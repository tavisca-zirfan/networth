/* File created: 04/10/2008-10:02:20; Revision Date: Tue Apr 01 00:00:00 CDT 2008 */
INSERT INTO sub_answer (answer, sub_answer_id, start_date, end_date, update_user_id, update_date, answer_desc, parent_answer_id, external_cd) VALUES ('001.0','1','04-01-2008','09-30-2099','1','04-10-2008','CHOLERA D/T VIB CHOLERAE','2','0010');
INSERT INTO sub_answer (answer, sub_answer_id, start_date, end_date, update_user_id, update_date, answer_desc, parent_answer_id, external_cd) VALUES ('001.1','1','04-01-2008','09-30-2099','1','04-10-2008','CHOLERA D/T VIB EL TOR','2','0011');
INSERT INTO sub_answer (answer, sub_answer_id, start_date, end_date, update_user_id, update_date, answer_desc, parent_answer_id, external_cd) VALUES ('002.0','1','04-01-2008','09-30-2099','1','04-10-2008','TYPHOID FEVER','2','0020');
INSERT INTO sub_answer (answer, sub_answer_id, start_date, end_date, update_user_id, update_date, answer_desc, parent_answer_id, external_cd) VALUES ('001.9','1','04-01-2008','09-30-2099','1','04-10-2008','CHOLERA NOS','2','0019');
COMMIT; 
/* File creation completed */