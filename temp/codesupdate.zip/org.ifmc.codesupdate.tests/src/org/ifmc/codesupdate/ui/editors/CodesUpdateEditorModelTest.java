/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.editors;

import java.text.ParseException;

import org.junit.Test;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CodesUpdateEditorModelTest {

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.ui.editors.editors.CodesUpdateEditorModel#processUpdate(java.util.Map, java.util.Date)}.
	 * 
	 * @throws ParseException
	 */
	@Test
	public void testProcessUpdate() throws ParseException {
		// CodeFilesViewModel model = CodeFilesViewModel.getInstance();
		// Map<CodeTypeEnum, File> inputFileMap = new HashMap<CodeTypeEnum, File>();
		// SimpleDateFormat sdf = new SimpleDateFormat("mm/dd/yyyy");
		// Date revisionDate = sdf.parse("01/01/2007");
		//
		// inputFileMap.put(CodeTypeEnum.DIAGNOSIS, new File(
		// "C:\\test_input_files\\revision1\\I9diagnoses.txt"));
		// model.processUpdate(inputFileMap, revisionDate);

	}
}
