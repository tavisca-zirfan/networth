package org.ifmc.codesupdate.tests;

import junit.framework.JUnit4TestAdapter;

import org.ifmc.codesupdate.ui.editors.CodesUpdateEditorModelTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses( { CodesUpdateEditorModelTest.class })
public class AllTests {

	// @Test
	// public static junit.framework.Test suite() {
	// TestSuite suite = new TestSuite("Test for
	// org.ifmc.codesupdate.tests");
	// $JUnit-BEGIN$
	// Test test = (Test) new CodesUpdateEditorModelTest();
	// $JUnit-END$
	// return suite;
	// return new JUnit4TestAdapter(CodesUpdateEditorModelTest.class);
	// }

}
