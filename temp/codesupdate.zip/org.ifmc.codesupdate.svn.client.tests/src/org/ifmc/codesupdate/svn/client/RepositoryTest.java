/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.io.File;
import java.util.List;

import junit.framework.Assert;

import org.ifmc.codesupdate.svn.client.exception.SVNClientException;
import org.junit.BeforeClass;
import org.junit.Test;
import org.tmatesoft.svn.core.SVNException;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class RepositoryTest {

	static Repository repo;

	@BeforeClass
	public static void setup() {
		String repositoryURL = "svn://c2r7u07/projects/dev/Icd9cmArtifacts/trunk/resources/dev_artifacts/tests/";
		String login = "icd9cm";
		String password = "dw12n3e12";
		repo = new Repository(repositoryURL, login, password);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#Repository(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testRepositoryIncorrect() {
		String incorrectRepositoryURL = "svn://c1r7u07/projects/dev/Icd9cmArtifacts/trunk/resources/dev_artifacts/tests/";

		try {
			@SuppressWarnings("unused")
			Repository repo = new Repository(incorrectRepositoryURL, "icd9cm",
					"password");
		} catch (Exception e) {
			Assert.assertTrue(true);
		}

	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#retrieveFile(java.io.File, java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testRetrieveFile() throws SVNClientException {

		String filePath = "10-01-2006/Output/CART/diagnosis.codes";
		String outputFilePath = "C:/icd9cm_tests/diagnosis.codes";

		repo.retrieveFile(filePath, outputFilePath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#saveOrUpdateFile(java.io.File, java.lang.String)}.
	 * 
	 * @throws SVNException
	 * @throws SVNClientException
	 */
	@Test
	public void testSaveOrUpdateFileSave() throws SVNException,
			SVNClientException {

		File file = new File("c:/icd9cm_tests/add_file.txt");
		String repoDirPath = "temp/";
		repo.saveOrUpdateFile(file, repoDirPath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#saveOrUpdateFile(java.io.File, java.lang.String)}.
	 * 
	 * @throws SVNException
	 * @throws SVNClientException
	 */
	@Test
	public void testSaveOrUpdateFileUpdate() throws SVNException,
			SVNClientException {

		File file = new File("c:/icd9cm_tests/updated_file.txt");
		String repoDirPath = "/";
		repo.saveOrUpdateFile(file, repoDirPath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#createDir(java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testCreateDir() throws SVNClientException {
		repo.createDir("temp/add/new/dir/");
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#isFileExistsInRepository(java.io.File, java.lang.String)}.
	 */
	@Test
	public void testIsFileExistsInRepository() {
		File file = new File("c:/icd9cm_tests/diagnosis.codes");
		String dirPath = "10-01-2006/Output/CART/";
		repo.isFileExistsInRepository(file, dirPath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.Repository#retrieveDirList(java.lang.String)}.
	 */
	@Test
	public void testRetrieveDirList() {
		String path = "/";
		List<String> dirs = repo.retrieveDirList(path);
		Assert.assertTrue(!dirs.isEmpty());
	}

}
