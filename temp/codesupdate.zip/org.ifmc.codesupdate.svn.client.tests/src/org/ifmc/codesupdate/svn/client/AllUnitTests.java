package org.ifmc.codesupdate.svn.client;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses( { RepositoryTest.class, SVNOperationTest.class,
		SVNClientHelperTrailingSlashTest.class,  SVNClientHelperFileNameTest.class})
public class AllUnitTests {

}
