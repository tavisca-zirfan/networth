/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.io.File;

import org.ifmc.codesupdate.svn.client.exception.SVNClientException;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class SVNOperationTest {

	static SVNRepository svnRepository;

	@BeforeClass
	public static void setup() throws SVNException {
		String repositoryURL = "svn://c2r7u07/projects/dev/Icd9cmArtifacts/trunk/resources/dev_artifacts/tests/";
		String login = "icd9cm";
		String password = "dw12n3e12";

		svnRepository = SVNRepositoryFactory.create(SVNURL
				.parseURIEncoded(repositoryURL));

		ISVNAuthenticationManager authManager = SVNWCUtil
				.createDefaultAuthenticationManager(login, password);
		svnRepository.setAuthenticationManager(authManager);

	}

	@AfterClass
	public static void tearDown() {
		// TODO
		// delete newly added directories and files
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#retrieveFile(org.tmatesoft.svn.core.io.SVNRepository, java.lang.String, java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testRetrieveFile() throws SVNClientException {
		String filePath = "10-01-2006/Output/CART/diagnosis.codes";
		String outputFilePath = "C:/icd9cm_tests/diagnosis.codes";
		SVNOperation.retrieveFile(svnRepository, filePath, outputFilePath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#addDir(org.tmatesoft.svn.core.io.SVNRepository, java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testAddDir() throws SVNClientException {
		SVNOperation.addDir(svnRepository, "temp/new_dir");
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#addFile(org.tmatesoft.svn.core.io.SVNRepository, java.io.File, java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testAddFile() throws SVNClientException {
		File file = new File("c:/icd9cm_tests/add_file.txt");
		String addDirPath = "temp/"; // trailing '/' is required
		SVNOperation.addFile(svnRepository, file, addDirPath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#rollbackFile(org.tmatesoft.svn.core.io.SVNRepository, java.io.File, java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testRollbackFile() throws SVNClientException {
		String filePath = "temp/add_file.txt";
		SVNOperation.rollbackFile(svnRepository, filePath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#findNodeType(org.tmatesoft.svn.core.io.SVNRepository, java.lang.String)}.
	 * 
	 */
	@Test
	public void testFindNodeType() throws SVNClientException {
		String nodeType = SVNOperation
				.findNodeType(svnRepository, "10-01-2006");
		Assert.assertEquals("dir", nodeType);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#updateFile(org.tmatesoft.svn.core.io.SVNRepository, java.io.File, java.lang.String)}.
	 * 
	 * @throws SVNClientException
	 */
	@Test
	public void testUpdateFile() throws SVNClientException {
		File file = new File("c:/icd9cm_tests/updated_file.txt");
		String updateDirPath = "/";
		SVNOperation.updateFile(svnRepository, file, updateDirPath);
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNOperation#retrieveDirList(org.tmatesoft.svn.core.io.SVNRepository, java.lang.String)}.
	 */
	@Test
	public void testRetrieveDirList() {
		String dirPath = "/";
		SVNOperation.retrieveDirList(svnRepository, dirPath);
	}

}
