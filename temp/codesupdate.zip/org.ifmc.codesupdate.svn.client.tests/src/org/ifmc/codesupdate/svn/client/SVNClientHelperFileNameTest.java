/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
@RunWith(Parameterized.class)
public class SVNClientHelperFileNameTest {

	private String filePath;

	private String fileNameExpected;

	public SVNClientHelperFileNameTest(String filePath, String fileNameExpected) {
		super();
		this.filePath = filePath;
		this.fileNameExpected = fileNameExpected;
	}

	@Parameters
	public static Collection files() {
		return Arrays.asList(new Object[][] { { "C:/icd9cm_tests/add_file.txt",
				"add_file.txt" } });
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNClientHelper#extractFileNameFromPath(java.lang.String)}.
	 */
	@Test
	public void testExtractFileNameFromPath() {
		String outputFileName = SVNClientHelper
				.extractFileNameFromPath(filePath);
		Assert.assertEquals(fileNameExpected, outputFileName);
	}

}