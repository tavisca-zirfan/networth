/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
@RunWith(Parameterized.class)
public class SVNClientHelperTrailingSlashTest {

	private String dirPath;

	private String dirPathExpected;

	public SVNClientHelperTrailingSlashTest(String dirPath,
			String dirPathExpected) {
		super();
		this.dirPath = dirPath;
		this.dirPathExpected = dirPathExpected;
	}

	@Parameters
	public static Collection dirPaths() {
		return Arrays.asList(new Object[][] { { "C:/MyDir", "C:/MyDir/" },
				{ "C:/MyDir/", "C:/MyDir/" }, { "", "" } });
	}

	/**
	 * Test method for
	 * {@link org.ifmc.codesupdate.svn.client.SVNClientHelper#addTrailingSlash(java.lang.String)}.
	 */
	@Test
	public void testAddTrailingSlash() {
		String outputDirPath = SVNClientHelper.addTrailingSlash(dirPath);
		Assert.assertEquals(dirPathExpected, outputDirPath);
	}

}
