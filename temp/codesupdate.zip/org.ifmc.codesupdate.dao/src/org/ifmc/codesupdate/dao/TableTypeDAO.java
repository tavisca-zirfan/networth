/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.TableType;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;


/**
 * DAO class that provides methods to manage Revision objects.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class TableTypeDAO extends CodesUpdateGenericDAO<TableType, String> {

	/**
	 * Returns the CodeType that matches given description.
	 *
	 * @param description
	 *            the String description to match against
	 * @return the CodeType; <code>null</code> if doesn't exist
	 */
	public TableType findByDescription(final String description) {
		CriteriaQuery q = new CriteriaQuery();
		q.add(Restrictions.eq("description", description));
		TableType tableType = null;
		try {

			List<TableType> tableTypes = find(q);
			if (!tableTypes.isEmpty()) {
				tableType = tableTypes.get(0);
			}

		} catch (SearchException se) {
			// we return null to indicate that type was not found
		}
		return tableType;
	}

}
