package org.ifmc.codesupdate.dao.dt;

public class BaseEntity implements IIdentifiable {
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
