/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.codesupdate.dao.util.Helper;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.Alias;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;

/**
 * DAO class that provides methods to manage CodeRevision objects.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CodeRevisionDAO extends
		CodesUpdateGenericDAO<CodeRevision, String> {

	/**
	 * Returns all active code revisions for specified revision start date. If
	 * revision start date is null then all active code revisions are returned.
	 *
	 * @param codeType
	 *            the CodeType of the codes to filter by
	 * @param revisionStartDate
	 *            the Revision start date to filter by; <code>null</code> for
	 *            all active codes
	 * @return the List of active code revisions
	 * @throws CodesUpdateDBException
	 *             if error while querying for code revisions
	 */
	public List<CodeRevision> findActiveCodeRevisions(final CodeType codeType,
			final Date revisionStartDate, final Date highDate)
			throws CodesUpdateDBException {

		CriteriaQuery q = new CriteriaQuery();
		// filter by specified code type
		q.add(new Alias("code", "c"));
		q.add(Restrictions.eq("c.codeType", codeType));

		// filter by revision endDate = HIGH_DATE
		q.add(new Alias("revision", "r"));
		q.add(Restrictions.eq("r.endDate", highDate));

		// if revision start date specificied then filter by
		// startDate = revisionStartDate
		if (revisionStartDate != null) {
			q.add(Restrictions.eq("r.startDate", revisionStartDate));
		}

		try {
			return this.find(q);
		} catch (SearchException se) {
			throw new CodesUpdateDBException(se);
		}

	}

	/**
	 * Returns all expired code revisions that were expired for the specified
	 * revision date.
	 *
	 * @param codeType
	 *            the CodeType of the codes to filter by
	 * @param revisionDate
	 *            non-null revision date
	 * @return the List of expired Code Revisions
	 * @throws CodesUpdateDBException
	 *             if revisionDate is <code>null</code>; if error querying
	 *             for code revisions
	 */
	public List<CodeRevision> findExpiredCodeRevisions(final CodeType codeType,
			final Date revisionDate) throws CodesUpdateDBException {

		if (revisionDate == null)
			throw new CodesUpdateDBException("Revision date cannot be null");

		CriteriaQuery q = new CriteriaQuery();
		// filter by specified code type
		q.add(new Alias("code", "c"));
		q.add(Restrictions.eq("c.codeType", codeType));

		// filter by revisionEndDate == revisionStartDate - 1
		q.add(new Alias("revision", "r"));
		q.add(Restrictions.eq("r.endDate", Helper.getDateBefore(revisionDate)));

		try {
			return this.find(q);
		} catch (SearchException se) {
			throw new CodesUpdateDBException(se);
		}
	}

	public CodeRevision findActiveCodeRevision(final String key, final CodeType codeType,
			final Date highDate) {
		CriteriaQuery q = new CriteriaQuery();
		// filter by specified code type
		q.add(new Alias("code", "c"));
		q.add(Restrictions.eq("c.key", key));
		q.add(Restrictions.eq("c.codeType", codeType));

		// filter by revision endDate = HIGH_DATE
		q.add(new Alias("revision", "r"));
		q.add(Restrictions.eq("r.endDate", highDate));

		// if revision start date specificied then filter by
		// startDate = revisionStartDate
		// TODO we don't filter by start dates
		// if (revisionStartDate != null) {
		// q.add(Restrictions.eq("r.startDate", revisionStartDate));
		// }

		try {
			return this.find(q).get(0);
		} catch (SearchException se) {
			throw new CodesUpdateDBException(se);
		}
	}

}
