/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class TableType extends AuditableEntity {

	private String description;

	/**
	 * Required by Hibernate
	 */
	public TableType() {
	}

	/**
	 * @param id
	 * @param description
	 */
	public TableType(String description) {
		super();
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return description;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;

		// object must be CodeType at this point
		TableType codeType = (TableType) obj;
		return description == codeType.description
				|| (description != null && description.equals(codeType.description));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		int desc_hash = (null == description ? 0 : description.hashCode());
		hash = 31 * hash + desc_hash;
		return (hash);
	}
}
