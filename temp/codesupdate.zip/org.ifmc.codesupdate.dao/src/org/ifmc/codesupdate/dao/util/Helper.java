/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.util;

import java.util.Date;

/**
 * Provides DAO Helper methods.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class Helper {

	/**
	 * Returns the date before the given date.
	 * 
	 * @param revisionDate
	 *            the Date
	 * @return the date before the given date
	 */
	public static Date getDateBefore(final Date revisionDate) {

		long dayInMillis = 1000 * 60 * 60 * 24;
		// subtract a day
		long dateMillis = revisionDate.getTime() - dayInMillis;

		return new java.util.Date(dateMillis);
	}
}
