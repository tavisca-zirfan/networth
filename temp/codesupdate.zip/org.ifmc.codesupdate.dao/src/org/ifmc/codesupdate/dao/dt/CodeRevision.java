/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

/**
 * Code Revision represents the revision of a code. Therefore it is composed of
 * the Code itself and a Revision. Description is the distinguishing attribute
 * between Code Revisions for a given Code.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CodeRevision extends AuditableEntity {

	private Code code;

	private String description;

	private Revision revision;

	/**
	 * Required by Hibernate
	 */
	public CodeRevision() {
	}

	/**
	 * @param code
	 *            the Code
	 * @param description
	 *            the Code description associated with this revision
	 * @param revision
	 *            the Revision
	 */
	public CodeRevision(Code code, String description, Revision revision) {
		super();
		this.code = code;
		this.description = description;
		this.revision = revision;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the code
	 */
	public Code getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(Code code) {
		this.code = code;
	}

	/**
	 * @return the revision
	 */
	public Revision getRevision() {
		return revision;
	}

	/**
	 * @param revision
	 *            the revision to set
	 */
	public void setRevision(Revision revision) {
		this.revision = revision;
	}

	public String toString() {
		return code.toString() + " " + description + " " + revision.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;

		// object must be CodeRevision at this point
		CodeRevision cr = (CodeRevision) obj;
		return (code == cr.code || (code != null && code.equals(cr.code)))
				&& (revision == cr.revision || (revision != null && revision
						.equals(cr.revision)))
				&& (description == cr.description || (description != null && description
						.equals(cr.description)));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		int code_hash = (null == code ? 0 : code.hashCode());
		hash = 31 * hash + code_hash;

		int rev_hash = (null == revision ? 0 : revision.hashCode());
		hash = 31 * hash + rev_hash;

		int desc_hash = (null == description ? 0 : description.hashCode());
		hash = 31 * hash + desc_hash;

		return (hash);
	}
}
