/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.dao.dt.TableType;
import org.ifmc.codesupdate.dao.util.Helper;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.Alias;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;

/**
 * DAO class that provides methods to manage CodeRevision objects.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class TableRevisionDAO extends
		CodesUpdateGenericDAO<TableRevision, String> {

	/**
	 * Returns all active table revisions for specified revision start date. If
	 * revision start date is null then all active table revisions are returned.
	 *
	 * @param tableType
	 *            the CodeType of the tables to filter by
	 * @param revisionStartDate
	 *            the Revision start date to filter by; <code>null</code> for
	 *            all active tables
	 * @return the List of active table revisions
	 * @throws CodesUpdateDBException
	 *             if error while querying for table revisions
	 */
	public List<TableRevision> findActiveTableRevisions(
			final TableType tableType,
			final Date revisionStartDate, final Date highDate)
			throws CodesUpdateDBException {

		CriteriaQuery q = new CriteriaQuery();
		// filter by specified code type
		q.add(new Alias("table", "t"));
		q.add(Restrictions.eq("t.tableType", tableType));

		// filter by revision endDate = HIGH_DATE
		q.add(new Alias("revision", "r"));
		q.add(Restrictions.eq("r.endDate", highDate));

		// if revision start date specificied then filter by
		// startDate = revisionStartDate
		if (revisionStartDate != null) {
			q.add(Restrictions.eq("r.startDate", revisionStartDate));
		}

		try {
			return this.find(q);
		} catch (SearchException se) {
			throw new CodesUpdateDBException(se);
		}

	}

	/**
	 * Returns all expired table revisions that were expired for the specified
	 * revision date.
	 *
	 * @param codeType
	 *            the CodeType of the tables to filter by
	 * @param revisionDate
	 *            non-null revision date
	 * @return the List of expired Table Revisions
	 * @throws CodesUpdateDBException
	 *             if revisionDate is <code>null</code>; if error querying
	 *             for table revisions
	 */
	public List<TableRevision> findExpiredTableRevisions(
			final TableType tableType,
			final Date revisionDate) throws CodesUpdateDBException {

		if (revisionDate == null) {
			throw new CodesUpdateDBException("Revision date cannot be null");
		}

		CriteriaQuery q = new CriteriaQuery();
		// filter by specified code type
		q.add(new Alias("table", "t"));
		q.add(Restrictions.eq("t.tableType", tableType));

		// filter by revisionEndDate == revisionStartDate - 1
		q.add(new Alias("revision", "r"));
		q.add(Restrictions.eq("r.endDate", Helper.getDateBefore(revisionDate)));

		try {
			return this.find(q);
		} catch (SearchException se) {
			throw new CodesUpdateDBException(se);
		}
	}

	/*
	 * public List<TableRevision> findExpiredCodeRevisions(final CodeType
	 * codeType, final Date revisionDate) { // TODO...how about Assertion if
	 * (revisionDate == null) throw new
	 * CodesUpdateDBException("Revision date cannot be null");
	 * 
	 * CriteriaQuery q = new CriteriaQuery(); // filter by specified code type
	 * q.add(new Alias("table", "t")); q.add(Restrictions.eq("t.type",
	 * codeType));
	 * 
	 * // filter by revisionEndDate == revisionStartDate - 1 q.add(new
	 * Alias("revision", "r")); q.add(Restrictions.eq("r.endDate",
	 * Helper.getDateBefore(revisionDate)));
	 * 
	 * try { return this.find(q); } catch (SearchException se) { throw new
	 * CodesUpdateDBException(se); } }
	 */

}