/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

import java.util.Set;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class TableRevision extends AuditableEntity {

	private Table table;

	private Revision revision;

	private Set<CodeRevision> codeRevisions;

	/**
	 * Required by Hibernate
	 */
	public TableRevision() {
	}

	/**
	 * @param table
	 *            the Table
	 * @param description
	 *            the Table description associated with this revision
	 * @param revision
	 *            the Revision
	 */
	public TableRevision(Table table, Set<CodeRevision> codeRevisions,
			Revision revision) {
		super();
		this.table = table;
		this.codeRevisions = codeRevisions;
		this.revision = revision;
	}

	/**
	 * @return the code
	 */
	public Table getTable() {
		return table;
	}

	/**
	 * @param table
	 *            the table to set
	 */
	public void setTable(Table table) {
		this.table = table;
	}

	/**
	 * @return the revision
	 */
	public Revision getRevision() {
		return revision;
	}

	/**
	 * @param revision
	 *            the revision to set
	 */
	public void setRevision(Revision revision) {
		this.revision = revision;
	}

	/**
	 * @return the CodeRevisions
	 */
	public Set<CodeRevision> getCodeRevisions() {
		return codeRevisions;
	}

	/**
	 * @param codeRevisions
	 *            the Set of CodeRevisions to set
	 */
	public void setCodeRevisions(Set<CodeRevision> codeRevisions) {
		this.codeRevisions = codeRevisions;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return table.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;

		// object must be TableRevision at this point
		TableRevision tr = (TableRevision) obj;
		return (table == tr.table || (table != null && table.equals(tr.table)))
				&& (revision == tr.revision || (revision != null && revision
						.equals(tr.revision)));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		int table_hash = (null == table ? 0 : table.hashCode());
		hash = 31 * hash + table_hash;

		int rev_hash = (null == revision ? 0 : revision.hashCode());
		hash = 31 * hash + rev_hash;

		return (hash);
	}
}
