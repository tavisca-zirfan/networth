/**
 * 
 */
package org.ifmc.codesupdate.dao;

import org.eclipse.osgi.util.NLS;

/**
 * @author sudhakar
 * 
 */
public class Messages {

	private static final String BUNDLE_NAME = "org.ifmc.codesupdate.dao.messages"; //$NON-NLS-1$

	// public static String TYPE_PERSIST_FAILED;

	static {
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}
}
