/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public interface IIdentifiable {

	String getId();

	void setId(String id);
}
