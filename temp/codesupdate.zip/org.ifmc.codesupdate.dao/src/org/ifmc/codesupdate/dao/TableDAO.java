/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class TableDAO extends CodesUpdateGenericDAO<Table, String> {

	/**
	 * Returns the table that matches given key and type. Clients are expected
	 * to check for null if no match is found.
	 * 
	 * @param key
	 *            the String key to match against
	 * @param codeType
	 *            the CodeType to match against
	 * @return the Table object, <code>null</code> otherwise
	 */
	public Table find(final String key, final CodeType codeType) {
		final CriteriaQuery q = new CriteriaQuery();
		q.add(Restrictions.eq("key", key));
		q.add(Restrictions.eq("type", codeType));

		Table table = null;

		try {

			List<Table> tables = find(q);
			if (!tables.isEmpty()) {
				table = tables.get(0);
			}

		} catch (SearchException ignore) {
			// swallow this exception
		}

		return table;
	}
}
