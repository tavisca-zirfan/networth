/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.util;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.ifmc.codesupdate.dao.dt.IAuditable;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class AuditInterceptor extends EmptyInterceptor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public boolean onSave(Object entity, Serializable id,
			Object[] currentState, String[] propertyNames, Type[] types) {
		boolean updated = false;

		if (entity instanceof IAuditable) {
			IAuditable a = (IAuditable) entity;
			String username = getCurrentUser();
			Date stamp = new Date();
			for (int i = 0; i < propertyNames.length; i++) {
				String propertyName = propertyNames[i];

				updated |= checkCreatedOn(currentState, a, stamp, i,
						propertyName);
				updated |= checkCreatedBy(currentState, a, username, i,
						propertyName);
				updated |= checkUpdatedOn(currentState, a, stamp, i,
						propertyName);
				updated |= checkUpdatedBy(currentState, a, username, i,
						propertyName);
			}
		}

		return updated;
	}

	@Override
	public boolean onFlushDirty(Object arg0, Serializable arg1, Object[] arg2,
			Object[] arg3, String[] arg4, Type[] arg5) {
		// TODO Auto-generated method stub
		return super.onFlushDirty(arg0, arg1, arg2, arg3, arg4, arg5);
	}

	private boolean checkCreatedOn(Object[] currentState, IAuditable auditable,
			Date stamp, int idx, String propertyName) {
		if ("createdOn".equals(propertyName)) {
			auditable.setCreatedOn(stamp);
			currentState[idx] = stamp;
			return true;
		} else {
			return false;
		}
	}

	private boolean checkCreatedBy(Object[] currentState, IAuditable auditable,
			String username, int idx, String propertyName) {
		if ("createdBy".equals(propertyName)) {
			auditable.setCreatedBy(username);
			currentState[idx] = username;
			return true;
		} else {
			return false;
		}
	}

	private boolean checkUpdatedOn(Object[] currentState, IAuditable auditable,
			Date stamp, int idx, String propertyName) {
		if ("updatedOn".equals(propertyName)) {
			auditable.setUpdatedOn(stamp);
			currentState[idx] = stamp;
			return true;
		} else {
			return false;
		}
	}

	private boolean checkUpdatedBy(Object[] currentState, IAuditable auditable,
			String username, int idx, String propertyName) {
		if ("updatedBy".equals(propertyName)) {
			auditable.setUpdatedBy(username);
			currentState[idx] = username;
			return true;
		} else {
			return false;
		}
	}

	private String getCurrentUser() {
		return "anonymous";
	}
}
