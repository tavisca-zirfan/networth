/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

import java.util.Date;

/**
 * Revision is a unique combination of start date and end date.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class Revision extends AuditableEntity {

	private Date startDate;

	private Date endDate;

	/**
	 * Required by Hibernate
	 */
	public Revision() {
	}

	/**
	 * @param startDate
	 * @param endDate
	 */
	public Revision(Date startDate, Date endDate) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String toString() {
		return startDate + " - " + endDate;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;

		// object must be Revision at this point
		Revision revision = (Revision) obj;
		return (startDate == revision.startDate || (startDate != null && startDate
				.equals(revision.startDate)))
				&& (endDate == revision.endDate || (endDate != null && endDate
						.equals(revision.endDate)));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		int sDate_hash = (null == startDate ? 0 : startDate.hashCode());
		hash = 31 * hash + sDate_hash;

		int eDate_hash = (null == endDate ? 0 : endDate.hashCode());
		hash = 31 * hash + eDate_hash;
		return (hash);
	}
}
