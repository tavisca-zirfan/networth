/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

import java.util.Date;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public interface IAuditable {

	String getCreatedBy();

	void setCreatedBy(String username);

	String getUpdatedBy();

	void setUpdatedBy(String username);

	Date getCreatedOn();

	void setCreatedOn(Date creationDate);

	Date getUpdatedOn();

	void setUpdatedOn(Date updateDate);
}
