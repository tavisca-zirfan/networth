/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;

/**
 * DAO class that provides methods to manage Revision objects.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CodeTypeDAO extends CodesUpdateGenericDAO<CodeType, String> {

	/**
	 * Returns the CodeType that matches given description.
	 * 
	 * @param description
	 *            the String description to match against
	 * @return the CodeType; <code>null</code> if doesn't exist
	 */
	public CodeType findByDescription(String description) {
		CriteriaQuery q = new CriteriaQuery();
		q.add(Restrictions.eq("description", description));
		CodeType codeType = null;
		try {

			List<CodeType> codeTypes = find(q);
			if (!codeTypes.isEmpty())
				codeType = codeTypes.get(0);

		} catch (SearchException se) {
			// we return null to indicate that type was not found
		}
		return codeType;
	}

}
