/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CodesUpdateDBException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CodesUpdateDBException() {
		super();
	}

	public CodesUpdateDBException(String message) {
		super(message);
	}

	public CodesUpdateDBException(String message, Throwable cause) {
		super(message, cause);
	}

	public CodesUpdateDBException(Throwable cause) {
		super(cause);
	}
}
