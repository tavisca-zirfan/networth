/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

/**
 * Table is a unique combination of a table key and table codeType. <br />
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class Table extends AuditableEntity {

	private String key;

	private TableType tableType;

	/**
	 * Default Constructor. Required by Hibernate
	 */
	public Table() {
	}

	/**
	 * @param key
	 *            the table key
	 * @param tableType
	 *            the TableType of the table
	 */
	public Table(final String key, final TableType tableType) {
		super();
		this.key = key;
		this.tableType = tableType;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(final String key) {
		this.key = key;
	}

	/**
	 * @return the tableType
	 */
	public TableType getTableType() {
		return tableType;
	}

	/**
	 * @param tableType
	 *            the tableType to set
	 */
	public void setTableType(final TableType tableType) {
		this.tableType = tableType;
	}

	@Override
	public String toString() {
		return key + " " + tableType.toString();
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;

		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;

		// object must be Table at this point
		Table table = (Table) obj;
		return ((key == table.key) || ((key != null) && key.equals(table.key)))
				&& ((tableType == table.tableType) || ((tableType != null) && tableType
						.equals(table.tableType)));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		int key_hash = (null == key ? 0 : key.hashCode());
		hash = 31 * hash + key_hash;

		int type_hash = (null == tableType ? 0 : tableType.hashCode());
		hash = 31 * hash + type_hash;
		return (hash);
	}
}
