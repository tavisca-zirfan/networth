/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.Revision;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;

/**
 * DAO class that provides methods to manage Revision objects.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class RevisionDAO extends CodesUpdateGenericDAO<Revision, String> {

	/**
	 * Returns the revision for the specified startDate and endDate
	 * 
	 * @param startDate
	 *            the Revision start date
	 * @param endDate
	 *            the Revision end date
	 * @return the Revision; <code>null</code> if does not exist
	 */
	public Revision find(Date startDate, Date endDate) {

		CriteriaQuery q = new CriteriaQuery();
		q.add(Restrictions.eq("startDate", startDate));
		q.add(Restrictions.eq("endDate", endDate));
		Revision revision = null;
		try {

			List<Revision> revisions = find(q);
			if (!revisions.isEmpty())
				revision = revisions.get(0);

		} catch (SearchException se) {
			// return null
		}
		return revision;
	}
}
