package org.ifmc.codesupdate.dao;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.eclipse.core.runtime.Plugin;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.ifmc.codesupdate.dao.util.AuditInterceptor;
import org.ifmc.qms.database.DatabasePlugin;
import org.ifmc.qms.database.IDatabase;
import org.ifmc.qms.database.IDatabaseConfiguration;
import org.ifmc.qms.hibernate.HibernateException;
import org.ifmc.qms.util.JobUtils;
import org.ifmc.qms.util.QmsConstants;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class CodesUpdateDAOPlugin extends Plugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "org.ifmc.codesupdate.dao";

	// The shared instance
	private static CodesUpdateDAOPlugin plugin;

	// Hibernate session factory
	private SessionFactory sessionFactory = null;

	private boolean inited = false;

	/**
	 * The constructor
	 */
	public CodesUpdateDAOPlugin() {
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.runtime.Plugins#start(org.osgi.framework.BundleContext)
	 */
	@Override
	public void start(final BundleContext context) throws Exception {
		super.start(context);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.runtime.Plugin#stop(org.osgi.framework.BundleContext)
	 */
	@Override
	public void stop(final BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static CodesUpdateDAOPlugin getDefault() {
		return plugin;
	}

	public synchronized SessionFactory getSessionFactory()
			throws HibernateException {
		if (sessionFactory == null) {
			checkPersistenceStorageStatus();
			// using string literal here...else we end up with cyclic
			// dependency on codesupdate plugin
			IDatabase database = DatabasePlugin.getDefault()
					.getEmbeddedDatabase("org.ifmc.codesupdate.perspective");

			if (database.checkConfiguration()) {
				try {
					Configuration configuration = getConfiguration();
					configuration.addProperties(createProperties(database
							.getConfiguration()));

					sessionFactory = configuration.buildSessionFactory();
				} catch (Throwable t) {
					throw new HibernateException(
							"An error occurred while initializing Hibernate", t);
				}
			}
		}

		return sessionFactory;
	}

	public synchronized void closeSessionFactory() {
		if ((sessionFactory != null) && !sessionFactory.isClosed()) {
			sessionFactory.close();
		}
		sessionFactory = null;
	}

	private void checkPersistenceStorageStatus() {
		// After we have been initialized, avoid waiting
		if (inited)
			return;

		try {
			JobUtils
					.waitForFamilyMembers(QmsConstants.INITIALIZATION_JOB_FAMILY);
			inited = true;
		} catch (InterruptedException ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
	}

	private Properties createProperties(final IDatabaseConfiguration configuration)
			throws IOException {
		URL url = getBundle().getResource("hibernate.properties");
		Properties properties = new Properties();

		BufferedInputStream bis = null;
		try {
			properties.load(bis = new BufferedInputStream(url.openStream()));

			properties.setProperty("hibernate.connection.driver_class",
					configuration.getDriverName());
			properties.setProperty("hibernate.connection.url", configuration
					.getUrl());
			properties.setProperty("hibernate.connection.username",
					configuration.getUsername());
			properties.setProperty("hibernate.connection.password",
					configuration.getPassword());
			properties.setProperty("hibernate.dialect", configuration
					.getDialect());
		} finally {
			if (bis != null) {
				bis.close();
			}
			bis = null;
		}

		return properties;
	}

	private Configuration getConfiguration() {
		Configuration configuration = new Configuration();

		// add POJOs to be persisted here
		configuration.addClass(org.ifmc.codesupdate.dao.dt.Code.class);
		configuration.addClass(org.ifmc.codesupdate.dao.dt.CodeType.class);
		configuration.addClass(org.ifmc.codesupdate.dao.dt.Revision.class);
		configuration.addClass(org.ifmc.codesupdate.dao.dt.CodeRevision.class);
		configuration.addClass(org.ifmc.codesupdate.dao.dt.Table.class);
		configuration.addClass(org.ifmc.codesupdate.dao.dt.TableType.class);
		configuration.addClass(org.ifmc.codesupdate.dao.dt.TableRevision.class);

		// the interceptor for auditing model objects
		configuration.setInterceptor(new AuditInterceptor());
		return configuration;
	}
}
