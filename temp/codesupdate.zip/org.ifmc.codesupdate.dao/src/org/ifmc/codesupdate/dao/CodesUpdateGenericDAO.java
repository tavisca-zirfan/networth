package org.ifmc.codesupdate.dao;

import java.io.Serializable;

import org.hibernate.SessionFactory;
import org.ifmc.qms.hibernate.HibernateException;
import org.ifmc.qms.hibernate.dao.GenericDAO;

public class CodesUpdateGenericDAO<T, ID extends Serializable> extends
		GenericDAO<T, ID> {

	@Override
	public void closeSessionFactory() throws HibernateException {
		CodesUpdateDAOPlugin.getDefault().closeSessionFactory();
	}

	@Override
	public SessionFactory getSessionFactory() throws HibernateException {
		return CodesUpdateDAOPlugin.getDefault().getSessionFactory();
	}

}
