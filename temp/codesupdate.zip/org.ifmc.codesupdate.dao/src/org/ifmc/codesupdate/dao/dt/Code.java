/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao.dt;

/**
 * Code is a unique combination of a code key and code codeType. <br /> Ex:
 * <ol>
 * <li>001.1 of codeType Diagnosis is a distinct code</li>
 * <li>001.1 of codeType Procedure is a distinct code</li>
 * </ol>
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class Code extends AuditableEntity {

	private String key;

	private CodeType codeType;

	/**
	 * Default Constructor. Required by Hibernate
	 */
	public Code() {
	}

	/**
	 * @param key
	 *            the code key
	 * @param codeType
	 *            the CodeType of the code
	 */
	public Code(final String key, final CodeType codeType) {
		super();
		this.key = key;
		this.codeType = codeType;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(final String key) {
		this.key = key;
	}

	/**
	 * @return the codeType
	 */
	public CodeType getCodeType() {
		return codeType;
	}

	/**
	 * @param codeType
	 *            the codeType to set
	 */
	public void setCodeType(final CodeType codeType) {
		this.codeType = codeType;
	}

	@Override
	public String toString() {
		return key + " " + codeType.toString();
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;

		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;

		// object must be Code at this point
		// we ignore case difference of the key field
		Code code = (Code) obj;
		return ((key == code.key) || ((key != null) && key
				.equalsIgnoreCase(code.key)))
				&& ((codeType == code.codeType) || ((codeType != null) && codeType
						.equals(code.codeType)));
	}

	@Override
	public int hashCode() {
		int hash = 7;
		// we toUpperCase key field to ignore case difference
		int key_hash = (null == key ? 0 : key.toUpperCase().hashCode());
		hash = 31 * hash + key_hash;

		int type_hash = (null == codeType ? 0 : codeType.hashCode());
		hash = 31 * hash + type_hash;
		return (hash);
	}
}
