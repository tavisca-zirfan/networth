/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.qms.hibernate.SearchException;
import org.ifmc.qms.hibernate.dao.CriteriaQuery;

/**
 * DAO class the provides methods to manage Code objects.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CodeDAO extends CodesUpdateGenericDAO<Code, String> {

	/**
	 * Returns the code that matches given key and type. Clients are expected to
	 * check for null if no match is found.
	 * 
	 * @param key
	 *            the String key to match against
	 * @param codeType
	 *            the CodeType to match against
	 * @return the Code object, <code>null</code> otherwise
	 */
	public Code find(final String key, final CodeType codeType) {
		final CriteriaQuery q = new CriteriaQuery();
		q.add(Restrictions.eq("key", key));
		q.add(Restrictions.eq("type", codeType));

		Code code = null;

		try {

			List<Code> codes = find(q);
			if (!codes.isEmpty()) {
				code = codes.get(0);
			}

		} catch (SearchException ignore) {
			// swallow this exception
		}

		return code;
	}
}
