/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.dao.CodesUpdateDBException;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.codesupdate.dao.dt.Revision;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.dao.dt.TableType;

/**
 * Provides methods to manage data in the codes database.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public interface IDatabaseService {

	/**
	 * Creates a new Code Revision.
	 *
	 * @param code
	 *            code can be a transient object or a persisted object. Since
	 *            cascade="save-update" if it is transient then a new code
	 *            object is created. When an existing code is revised, then the
	 *            persistent object is passed which will eliminate creation of
	 *            duplication codes. This is different from expireCodes method
	 *            where we have to track the state of the Revision object.
	 * @param revision
	 *            the revision to associate with the code revision
	 * @param description
	 *            the code description
	 * @return the Code Revision that is created
	 * @throws CodesUpdateDBException
	 *             if creation of Code Revision fails
	 */
	CodeRevision createCodeRevision(final Code code, final Revision revision,
			final String description);

	/**
	 * Returns an existing CodeType or creates a new CodeType if it doesn't exist.
	 *
	 * @param typeDescription
	 *            the description
	 * @return the CodeType
	 * @throws CodesUpdateCoreRuntimeException
	 *             if failed to create new CodeType
	 */
	CodeType findOrCreateCodeType(final String typeDescription);

	/**
	 * Returns an existing TableType or creates a new TableType if it doesn't
	 * exist.
	 *
	 * @param typeDescription
	 *            the description
	 * @return the CodeType
	 * @throws CodesUpdateCoreRuntimeException
	 *             if failed to create new CodeType
	 */
	TableType findOrCreateTableType(final String typeDescription);

	/**
	 * Returns an existing Code or creates a new Code if it doesn't exist.
	 *
	 * @param key
	 *            the code key
	 * @param codeType
	 *            the code CodeType
	 * @return the Code
	 * @throws CodesUpdateDBException
	 *             if failed to create new Code
	 */
	Code findOrCreateCode(final String key, final CodeType codeType);

	/**
	 * Returns an existing Revision or creates a new Revision (with end date as
	 * HIGH DATE) if it doesn't exist.
	 *
	 * @param revisionDate
	 *            the revision date of the revision
	 * @return the Revision
	 * @throws CodesUpdateDBException
	 *             if failed to create new Revision
	 */
	Revision findOrCreateRevision(final Date revisionDate);

	/**
	 * Returns all Revisions that exist in the database.
	 *
	 * @return the List of Code Revisions
	 * @throws CodesUpdateDBException
	 *             if error querying the database
	 */
	List<Revision> findAllRevisions();

	/**
	 * Returns all active Code Revisions for the given code CodeType.
	 *
	 * @param codeType
	 *            the code CodeType
	 * @return the List of all Code Revisions
	 * @throws CodesUpdateDBException
	 *             if error querying for Code Revisions
	 */
	List<CodeRevision> findActiveCodeRevisions(final CodeType codeType);

	/**
	 * Returns all active Code Revisions for the given type description and
	 * revision start date.
	 *
	 * @param typeDescription
	 *            the code CodeType description
	 * @param revisionDate
	 *            the Revision start date
	 * @return the filtered List of active Code Revisions
	 * @throws CodesUpdateDBException
	 *             if error querying for Code Revisions
	 */
	List<CodeRevision> findActiveCodeRevisions(final String typeDescription,
			final Date revisionStartDate);

	/**
	 * Returns the List of Code Revisions that were expired for the given
	 * Revision start date.
	 *
	 * @param typeDescription
	 *            the code CodeType description
	 * @param revisionDate
	 *            the Revision start date
	 * @return the list of expired Code Revisions
	 * @throws CodesUpdateDBException
	 *             if error querying for Code Revisions
	 */
	List<CodeRevision> findExpiredCodeRevisions(final String typeDescription,
			final Date revisionDate);

	/**
	 * Expires the given active Code Revision.
	 *
	 * @param codeRevision
	 *            the active Code Revision to be expired
	 * @param expireRevisionDate
	 *            the Date of the revision as of which this Code Revision is to
	 *            be expired
	 * @param allRevisions
	 *            all Revisions currently in the database
	 * @return the Code Revision that has been expired
	 * @throws CodesUpdateException
	 *             if codeRevision is already expired
	 * @throws CodesUpdateDBException
	 *             if expiry of Code Revision fails
	 */
	CodeRevision expireCodeRevision(final CodeRevision codeRevision,
			final Date expireRevisionDate, List<Revision> allRevisions)
			throws CodesUpdateException;

	/**
	 * Un-expires the given list of Code Revisions.
	 *
	 * @param codeRevisions
	 *            the List of Code Revisions
	 * @throws CodesUpdateDBException
	 */
	void unExpireCodeRevisions(List<CodeRevision> codeRevisions);

	/**
	 * Deletes the given list of Code Revisions.
	 *
	 * @param codeRevisions
	 *            the List of Code Revisions to be deleted
	 * @throws CodesUpdateDBException
	 *             if error when deleting a Code Revision
	 */
	void deleteCodeRevisions(List<CodeRevision> codeRevisions);

	List<TableRevision> findActiveTableRevisions(String string,
			Date revisionDate);

	void deleteTableRevisions(List<TableRevision> addedTableRevisions);

	List<TableRevision> findExpiredTableRevisions(String string,
			Date revisionDate);

	void unExpireTableRevisions(List<TableRevision> expiredTableRevisions);

	List<TableRevision> findActiveTableRevisions(TableType tableType);

	TableRevision expireTableRevision(TableRevision tr, Date startDate,
			List<Revision> allRevisions);

	/**
	 * Creates a new Table Revision given the table, revision and the set of
	 * code revisions associated with the table revision.
	 *
	 * @param table
	 *            the Table
	 * @param revision
	 *            the Revisions
	 * @param codeRevisions
	 *            the Set of CodeRevisions
	 * @return
	 */
	TableRevision createTableRevision(Table table, Revision revision,
			Set<CodeRevision> codeRevisions);

	CodeRevision findActiveCodeRevision(Code code);
}
