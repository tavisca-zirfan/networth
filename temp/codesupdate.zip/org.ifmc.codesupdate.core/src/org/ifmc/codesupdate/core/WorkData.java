/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class WorkData extends AbstractModelObject {

	// no. of work units worked
	private int workedUnits;

	private String currentSubTask;

	public WorkData() {
		currentSubTask = "";
	}

	public void worked(int workedUnits) {
		// use old value as 0 to model an increment type property
		firePropertyChange("workedUnits", 0, this.workedUnits = workedUnits);
	}

	public String getCurrentSubTask() {
		return currentSubTask;
	}

	public void setCurrentSubTask(String currentTask) {
		firePropertyChange("currentSubTask", this.currentSubTask,
				this.currentSubTask = currentTask);
	}

	public int getCurrentWorkedUnits() {
		return workedUnits;
	}
}
