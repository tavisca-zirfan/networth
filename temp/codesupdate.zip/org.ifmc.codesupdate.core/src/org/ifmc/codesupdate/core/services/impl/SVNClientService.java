/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services.impl;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.svn.client.Repository;

/**
 * Provides client side methods to access subversion.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class SVNClientService implements ISVNClientService {

	private Repository repository; // the repository

	/**
	 * @param repoUrl
	 *            the repository location to bind at
	 * @param login
	 *            the subversion account login id
	 * @param password
	 *            the subversion account password
	 */
	public SVNClientService(final String repoUrl, final String login,
			final String password) {
		// initialize the repository object
		repository = new Repository(repoUrl, login, password);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ISVNClientService#getLatestRevisionDate()
	 */
	public Date getLatestRevisionDate() {
		SortedSet<Date> revisionDates = getSortedRevisionDates();
		if (!revisionDates.isEmpty()) {
			return revisionDates.last();
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ISVNClientService#getSortedRevisionDates()
	 */
	public SortedSet<Date> getSortedRevisionDates() {

		// assumes revisions are stored at root of repository bind location
		String path = ".";
		List<String> dirs = repository.retrieveDirList(path);

		SortedSet<Date> sortedRevisionDates = new TreeSet<Date>();

		for (String dir : dirs) {
			try {
				sortedRevisionDates.add(CoreHelper.formatStringAsDate(dir));
			} catch (CodesUpdateException e) {
				// Non revision directory name found in the root location
				// we simply skip these
			}
		}
		return sortedRevisionDates;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ISVNClientService#retrieveFile(java.lang.String)
	 */
	public File retrieveFile(final String filePath, final String outputFilePath) {

		return repository.retrieveFile(filePath, outputFilePath);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ISVNClientService#persistFile(java.io.File,
	 *      java.lang.String)
	 */
	public void persistFile(final File file, final String destinationDir) {
		repository.saveOrUpdateFile(file, destinationDir);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ISVNClientService#isFileExists(java.io.File,
	 *      java.lang.String)
	 */
	public boolean isFileExists(final File file, final String dirPath) {
		return repository.isFileExistsInRepository(file, dirPath);
	}
}
