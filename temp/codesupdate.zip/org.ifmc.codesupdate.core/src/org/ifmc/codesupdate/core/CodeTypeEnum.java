/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core;

/**
 * Enum that is used through out the application to represent types of Codes
 * that are currently suportted by the application. When a new type is to be
 * supported it will need to be added to the this enum.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public enum CodeTypeEnum {

	PROCEDURE("I9procedures.txt"), DIAGNOSIS("I9diagnoses.txt"), CART_MEDICATION(
	"cart_medications.txt"), OPPS_MEDICATION("opps_medications.txt"), CPT(
	"cpt.txt");

	public String inputFileName;

	CodeTypeEnum(final String inputFileName) {
		this.inputFileName = inputFileName;
	}

	/**
	 * Given the input file name this method returns the corresponding CodeTypeEnum.
	 * 
	 * @param fileName
	 * @return
	 */
	public static CodeTypeEnum getCodeType(final String fileName) {
		for (CodeTypeEnum type : CodeTypeEnum.values()) {
			if (type.inputFileName.equals(fileName))
				return type;
		}
		return null;
	}
}
