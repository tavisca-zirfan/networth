/**
 * 
 */
package org.ifmc.codesupdate.core.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

/**
 * @author SRamasam
 * 
 */
public class LogData extends Observable {

	private List<String> messages = new ArrayList<String>();

	public List<String> getMessages() {
		return messages;
	}

	public void add(String message) {
		messages.add(message);
		setChanged();
		notifyObservers(message);
	}

	public void clear() {
		messages.clear();
	}
}
