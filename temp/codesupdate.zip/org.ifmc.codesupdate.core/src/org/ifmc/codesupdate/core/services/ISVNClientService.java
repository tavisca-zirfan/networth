/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services;

import java.io.File;
import java.util.Date;
import java.util.SortedSet;

import org.ifmc.codesupdate.svn.client.exception.SVNClientException;

/**
 * Provides client side methods to access subversion.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public interface ISVNClientService {

	/**
	 * Returns the most recent revision date available in the repository.
	 * 
	 * @return the Date of the latest revision; <code>null</code> if no
	 *         revisions exist yet
	 */
	Date getLatestRevisionDate();

	/**
	 * Returns the SortedSet of revision dates that exist in the repository.
	 * 
	 * @return the SortedSet of revision dates
	 */
	SortedSet<Date> getSortedRevisionDates();

	/**
	 * Returns the file stored at given repository file path at the specivfied
	 * output file path.
	 * 
	 * @param filePath
	 *            the path to the file relative to the repository bind location
	 * @param outputFilePath
	 *            the destination location of the output file
	 * @return the destination File
	 * @throws SVNClientException
	 *             if failed to retrieve specified file in repository location
	 *             or if failed to create the output destination file
	 */
	File retrieveFile(final String filePath, final String outputFilePath);

	/**
	 * Adds new file if does not exist or update file if already exists.
	 * 
	 * @param file
	 *            the File to be persisted
	 * @param destinationDir
	 *            the path relative to the repository bind location where the
	 *            file should be persisted
	 * @throws SVNClientException
	 *             if failed to persist
	 */
	void persistFile(final File file, final String destinationDir);

	/**
	 * Checks if specified file exists at the given repository location.
	 * 
	 * @param file
	 *            the file to check for
	 * @param dirPath
	 *            the repository path relative to the repository bind location
	 * @return <code>true</code> if the file exists; <code>false</code> if
	 *         not a file or the file does not exist
	 */
	boolean isFileExists(final File file, final String dirPath);

}