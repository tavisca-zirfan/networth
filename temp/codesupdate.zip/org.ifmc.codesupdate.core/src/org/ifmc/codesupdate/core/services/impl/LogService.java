/**
 * 
 */
package org.ifmc.codesupdate.core.services.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.Activator;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.qms.util.LogUtils;

/**
 * @author SRamasam
 * 
 */
public class LogService implements ILogService {

	private LogData logData; // stores the in-memory log messages

	/**
	 * Contructor
	 * 
	 * @param logData
	 *            the LogData that holds the in-memory log messages
	 */
	public LogService(final LogData logData) {
		this.logData = logData;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ILogService#getMessages()
	 */
	public List<String> getMessages() {
		return logData.getMessages();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ILogService#clearMessages()
	 */
	public void clearMessages() {
		logData.clear();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ILogService#logInfo(java.lang.String)
	 */
	public void logInfo(String message) {
		// log to the platform log
		LogUtils.log(message, Activator.PLUGIN_ID, LogUtils.INFO);

		String level = "INFO";
		message = formatLogMessage(message, level);

		// log to the in-memory log
		logData.add(message);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ILogService#logError(java.lang.String,
	 *      java.lang.Exception)
	 */
	public void logError(String message, Exception e) {
		// log to the platform log
		LogUtils.log(message, Activator.PLUGIN_ID, LogUtils.ERROR);
		LogUtils.log(e.getCause().getMessage(), Activator.PLUGIN_ID,
				LogUtils.ERROR);

		String level = "ERROR";
		message = formatLogMessage(message, level);

		logData.add(message);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ILogService#logError(java.lang.String)
	 */
	public void logError(String message) {
		// log to the platform log
		LogUtils.log(message, Activator.PLUGIN_ID, LogUtils.ERROR);

		String level = "ERROR";
		message = formatLogMessage(message, level);

		// add to messages list for tracking
		logData.add(message);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.ILogService#commit(java.util.Date,
	 *      org.ifmc.codesupdate.core.services.ISVNClientService)
	 */
	public void commit(final Date revisionDate,
			final ISVNClientService svnClientService) {
		File logFile = flushToFile();

		svnClientService.persistFile(logFile, CoreHelper
				.formatLogDestination(revisionDate));
	}

	/**
	 * Writes the in-memory log to file.
	 * 
	 * @return the output file
	 * @throws CodesUpdateException
	 *             if failed to create output file
	 */
	private File flushToFile() throws CodesUpdateException {
		FileWriter fw = null;
		PrintWriter pw = null;

		File logFile = initializeLogFile();
		try {
			fw = new FileWriter(logFile, true);
			pw = new PrintWriter(fw, true);

			for (String message : logData.getMessages()) {
				pw.println(message);
			}
		} catch (FileNotFoundException e) {
			throw new CodesUpdateException(
					"Failed to open log file for output ["
							+ logFile.getAbsolutePath() + "]", e);
		} catch (IOException e) {
			throw new CodesUpdateException("Failed to write log message", e);
		} finally {
			try {
				pw.close();
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return logFile;
	}

	/**
	 * Initialize the output log file.
	 * 
	 * @return the destination output log file
	 * @throws CodesUpdateException
	 *             if error creating output file
	 */
	private File initializeLogFile() throws CodesUpdateException {
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy-HHmmss");
		String timeStamp = sdf.format(new Date());
		String logFileName = "log-" + timeStamp + ".txt";
		File logFile = new File(CoreHelper.getTempLocation() + logFileName);
		logFile.deleteOnExit(); // cleanup upon program exit

		try {
			// create file if not exists
			logFile.createNewFile();
		} catch (IOException e) {
			throw new CodesUpdateException("Failed to open log file ["
					+ logFile.getAbsolutePath() + "]", e);
		}

		return logFile;
	}

	/**
	 * Formats the specified message in log format.
	 * 
	 * @param message
	 *            the String message
	 * @param level
	 *            the log level
	 * @return
	 */
	private String formatLogMessage(String message, final String level) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss");
		String timeStamp = sdf.format(new Date());
		message = timeStamp + " " + level + " " + message;
		return message;
	}
}
