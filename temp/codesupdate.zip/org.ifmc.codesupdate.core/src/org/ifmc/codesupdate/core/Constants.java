/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class Constants {

	public static final TableCodeMap tableCodeMap = new TableCodeMap();

	static {
		tableCodeMap.put(TableTypeEnum.CART_PROCEDURE, CodeTypeEnum.PROCEDURE);
		tableCodeMap.put(TableTypeEnum.CART_DIAGNOSIS, CodeTypeEnum.DIAGNOSIS);
		tableCodeMap.put(TableTypeEnum.CART_MEDICATION, CodeTypeEnum.CART_MEDICATION);

		tableCodeMap.put(TableTypeEnum.CPT, CodeTypeEnum.CPT);

		tableCodeMap.put(TableTypeEnum.OPPS_PROCEDURE, CodeTypeEnum.PROCEDURE);
		tableCodeMap.put(TableTypeEnum.OPPS_DIAGNOSIS, CodeTypeEnum.DIAGNOSIS);
		tableCodeMap.put(TableTypeEnum.OPPS_MEDICATION, CodeTypeEnum.OPPS_MEDICATION);
	}
}
