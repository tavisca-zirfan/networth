/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core;

/**
 * Enum that is used through out the application to represent types of Tables
 * that are currently supported by the application. When a new type is to be
 * supported it will need to be added to the this enum. This enum also tracks
 * the valid input file name and the CodeTypeEnum for the corresponding
 * TableTypeEnum.
 *
 * A TableTypeEnum associates a table type with the corresponding input data
 * file name and the code type of the codes associated with that table.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public enum TableTypeEnum {

	CART_PROCEDURE("cart_procedures.xls", CodeTypeEnum.PROCEDURE), CART_DIAGNOSIS(
			"cart_diagnoses.xls", CodeTypeEnum.DIAGNOSIS), CART_MEDICATION(
			"cart_medications.xls", CodeTypeEnum.CART_MEDICATION), OPPS_PROCEDURE(
			"opps_procedures.xls", CodeTypeEnum.PROCEDURE), OPPS_DIAGNOSIS(
			"opps_diagnoses.xls", CodeTypeEnum.DIAGNOSIS), OPPS_MEDICATION(
			"opps_medications.xls", CodeTypeEnum.OPPS_MEDICATION), CPT(
			"cpt.xls", CodeTypeEnum.CPT);

	public String inputFileName;
	public CodeTypeEnum codeTypeEnum;

	TableTypeEnum(final String inputFileName, final CodeTypeEnum codeTypeEnum) {
		this.inputFileName = inputFileName;
		this.codeTypeEnum = codeTypeEnum;
	}

	/**
	 * Given the input file name this method returns the corresponding
	 * TableTypeEnum.
	 *
	 * @param fileName
	 * @return
	 */
	public static TableTypeEnum getTableType(final String fileName) {
		for (TableTypeEnum type : TableTypeEnum.values()) {
			if (type.inputFileName.equals(fileName))
				return type;
		}
		return null;
	}

}
