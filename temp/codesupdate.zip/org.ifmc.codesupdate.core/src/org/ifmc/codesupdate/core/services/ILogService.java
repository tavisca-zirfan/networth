/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services;

import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.svn.client.exception.SVNClientException;

/**
 * ILogService provides methods for the logging facility.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public interface ILogService {

	/**
	 * Logs an information message to the in-memory log and the platform log.
	 * 
	 * @param message
	 *            the String message to be logged
	 */
	public void logInfo(String message);

	/**
	 * Returns all in-memory messages currently logged.
	 * 
	 * @return the List of log messages
	 */
	public List<String> getMessages();

	/**
	 * Clears all in-memory log messages.
	 */
	public void clearMessages();

	/**
	 * Writes the in-memory log messages to a file and commits the file to
	 * subversion.
	 * 
	 * @param revisionDate
	 *            the revision date associated with the log messages. The log
	 *            file is stored in the folder with this name
	 * @param svnClientService
	 *            handle to the subversion client
	 * @throws SVNClientException
	 *             if error commiting file to subversion
	 */
	public void commit(final Date revisionDate,
			final ISVNClientService svnClientService);

	/**
	 * Logs an error message to the in-memory log and the platform log.
	 * 
	 * @param message
	 *            the String message to be logged
	 * @param e
	 */
	public void logError(String message, Exception e);

	/**
	 * Logs an error message to the in-memory log and the platform log.
	 * 
	 * @param message
	 *            the String message to be logged
	 */
	public void logError(String message);
}
