/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services.impl;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.IEmailService;

/**
 * EmailService provides methods for processing email services.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class EmailService implements IEmailService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.core.services.IEmailService#sendSimpleEmail(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	public boolean sendSimpleEmail(final String fromAddress,
			final String toAddress, final String subject, final String message)
			throws CodesUpdateException {

		SimpleEmail email = new SimpleEmail();
		email.setHostName(CoreSettings.SMTP_SERVER);
		try {
			email.setFrom(fromAddress);
			email.setSubject(subject);
			email.setMsg(message);
			email.addTo(toAddress);
			try {
				email.send();
			} catch (EmailException e) {
				// query the EmailException to determine if mail server responds
				// with incorrect email address. Not all mail servers
				// configurations support this. SDPS GroupWise does however
				// support this.
				if (e.getCause().getMessage().equals("Invalid Addresses")) {
					// mail server responded with email address incorrect
					return false;
				} else {
					throw new CodesUpdateException("Failed sending email",
							e);
				}
			}
		} catch (EmailException e) {
			throw new CodesUpdateException("Failed sending email", e);
		}
		return true;
	}
}
