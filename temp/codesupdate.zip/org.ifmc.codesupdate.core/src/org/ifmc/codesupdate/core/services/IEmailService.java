/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services;

import org.ifmc.codesupdate.core.exception.CodesUpdateException;

/**
 * IEmailService provides methods for processing email services.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public interface IEmailService {

	/**
	 * Sends a simple email message.
	 * 
	 * @param fromAddress
	 *            the From address of the email
	 * @param toAddress
	 *            the To address of the email
	 * @param subject
	 *            the Subject of the email
	 * @param message
	 *            the Body of the email
	 * @return <code>true<code> if email sent successfully; <code>false<code> if invalid To address
	 * @throws CodesUpdateException if error while constructing or sending email
	 */
	boolean sendSimpleEmail(final String fromAddress, final String toAddress,
			final String subject, final String message)
			throws CodesUpdateException;

}