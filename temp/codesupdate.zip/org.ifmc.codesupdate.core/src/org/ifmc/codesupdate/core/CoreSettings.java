/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core;

import java.util.Date;
import java.util.Properties;
import org.ifmc.codesupdate.core.PropertyLoader;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CoreSettings {

	/**
	 * the From address of all outgoing email notifications
	 */
	public static final String FROM_EMAIL_ADDRESS;

	/**
	 * the SMTP relay server IP or hostname to use for all outgoing email
	 */
	public static final String SMTP_SERVER;

	/**
	 * the path to the temporary directory location
	 */
	public static final String TEMP_DIR_PATH;

	/**
	 * date to be used as HIGH DATE in the application
	 */
	public static final Date HIGH_DATE;

	/**
	 * the folder name to be used for the log files in subversion
	 */
	public static final String SVN_LOG_FOLDER_NAME;

	/**
	 * the folder name to be used for input files in subversion
	 */
	public static final String SVN_INPUT_FOLDER_NAME;

	static {
		// create and load default properties
		Properties defaultProps = PropertyLoader.loadProperties("coresettings");

		FROM_EMAIL_ADDRESS = defaultProps.getProperty("FROM_EMAIL_ADDRESS");
		SMTP_SERVER = defaultProps.getProperty("SMTP_SERVER");
		HIGH_DATE = CoreHelper.formatStringAsDate(defaultProps
				.getProperty("HIGH_DATE"));
		SVN_LOG_FOLDER_NAME = defaultProps.getProperty("SVN_LOG_FOLDER_NAME");
		SVN_INPUT_FOLDER_NAME = defaultProps
				.getProperty("SVN_INPUT_FOLDER_NAME");
		TEMP_DIR_PATH = defaultProps.getProperty("TEMP_DIR_PATH");
	}
}