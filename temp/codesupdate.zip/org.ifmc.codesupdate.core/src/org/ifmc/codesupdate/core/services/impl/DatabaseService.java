/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core.services.impl;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.dao.CodeDAO;
import org.ifmc.codesupdate.dao.CodeRevisionDAO;
import org.ifmc.codesupdate.dao.CodeTypeDAO;
import org.ifmc.codesupdate.dao.CodesUpdateDAOPlugin;
import org.ifmc.codesupdate.dao.CodesUpdateDBException;
import org.ifmc.codesupdate.dao.RevisionDAO;
import org.ifmc.codesupdate.dao.TableRevisionDAO;
import org.ifmc.codesupdate.dao.TableTypeDAO;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.codesupdate.dao.dt.Revision;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.dao.dt.TableType;
import org.ifmc.qms.hibernate.PersistenceException;
import org.ifmc.qms.hibernate.SearchException;

/**
 * Provides methods to manage data in the central database.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class DatabaseService implements IDatabaseService {

	CodeDAO cDao = new CodeDAO();

	CodeTypeDAO ctDao = new CodeTypeDAO();

	TableTypeDAO ttDao = new TableTypeDAO();

	RevisionDAO rDao = new RevisionDAO();

	CodeRevisionDAO crDao = new CodeRevisionDAO();

	TableRevisionDAO trDao = new TableRevisionDAO();

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#createCodeRevision
	 * (org.ifmc.codesupdate.dao.dt.Code, org.ifmc.codesupdate.dao.dt.Revision,
	 * java.lang.String)
	 */
	public CodeRevision createCodeRevision(final Code code,
			final Revision revision, final String description) {
		CodeRevision codeRevision = new CodeRevision(code, description,
				revision);
		try {
			crDao.save(codeRevision);
		} catch (PersistenceException pe) {
			throw new CodesUpdateDBException(pe);
		}
		return codeRevision;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findOrCreateType(
	 * java.lang.String)
	 */
	public CodeType findOrCreateCodeType(final String typeDescription) {
		CodeType codeType = ctDao.findByDescription(typeDescription);
		if (codeType == null) {
			codeType = new CodeType(typeDescription);
			try {
				ctDao.save(codeType);
			} catch (PersistenceException e) {
				throw new CodesUpdateDBException(e);
			}
		}
		return codeType;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findOrCreateType(
	 * java.lang.String)
	 */
	public TableType findOrCreateTableType(final String typeDescription) {
		TableType tableType = ttDao.findByDescription(typeDescription);
		if (tableType == null) {
			tableType = new TableType(typeDescription);
			try {
				ttDao.save(tableType);
			} catch (PersistenceException e) {
				throw new CodesUpdateDBException(e);
			}
		}
		return tableType;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findOrCreateCode(
	 * java.lang.String, org.ifmc.codesupdate.dao.dt.CodeType)
	 */
	public Code findOrCreateCode(final String key, final CodeType codeType) {
		// get the code from the database
		Code code = cDao.find(key, codeType);
		if (code == null) {
			code = new Code(key, codeType);
			try {
				cDao.save(code);
			} catch (PersistenceException pe) {
				throw new CodesUpdateDBException(pe);
			}
		}
		return code;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findOrCreateRevision
	 * (java.sql.Date)
	 */
	public Revision findOrCreateRevision(final Date revisionDate) {
		// get the revision from the database
		Revision revision = rDao.find(revisionDate, CoreSettings.HIGH_DATE);
		if (revision == null) {
			revision = createRevision(revisionDate);
		}
		return revision;
	}

	/**
	 * Creates a Revision with specified start date and HIGH DATE as end date.
	 *
	 * @param revisionDate
	 *            the start date of the revision
	 * @return the Revision
	 * @throws CodesUpdateCoreRuntimeException
	 *             if error creating the Revision
	 */
	private Revision createRevision(final Date revisionDate) {
		Revision revision = new Revision(revisionDate, CoreSettings.HIGH_DATE);
		try {
			rDao.save(revision);
		} catch (PersistenceException pe) {
			throw new CodesUpdateDBException(pe);
		}
		return revision;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findAllRevisions()
	 */
	public List<Revision> findAllRevisions() {
		try {
			List<Revision> revisions = rDao.find();
			return revisions;
		} catch (SearchException e) {
			throw new CodesUpdateDBException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findActiveCodeRevisions
	 * (org.ifmc.codesupdate.dao.dt.CodeType)
	 */
	public List<CodeRevision> findActiveCodeRevisions(final CodeType codeType) {

		return crDao.findActiveCodeRevisions(codeType, null,
				CoreSettings.HIGH_DATE);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findActiveCodeRevisions
	 * (java.lang.String, java.sql.Date)
	 */
	public List<CodeRevision> findActiveCodeRevisions(
			final String typeDescription, final Date revisionStartDate) {

		// retrieve the type from the database
		CodeType codeType = ctDao.findByDescription(typeDescription);

		return crDao.findActiveCodeRevisions(codeType, revisionStartDate,
				CoreSettings.HIGH_DATE);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findExpiredCodeRevisions
	 * (java.lang.String, java.sql.Date)
	 */
	public List<CodeRevision> findExpiredCodeRevisions(
			final String typeDescription, final Date revisionDate) {

		// retrieve the type from the database
		CodeType codeType = ctDao.findByDescription(typeDescription);

		return crDao.findExpiredCodeRevisions(codeType, revisionDate);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#expireCodeRevision
	 * (org.ifmc.codesupdate.dao.dt.CodeRevision,
	 * org.ifmc.codesupdate.dao.dt.Revision, java.util.List)
	 */
	public CodeRevision expireCodeRevision(final CodeRevision codeRevision,
			final Date expireRevisionDate, final List<Revision> allRevisions)
			throws CodesUpdateException {

		// code's currently active revision
		Revision activeRevision = codeRevision.getRevision();

		// endDate of activeRevision must be = HIGH_DATE
		if (activeRevision.getEndDate().compareTo(CoreSettings.HIGH_DATE) != 0)
			throw new CodesUpdateException(
					"Illegal operation attempting to expire an already expired code revision.");

		// expireRevisionDate must be > startDate of activeRevision
		if (expireRevisionDate.compareTo(activeRevision.getStartDate()) < 0)
			throw new CodesUpdateException(
					"Current revision date is before the start date of code's active revision.");

		// set the start date for expired revision to the start date of the
		// activeRevision
		Date expiredRevisionStartDate = activeRevision.getStartDate();

		// end date for expired revision is day before expireRevisionDate
		Date expiredRevisionEndDate = CoreHelper
				.getDateBefore(expireRevisionDate);

		// lookup revision exists in allRevisions list
		Revision expireRevision = CoreHelper.lookupRevisionInList(
				expiredRevisionStartDate, expiredRevisionEndDate, allRevisions);

		if (expireRevision == null) {
			// revision doesn't exist in DB yet...so create new object
			// need to add to allRevisions else we loose it!
			expireRevision = new Revision(expiredRevisionStartDate,
					expiredRevisionEndDate);
			allRevisions.add(expireRevision);
		}

		// expire the active code revision
		codeRevision.setRevision(expireRevision);

		try {
			crDao.save(codeRevision);
		} catch (PersistenceException pe) {
			throw new CodesUpdateDBException(pe);
		}

		return codeRevision; // the now expired Code Revision

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#unExpireCodeRevisions
	 * (java.util.List)
	 */
	public void unExpireCodeRevisions(
			final List<CodeRevision> expiredCodeRevisions) {

		if (expiredCodeRevisions.isEmpty())
			return;

		List<Revision> allRevisions = findAllRevisions();

		// modify Code Revisions iteratively
		for (CodeRevision expiredCodeRevision : expiredCodeRevisions) {

			// lookup revision exists in allRevisions list
			Revision activeRevision = CoreHelper.lookupRevisionInList(
					expiredCodeRevision.getRevision().getStartDate(),
					CoreSettings.HIGH_DATE, allRevisions);

			if (activeRevision == null) {
				// revision doesn't exist in DB yet...so create new object
				// need to add to allRevisions else we loose it!
				activeRevision = new Revision(expiredCodeRevision.getRevision()
						.getStartDate(), CoreSettings.HIGH_DATE);
				allRevisions.add(activeRevision);
			}

			// expire the active code revision
			expiredCodeRevision.setRevision(activeRevision);

		}
		// mass update Code Revisions
		update(expiredCodeRevisions
				.toArray(new CodeRevision[expiredCodeRevisions.size()]));
	}

	/**
	 * Updates the list of Code Revisions within a single transaction.
	 *
	 * @param codeRevisions
	 *            the list of Code Revisions
	 * @throws CodesUpdateDBException
	 *             if session or trasaction error
	 */
	private void update(final CodeRevision[] codeRevisions)
			throws CodesUpdateDBException {
		// if entities is empty or full of nulls, just return
		if (isEmpty(codeRevisions))
			return;

		Session session = null;
		Transaction transaction = null;
		try {
			session = CodesUpdateDAOPlugin.getDefault().getSessionFactory()
					.openSession();
			transaction = session.beginTransaction();
			for (CodeRevision entity : codeRevisions) {
				if (entity != null) {
					session.update(entity);
				}
			}

			transaction.commit();
		} catch (Throwable e) {
			throw new CodesUpdateDBException(e);
		} finally {
			if ((transaction != null) && !transaction.wasCommitted()) {
				transaction.rollback();
			}
			if (session != null) {
				session.close();
			}
		}
	}

	/**
	 * Updates the list of Code Revisions within a single transaction.
	 *
	 * @param codeRevisions
	 *            the list of Code Revisions
	 * @throws CodesUpdateDBException
	 *             if session or trasaction error
	 */
	private void update(final TableRevision[] tableRevisions)
			throws CodesUpdateDBException {

		// TODO use Generics
		// if entities is empty or full of nulls, just return
		if (isEmpty(tableRevisions))
			return;

		Session session = null;
		Transaction transaction = null;
		try {
			session = CodesUpdateDAOPlugin.getDefault().getSessionFactory()
					.openSession();
			transaction = session.beginTransaction();
			for (TableRevision entity : tableRevisions) {
				if (entity != null) {
					session.update(entity);
				}
			}

			transaction.commit();
		} catch (Throwable e) {
			throw new CodesUpdateDBException(e);
		} finally {
			if ((transaction != null) && !transaction.wasCommitted()) {
				transaction.rollback();
			}
			if (session != null) {
				session.close();
			}
		}
	}

	private boolean isEmpty(final CodeRevision[] codeRevisions) {
		if (codeRevisions.length == 0)
			return true;

		for (CodeRevision cr : codeRevisions) {
			if (cr != null)
				return false;
		}

		return true;
	}

	private boolean isEmpty(final TableRevision[] tableRevisions) {
		// TODO use generics...move to helper class
		if (tableRevisions.length == 0)
			return true;

		for (TableRevision tr : tableRevisions) {
			if (tr != null)
				return false;
		}

		return true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#deleteCodeRevisions
	 * (java.util.List)
	 */
	public void deleteCodeRevisions(final List<CodeRevision> codeRevisions)
			throws CodesUpdateDBException {

		if (codeRevisions.isEmpty())
			return;

		CodeRevision[] codeRevisionsArray = new CodeRevision[codeRevisions
				.size()];
		codeRevisions.toArray(codeRevisionsArray);

		try {
			crDao.delete(codeRevisionsArray);
		} catch (PersistenceException e) {
			throw new CodesUpdateDBException(e);
		}
	}

	public List<TableRevision> findActiveTableRevisions(
			final TableType tableType) {
		return trDao.findActiveTableRevisions(tableType, null,
				CoreSettings.HIGH_DATE);
	}

	public TableRevision createTableRevision(final Table table,
			final Revision revision, final Set<CodeRevision> codeRevisions) {
		TableRevision tableRevision = new TableRevision(table, codeRevisions,
				revision);
		try {
			trDao.save(tableRevision);
		} catch (PersistenceException pe) {
			throw new CodesUpdateDBException(pe);
		}
		return tableRevision;
	}

	public TableRevision expireTableRevision(final TableRevision tableRevision,
			final Date expireRevisionDate, final List<Revision> allRevisions) {
		// table's currently active revision
		Revision activeRevision = tableRevision.getRevision();

		// endDate of activeRevision must be = HIGH_DATE
		if (activeRevision.getEndDate().compareTo(CoreSettings.HIGH_DATE) != 0)
			throw new CodesUpdateException(
					"Illegal operation attempting to expire an already expired table revision.");

		// expireRevisionDate must be > startDate of activeRevision
		if (expireRevisionDate.compareTo(activeRevision.getStartDate()) < 0)
			throw new CodesUpdateException(
					"Current revision date is before the start date of table's active revision.");

		// set the start date for expired revision to the start date of the
		// activeRevision
		Date expiredRevisionStartDate = activeRevision.getStartDate();

		// end date for expired revision is day before expireRevisionDate
		Date expiredRevisionEndDate = CoreHelper
				.getDateBefore(expireRevisionDate);

		// lookup revision exists in allRevisions list
		Revision expireRevision = CoreHelper.lookupRevisionInList(
				expiredRevisionStartDate, expiredRevisionEndDate, allRevisions);

		if (expireRevision == null) {
			// revision doesn't exist in DB yet...so create new object
			// need to add to allRevisions else we loose it!
			expireRevision = new Revision(expiredRevisionStartDate,
					expiredRevisionEndDate);
			allRevisions.add(expireRevision);
		}

		// expire the active code revision
		tableRevision.setRevision(expireRevision);

		try {
			trDao.save(tableRevision);
		} catch (PersistenceException pe) {
			throw new CodesUpdateDBException(pe);
		}

		return tableRevision; // the now expired Table Revision

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findActiveTableRevisions
	 * (java.lang.String, java.sql.Date)
	 */
	public List<TableRevision> findActiveTableRevisions(
			final String typeDescription, final Date revisionStartDate) {
		// retrieve the type from the database
		TableType tableType = ttDao.findByDescription(typeDescription);

		return trDao.findActiveTableRevisions(tableType, revisionStartDate,
				CoreSettings.HIGH_DATE);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#deleteTableRevisions
	 * (java.util.List)
	 */
	public void deleteTableRevisions(final List<TableRevision> tableRevisions) {

		if (tableRevisions.isEmpty())
			return;

		TableRevision[] tableRevisionsArray = new TableRevision[tableRevisions
				.size()];
		tableRevisions.toArray(tableRevisionsArray);

		try {
			trDao.delete(tableRevisionsArray);
		} catch (PersistenceException e) {
			throw new CodesUpdateDBException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.ifmc.codesupdate.core.services.IDatabaseService#findExpiredTableRevisions
	 * (java.lang.String, java.sql.Date)
	 */
	public List<TableRevision> findExpiredTableRevisions(
			final String typeDescription, final Date revisionDate) {

		TableType tableType = ttDao.findByDescription(typeDescription);

		return trDao.findExpiredTableRevisions(tableType, revisionDate);

	}

	public void unExpireTableRevisions(
			final List<TableRevision> expiredTableRevisions) {
		if (expiredTableRevisions.isEmpty())
			return;

		List<Revision> allRevisions = findAllRevisions();

		// modify Code Revisions iteratively
		for (TableRevision expiredTableRevision : expiredTableRevisions) {

			// lookup revision exists in allRevisions list
			Revision activeRevision = CoreHelper.lookupRevisionInList(
					expiredTableRevision.getRevision().getStartDate(),
					CoreSettings.HIGH_DATE, allRevisions);

			if (activeRevision == null) {
				// revision doesn't exist in DB yet...so create new object
				// need to add to allRevisions else we loose it!
				activeRevision = new Revision(expiredTableRevision
						.getRevision().getStartDate(), CoreSettings.HIGH_DATE);
				allRevisions.add(activeRevision);
			}

			// expire the active code revision
			expiredTableRevision.setRevision(activeRevision);

		}
		// mass update Table Revisions
		update(expiredTableRevisions
				.toArray(new TableRevision[expiredTableRevisions.size()]));

	}

	public CodeRevision findActiveCodeRevision(final Code code) {
		return crDao.findActiveCodeRevision(code.getKey(), code.getCodeType(),
				CoreSettings.HIGH_DATE);
	}

}