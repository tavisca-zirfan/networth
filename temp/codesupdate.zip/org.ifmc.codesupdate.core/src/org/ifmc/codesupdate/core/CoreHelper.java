/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.core;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import org.eclipse.core.runtime.Platform;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.dao.dt.Revision;

/**
 * Helper methods.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public final class CoreHelper {

	private CoreHelper() {
	} // not extensible

	/**
	 * Takes a date of format MM/dd/yyyy and returns a string formatted as
	 * MM-dd-yyyy. Ex: 01/01/2008 is formatted as 01-01-2008.
	 * 
	 * @param date
	 *            the date to be formatted
	 * @return the formattted date as a String
	 */
	public static String formatDateAsString(final Date date) {

		final String DATE_FORMAT = "MM-dd-yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, Locale.US);
		String strDate = sdf.format(date);

		return strDate;

	}

	/**
	 * Takes a string of format MM-dd-yyyy and returns a date formatted as
	 * MM-dd-yyyy. Ex: 01-01-2008 is formatted as 01-01-2008.
	 * 
	 * @param strDate
	 *            the date to be formatted
	 * @return the formattted date as a String
	 * @throws CodesUpdateException
	 */
	public static Date formatStringAsDate(final String strDate)
			throws CodesUpdateException {

		try {
			return new SimpleDateFormat("MM-dd-yy", Locale.US).parse(strDate);
		} catch (ParseException e) {
			throw new CodesUpdateException(e);
		}
	}

	/**
	 * Returns the date before the given date.
	 * 
	 * @param date
	 *            the Date
	 * @return the date before the given date
	 */
	public static Date getDateBefore(final Date date) {

		long dayInMillis = 1000 * 60 * 60 * 24;
		// subtract a day
		long dateMillis = date.getTime() - dayInMillis;

		return new Date(dateMillis);
	}

	/**
	 * Returns the path to the input files destination in subversion.
	 * 
	 * @param revisionDate
	 *            the revision date
	 * @return the path to the input files destination
	 */
	public static String formatInputDestination(final Date revisionDate) {
		String inputFolderName = CoreSettings.SVN_INPUT_FOLDER_NAME;
		String inputFolderPath = formatDateAsString(revisionDate) + "/"
				+ inputFolderName;
		return inputFolderPath;
	}

	/**
	 * Returns the path to the log files destination in subversion.
	 * 
	 * @param revisionDate
	 *            the revision date
	 * @return the path to the log files destination
	 */
	public static String formatLogDestination(final Date revisionDate) {
		String logFolderName = CoreSettings.SVN_LOG_FOLDER_NAME;
		String logFolderPath = formatDateAsString(revisionDate) + "/"
				+ logFolderName;
		return logFolderPath;
	}

	/**
	 * Returns the path to temporary location.
	 * 
	 * @return the path to temporary location
	 */
	public static String getTempLocation() {
		String tempDirPath = Platform.getInstallLocation().getURL().getFile()
				+ CoreSettings.TEMP_DIR_PATH;
		File tempDir = new File(tempDirPath);
		@SuppressWarnings("unused")
		boolean result = tempDir.mkdirs();
		return tempDirPath;
	}

	/**
	 * Returns a Revision from the list of Revisions which matches the
	 * revisionStartDate and revisionEndDate.
	 * 
	 * @param startDate
	 *            the start date of the revision
	 * @param endDate
	 *            the end date of the revision
	 * @param revisions
	 *            the list of revisions to search in
	 * @return the Revision that has start date as revisionStartDate and end
	 *         date as reivsionEndDate; <code>null</code> if not found
	 */
	public static Revision lookupRevisionInList(final Date startDate,
			final Date endDate, final List<Revision> revisions) {
		Revision lookup = new Revision(startDate, endDate);
		Revision revision = null;
		try {
			revision = revisions.get(revisions.indexOf(lookup));
		} catch (Exception ignore) {
			// lookup object not found...return null
		}
		return revision;
	}

	/**
	 * Parses a String by splitting it with any of the specified delimiters and
	 * returning an array of the results.
	 * 
	 * @param input
	 *            the delimited String
	 * @param delimiter
	 *            the delimiter to be used in splitting the input
	 * @return
	 */
	public static String[] parseString(final String input,
			final String delimiters) {
		StringTokenizer tokenizer = new StringTokenizer(input, delimiters);
		List<String> list = new ArrayList<String>();
		while (tokenizer.hasMoreElements()) {
			list.add((String) tokenizer.nextElement());
		}
		return (String[]) list.toArray(new String[list.size()]);
	}
}
