/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.helper;

import java.io.File;
import java.util.Date;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class RepositoryFile {

	private File file;

	private Date revisionDate;

	public RepositoryFile(final File file, final Date revisionDate) {
		this.file = file;
		this.revisionDate = revisionDate;
	}

	public File getFile() {
		return file;
	}

	public void setFile(final File file) {
		this.file = file;
	}

	public Date getRevisionDate() {
		return revisionDate;
	}

	public void setRevisionDate(final Date revisionDate) {
		this.revisionDate = revisionDate;
	}

}
