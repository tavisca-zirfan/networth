/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.revisioner.impl.WhDbTablesRevisioner;
import org.ifmc.codesupdate.revisioner.impl.XMLTablesRevisioner;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class TablesRevisioner extends AbstractRevisioner {

	/**
	 * the CodeTypeEnum of the input Code Revisions
	 */
	private final TableTypeEnum tableTypeEnum;

	private final List<TableRevision> expiredTableRevisions;

	private final List<TableRevision> activeTableRevisions;

	private final List<TableRevision> revisedTableRevisions = new ArrayList<TableRevision>();

	public TablesRevisioner(final TableTypeEnum tableTypeEnum,
			final Date revisionDate,
			final List<TableRevision> expiredTableRevisions,
			final List<TableRevision> activeTableRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {
		super(revisionDate, notificationEmailAddressList,
				svnClientService, logService, emailService);

		this.tableTypeEnum = tableTypeEnum;
		this.expiredTableRevisions = expiredTableRevisions;
		this.activeTableRevisions = activeTableRevisions;

		createRevisedTableRevisions(activeTableRevisions,
				revisedTableRevisions, expiredTableRevisions);

	}

	private void createRevisedTableRevisions(
			final List<TableRevision> activeTableRevisions,
			final List<TableRevision> revisedTableRevisions,
			final List<TableRevision> expiredTableRevisions) {

		// get the intersection of codes in expired and active code revisions to
		// get the set of codes revised in this revision
		for (TableRevision expiredTableRevision : expiredTableRevisions) {

			// check if expired Table Revision's table exists in the list of
			// active Table Revisions
			TableRevision activeTableRevision = lookup(expiredTableRevision
					.getTable(), activeTableRevisions);

			if (activeTableRevision != null) {
				// add to the list of revised tables
				revisedTableRevisions.add(activeTableRevision);

				// remove from the list of active table
				// revisions to prevent duplicate processing
				activeTableRevisions.remove(activeTableRevision);

			}
		}

		// now clean up revisedtables from the expiredTableRevisions
		for (TableRevision revisedTableRevision : revisedTableRevisions) {
			removeFromList(revisedTableRevision, expiredTableRevisions);
		}

	}

	private void removeFromList(final TableRevision tableRevision,
			final List<TableRevision> tableRevisions) {
		int i = 0;
		while (!tableRevisions.isEmpty()) {
			TableRevision tr = tableRevisions.get(i);
			if (tr.getTable().getKey()
					.equals(tableRevision.getTable().getKey())) {
				tableRevisions.remove(tr);
				return;
			}
			i++;
		}
	}

	private TableRevision lookup(final Table table, final List<TableRevision> tableRevisions) {
		for (TableRevision tr : tableRevisions) {
			if (tr.getTable().getKey().equals(table.getKey()))
				return tr;
		}
		return null;
	}

	@Override
	protected void addRevisionersToList() {
		revisioners.add(new XMLTablesRevisioner(tableTypeEnum, revisionDate,
				activeTableRevisions, revisedTableRevisions,
				expiredTableRevisions, notificationEmailAddressList,
				svnClientService, logService, emailService));

		revisioners.add(new WhDbTablesRevisioner(tableTypeEnum, revisionDate,
				activeTableRevisions, revisedTableRevisions,
				expiredTableRevisions, notificationEmailAddressList,
				svnClientService, logService, emailService));
	}

}
