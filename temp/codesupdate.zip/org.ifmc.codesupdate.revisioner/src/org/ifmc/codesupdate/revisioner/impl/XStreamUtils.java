/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.ifmc.qms.lookup.data.objects.Code;
import org.ifmc.qms.lookup.data.objects.LookupObject;
import org.ifmc.qms.lookup.data.objects.Table;
import org.ifmc.qms.lookup.resource.reader.CodeConverter;
import org.ifmc.qms.lookup.resource.reader.ReferenceByPersistIdMarshallingStrategy;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.core.util.ObjectIdDictionary;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class XStreamUtils {
	static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";

	static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";

	public static XStreamUtils INSTANCE = new XStreamUtils();

	private Map<String, Map<String, Object>> references = null;

	private XStreamUtils() {
		references = new HashMap<String, Map<String, Object>>();
	}

	@SuppressWarnings("unchecked")
	public synchronized List<Code> loadCodes(final URL xsd, final URL url, final Map aliasMap,
			final String type) {
		return (List<Code>) loadLookupResource(xsd, url, aliasMap, type);
	}

	private Map<String, Object> retrieveTypeOfReferences(final String type) {
		if (references.get(type) == null) {
			references.put(type, new HashMap<String, Object>());
		}
		return references.get(type);
	}

	@SuppressWarnings("unchecked")
	public synchronized List<Table> loadTables(final URL xsd, final URL url, final Map aliasMap,
			final String type) {
		List<Table> temp = (List<Table>) loadLookupResource(xsd, url, aliasMap,
				type);
		// destroyTypeOfReferences(type);
		return temp;
	}

	@SuppressWarnings("unchecked")
	public synchronized List<? extends LookupObject> loadLookupResource(
			final URL xsd, final URL url, final Map aliasMap, final String type) {
		try {

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));

			XStream xtrm = new XStream();
			Iterator aliasList = aliasMap.keySet().iterator();
			while (aliasList.hasNext()) {
				String alias = (String) aliasList.next();
				xtrm.alias(alias, (Class) aliasMap.get(alias));
			}

			xtrm.registerConverter(new CodeConverter());
			ReferenceByPersistIdMarshallingStrategy strategy = new ReferenceByPersistIdMarshallingStrategy();

			// set the marshalling references if available.
			// This will contain all references from previous read.
			Map<String, Object> typeOfReferences = retrieveTypeOfReferences(type);
			strategy.setUnMarshallingReferences(typeOfReferences);
			xtrm.setMarshallingStrategy(strategy);
			return ((List<? extends LookupObject>) xtrm.fromXML(reader));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/* Destroy the cache as it is not required. */
	public void destroyTypeOfReferences(final String type) {
		references.get(type).clear();
		references.remove(type);
	}

	@SuppressWarnings("unchecked")
	public void writerXMLData(final Writer writer, final List data, final String type,
			final boolean isTablesFile) {
		XStream xtrm = new XStream();
		xtrm.alias("code", Code.class);
		xtrm.alias("table", Table.class);
		xtrm.alias("list", ArrayList.class);
		xtrm.registerConverter(new CodeConverter());
		if (isTablesFile) {
			ReferenceByPersistIdMarshallingStrategy strategy = new ReferenceByPersistIdMarshallingStrategy();
			// set the marshaling references if available.
			strategy
					.setMarshallingReferences(createMarshallingReferences(type));
			xtrm.setMarshallingStrategy(strategy);
		}

		xtrm.toXML(data, writer);
	}

	private ObjectIdDictionary createMarshallingReferences(final String type) {
		ObjectIdDictionary oidDict = new ObjectIdDictionary();
		Set<String> types = references.keySet();
		for (String aCodeType : types) {
			if (aCodeType.equals(type)) {
				Map<String, Object> allCodesForType = references.get(type);
				Set<String> codePersistIds = allCodesForType.keySet();
				for (String aCodePersistId : codePersistIds) {
					if (allCodesForType.get(aCodePersistId) instanceof Code) {
						oidDict.associateId(
								allCodesForType.get(aCodePersistId),
								aCodePersistId);
					} else {
						System.out.println("Missing " + aCodePersistId);
					}
				}
			}
		}
		return oidDict;
	}
}
