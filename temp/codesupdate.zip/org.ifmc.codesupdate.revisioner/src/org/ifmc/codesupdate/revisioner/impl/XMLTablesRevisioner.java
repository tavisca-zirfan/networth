/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.revisioner.helper.RepositoryFile;
import org.ifmc.codesupdate.revisioner.helper.RevisionerHelper;
import org.ifmc.codesupdate.revisioner.helper.XMLHelper;
import org.ifmc.qms.lookup.data.objects.Code;
import org.ifmc.qms.lookup.data.objects.Table;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class XMLTablesRevisioner extends AbstractTablesRevisioner {

	/**
	 * holds the map between code type and output file name
	 */
	private static Map<String, String> xmlFilesMap = new HashMap<String, String>();

	/**
	 * holds the map between code type and output file name
	 */
	private static Map<String, String> codesXMLFilesMap = new HashMap<String, String>();

	static {
		xmlFilesMap.put(TableTypeEnum.CART_DIAGNOSIS.toString(),
				"cart_diagnosis.tables");
		xmlFilesMap.put(TableTypeEnum.CART_PROCEDURE.toString(),
				"cart_procedures.tables");
		xmlFilesMap.put(TableTypeEnum.CART_MEDICATION.toString(),
				"cart_medications.tables");

		xmlFilesMap.put(TableTypeEnum.OPPS_DIAGNOSIS.toString(),
				"opps_diagnosis.tables");
		xmlFilesMap.put(TableTypeEnum.OPPS_PROCEDURE.toString(),
				"opps_procedures.tables");
		xmlFilesMap.put(TableTypeEnum.OPPS_MEDICATION.toString(),
				"opps_medications.tables");

		xmlFilesMap.put(TableTypeEnum.CPT.toString(), "cpt.tables");

		codesXMLFilesMap.put(CodeTypeEnum.DIAGNOSIS.toString(),
				"diagnosis.codes");
		codesXMLFilesMap.put(CodeTypeEnum.PROCEDURE.toString(),
				"procedures.codes");
		codesXMLFilesMap.put(CodeTypeEnum.CART_MEDICATION.toString(),
				"cart_medications.codes");
		codesXMLFilesMap.put(CodeTypeEnum.OPPS_MEDICATION.toString(),
				"opps_medications.codes");
		codesXMLFilesMap.put(CodeTypeEnum.CPT.toString(), "cpt.codes");
	}

	public XMLTablesRevisioner(final TableTypeEnum tableTypeEnum,
			final Date revisionDate,
			final List<TableRevision> newTableRevisions,
			final List<TableRevision> revisedTableRevisions,
			final List<TableRevision> expiredTableRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {

		super(tableTypeEnum, revisionDate, newTableRevisions,
				revisedTableRevisions, expiredTableRevisions,
				notificationEmailAddressList, svnClientService, logService,
				emailService);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.ifmc.codesupdate.revisioner.IRevisioner#revise(java.util.List,
	 * java.util.List, java.util.List, org.ifmc.codesupdate.core.CodeTypeEnum,
	 * java.util.Date, java.lang.String,
	 * org.ifmc.codesupdate.core.services.ISVNClientService,
	 * org.ifmc.codesupdate.core.services.ILogService,
	 * org.ifmc.codesupdate.core.services.IEmailService,
	 * org.ifmc.codesupdate.core.WorkData)
	 */
	public void revise(final WorkData workData)
			throws CodesUpdateRevisionerException {

		// input file from latest available revision
		String fileName = xmlFilesMap.get(tableTypeEnum.toString());

		try {
			workData.setCurrentSubTask("Generating output file " + fileName);

			logService
					.logInfo("Attempting to checkout most recent XML revision for "
							+ tableTypeEnum.toString() + " tables");
			// retrieve the XML file from subversion for the last revision
			RepositoryFile repositoryFile = XMLHelper.fetchLatestXMLFile(
					fileName, revisionDate, svnClientService, false);

			if (repositoryFile == null)
				throw new CodesUpdateRevisionerException(
						"XML Revisioner - Failed to checkout previous version of "
								+ fileName);
			else {
				logService.logInfo("Succeeded retrieving XML Tables for "
						+ tableTypeEnum.toString()
						+ " from "
						+ CoreHelper.formatDateAsString(repositoryFile
								.getRevisionDate()));
			}

			File xmlInputFile = repositoryFile.getFile();

			logService.logInfo("Attempting to update XML file for "
					+ tableTypeEnum.toString() + " tables");
			File xmlOutputFile;
			try {
				xmlOutputFile = reviseFile(xmlInputFile, fileName);
			} catch (CodesUpdateRevisionerException e) {
				throw new CodesUpdateRevisionerException("Failed to revise "
						+ fileName + " by XMLCodesRevisioner.", e);
			}
			logService.logInfo("Succeeded updating XML file for "
					+ tableTypeEnum.toString() + " tables");

			logService.logInfo("Attempting to checkin updated XML file for "
					+ tableTypeEnum.toString() + " tables for revision "
					+ CoreHelper.formatDateAsString(revisionDate));
			try {
				XMLHelper
						.checkin(xmlOutputFile, revisionDate, svnClientService);
			} catch (CodesUpdateRevisionerException e) {
				throw new CodesUpdateRevisionerException(
						"Failed to checkin revised version of " + fileName
								+ " by XMLCodesRevisioner.", e);
			}
			logService.logInfo("Succeeded checking in XML file for "
					+ tableTypeEnum.toString() + " tables for revision "
					+ CoreHelper.formatDateAsString(revisionDate));
			RevisionerHelper.sendSuccessEmail(notificationEmailAddressList,
					fileName, tableTypeEnum.toString(), logService,
					emailService);

			workData.worked(1);

		} catch (CodesUpdateRevisionerException e) {
			RevisionerHelper.sendFailureEmail(notificationEmailAddressList,
					fileName, logService, emailService);
			throw e;
		}
	}

	private File reviseFile(final File xmlInputFile, final String outputFileName) {

		// as input we also need the persistIds in the updated codes file for
		// this revision
		// retrieve the XML file from subversion for the last revision
		File codesXMLInputFile = fetchCodesXMLFile();

		// codes from the XML file
		// this is required in order for XStreamUtils to correlate the codes to
		// the tables which we will load right after
		List<org.ifmc.qms.lookup.data.objects.Code> masterXMLCodes = XMLHelper
				.readCodesFromInputXMLFile(codesXMLInputFile, tableTypeEnum
						.toString());
		// filter codes by revision date
		List<org.ifmc.qms.lookup.data.objects.Code> filteredXMLCodes = XMLHelper
				.filterXMLCodes(masterXMLCodes, revisionDate);

		// this is the XML file
		List<Table> masterXMLTables = XMLHelper.readTablesFromInputXMLFile(
				xmlInputFile, tableTypeEnum);
		// Filter tables by revision date
		List<Table> filteredXMLTables = XMLHelper.filterXMLTables(
				masterXMLTables, revisionDate);

		// expire all expired table revisions
		expireTableRevisions(filteredXMLTables);

		// add all new table revisions
		addNewTableRevisions(masterXMLTables, filteredXMLCodes);

		// revise all revised table revisions
		reviseTableRevisions(masterXMLTables, filteredXMLTables,
				filteredXMLCodes);

		// write tables
		File xmlOutputFile = new File(CoreHelper.getTempLocation()
				+ outputFileName);
		xmlOutputFile.deleteOnExit(); // make sure to cleanup

		XMLHelper.writeTablesToFile(masterXMLTables, xmlOutputFile,
				tableTypeEnum
				.toString());
		return xmlOutputFile;
	}

	private void reviseTableRevisions(final List<Table> masterXMLTables,
			final List<Table> activeXMLTables, final List<Code> activeXMLCodes) {
		for (TableRevision tr : revisedTableRevisions) {

			String key = tr.getTable().getKey();
			if ((tableTypeEnum == TableTypeEnum.CPT)
					|| (tableTypeEnum == TableTypeEnum.OPPS_DIAGNOSIS)
					|| (tableTypeEnum == TableTypeEnum.OPPS_MEDICATION)) {
				key = "OP" + key;
			}

			// first, expire this table from the active list
			Table t1 = findInXMLTableList(activeXMLTables, key);

			if (t1 != null) {
				t1.setEndDate(CoreHelper.formatDateAsString(CoreHelper
						.getDateBefore(revisionDate)));

				List<Code> codes = getXMLCodes(tr.getCodeRevisions(),
						activeXMLCodes);

				// create a new table
				Table newT = createNewTable(key, codes, revisionDate,
						CoreSettings.HIGH_DATE);

				masterXMLTables.add(newT);
			} else {
				logService.logError("Table missing in tables file ["
						+ tr.getTable().getKey() + "]");
			}
		}

	}

	private Table findInXMLTableList(final List<Table> tables, final String key) {
		for (Table table : tables) {
			if (table.getName().compareTo(key) == 0)
				return table;
		}
		return null;
	}

	private void addNewTableRevisions(final List<Table> masterXMLTables,
			final List<Code> activeXMLCodes) {

		for (TableRevision tr : newTableRevisions) {
			String key = tr.getTable().getKey();

			List<Code> codes = getXMLCodes(tr.getCodeRevisions(),
					activeXMLCodes);
			if ((tableTypeEnum == TableTypeEnum.CPT)
					|| (tableTypeEnum == TableTypeEnum.OPPS_DIAGNOSIS)
					|| (tableTypeEnum == TableTypeEnum.OPPS_MEDICATION)) {
				key = "OP" + key;
			}
			Table newT = createNewTable(key, codes, revisionDate,
					CoreSettings.HIGH_DATE);

			masterXMLTables.add(newT);
		}
	}

	/**
	 * Lookup corresponding XML Codes from the given codeRevisions.
	 *
	 * @param codeRevisions
	 * @param xmlCodes
	 * @return
	 */
	private List<Code> getXMLCodes(final Set<CodeRevision> codeRevisions,
			final List<Code> xmlCodes) {

		List<Code> codes = new ArrayList<Code>();
		for (CodeRevision cr : codeRevisions) {

			Code c = XMLHelper.findInXMLCodeList(xmlCodes, cr.getCode()
					.getKey());

			// Code c1 = new Code();
			// // only persistId should make it to the XML file
			// // as "reference" attribute
			// c1.setData("reference", c.getData(Code.persistId));

			codes.add(c);
		}
		return codes;
	}

	/**
	 * @throws CodesUpdateRevisionerException
	 */
	private File fetchCodesXMLFile() {

		// retrieve the latest available Codes XML file
		String fileName = codesXMLFilesMap.get(tableTypeEnum.codeTypeEnum
				.toString());

		RepositoryFile repositoryFile = XMLHelper.fetchLatestXMLFile(fileName,
				revisionDate, svnClientService, true);

		if (repositoryFile == null)
			throw new CodesUpdateRevisionerException(
					"XML Revisioner - Failed to checkout previous version of "
							+ fileName);
		else {
			logService.logInfo("Succeeded retrieving XML Codes for "
					+ tableTypeEnum.toString()
					+ " from "
					+ CoreHelper.formatDateAsString(repositoryFile
							.getRevisionDate()));
		}

		return repositoryFile.getFile();
	}

	private Table createNewTable(final String key, final List<Code> codes,
			final Date startDate, final Date date) {

		Table newT = new Table();
		newT.setId(UUID.randomUUID().toString());
		newT.setName(key);
		newT.setStartDate(CoreHelper.formatDateAsString(startDate));
		newT.setEndDate(CoreHelper.formatDateAsString(date));
		for (Code code : codes) {
			newT.addCode(code);
		}

		return newT;
	}

	private void expireTableRevisions(final List<Table> activeXMLTables) {

		// avoid unncessary looping if there are 0 expired tables
		if (expiredTableRevisions.isEmpty())
			return;

		Map<String, Table> activeXMLTableMap = new HashMap<String, Table>();
		for (Table t : activeXMLTables) {
			activeXMLTableMap.put(t.getName().trim(), t);
		}

		Collection<String> expiredTableKeys = getTableKeys(expiredTableRevisions);

		for (String expiredTableKey : expiredTableKeys) {
			if ((tableTypeEnum == TableTypeEnum.CPT)
					|| (tableTypeEnum == TableTypeEnum.OPPS_DIAGNOSIS)
					|| (tableTypeEnum == TableTypeEnum.OPPS_MEDICATION)) {
				expiredTableKey = "OP" + expiredTableKey;
			}
			if (activeXMLTableMap.containsKey(expiredTableKey)) {
				// activeXMLTable is in the list of expired codes
				// so expire it in the list of masterXMLTables
				Date newExpDate = CoreHelper.getDateBefore(revisionDate);
				Table t = activeXMLTableMap.get(expiredTableKey);
				t.setEndDate(CoreHelper.formatDateAsString(newExpDate));
			}
		}

		// loop through all active tabes in the XML file
		// for (Table t : activeXMLTables) {
		//
		// if (expiredTableKeys.contains(t.getName().trim())) {
		// // activeXMLTable is in the list of expired codes
		// // so expire it in the list of masterXMLTables
		// Date newExpDate = CoreHelper.getDateBefore(revisionDate);
		// t.setEndDate(CoreHelper.formatDateAsString(newExpDate));
		// }
		// }
	}

	private Collection<String> getTableKeys(
			final List<TableRevision> tableRevisions) {
		Collection<String> tableKeys = new ArrayList<String>();

		for (TableRevision tr : tableRevisions) {
			tableKeys.add(tr.getTable().getKey());
		}
		return tableKeys;
	}
}
