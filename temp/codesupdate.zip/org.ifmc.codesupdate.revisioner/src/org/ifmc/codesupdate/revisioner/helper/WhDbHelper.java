/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.helper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.revisioner.impl.WhDbCodeRevision;
import org.ifmc.codesupdate.svn.client.exception.SVNClientException;

/**
 * Helper methods for Warehouse Database revisioner.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public final class WhDbHelper {

	private WhDbHelper() {
	}

	/**
	 * Maps the code type to the Warehouse DB type id
	 */
	private static final Map<String, Integer> TYPE_ID_MAP = new HashMap<String, Integer>();

	static {
		TYPE_ID_MAP.put(CodeTypeEnum.CART_MEDICATION.toString(), 10);
		TYPE_ID_MAP.put(CodeTypeEnum.DIAGNOSIS.toString(), 2);
		TYPE_ID_MAP.put(CodeTypeEnum.PROCEDURE.toString(), 3);
		TYPE_ID_MAP.put(CodeTypeEnum.CPT.toString(), 14);
		TYPE_ID_MAP.put(CodeTypeEnum.OPPS_MEDICATION.toString(), 14);
	}

	/**
	 * Returns a WhDbCodeRevision object that is equivalent to the given
	 * CodeRevision object.
	 *
	 * @param codeRevision
	 *            the CodeRevision
	 * @return the equivalent WhDbCodeRevision
	 */
	public static WhDbCodeRevision convertToWhDbCodeRevision(
			final CodeRevision codeRevision) {
		// properties required for all warehouse code revisions
		String answer = codeRevision.getCode().getKey();
		Date startDate = codeRevision.getRevision().getStartDate();
		Date endDate = codeRevision.getRevision().getEndDate();

		WhDbCodeRevision whdbCodeRevision = new WhDbCodeRevision(answer,
				startDate, endDate);

		// properties common for all code revisions
		whdbCodeRevision.setUpdateUserId(codeRevision.getUpdatedBy());
		whdbCodeRevision.setUpdateDate(codeRevision.getUpdatedOn());
		whdbCodeRevision.setAnswerDescription(codeRevision.getDescription());

		int whDbTypeId = TYPE_ID_MAP.get(codeRevision.getCode().getCodeType()
				.getDescription());

		whdbCodeRevision.setParentAnswerId(whDbTypeId);

		// medication codes have generic name
		if ((whDbTypeId == TYPE_ID_MAP.get("CART_MEDICATION"))
				|| (whDbTypeId == TYPE_ID_MAP.get("OPPS_MEDICATION"))) {
			whdbCodeRevision.setGenericName(codeRevision.getDescription());
		} else { // diagnosis and procedure codes have external code
			whdbCodeRevision
					.setExternalCd(org.ifmc.codesupdate.revisioner.helper.RevisionerHelper
							.formatExternalCode(codeRevision.getCode().getKey()));
		}

		return whdbCodeRevision;
	}

	/**
	 * Checks-in the given file into subversion.
	 *
	 * @param file
	 *            the File to be checked-in
	 * @param revisionDate
	 *            the revision date
	 * @param svnClientService
	 *            handle to SVNClientService
	 * @throws CodesUpdateRevisionerException
	 *             if failed to check-in
	 */
	public static void checkin(final File file,
			final java.util.Date revisionDate,
			final ISVNClientService svnClientService)
			throws CodesUpdateRevisionerException {
		String destFolder = CoreHelper.formatDateAsString(revisionDate)
				+ "/Output/WHDB/";
		try {
			svnClientService.persistFile(file, destFolder);
		} catch (SVNClientException e) {
			throw new CodesUpdateRevisionerException(e);
		}
	}

	/**
	 * Returns an escaped SQL string for use Oracle's PL/SQL Developer tool
	 * <p>
	 * <ol>
	 * <li><code>'</code> is escaped as <code>''</code></li>
	 * <li><code>&</code> is escaped as <code>&'||'</code></li>
	 * </ol>
	 *
	 * @param s
	 *            the String to be escaped
	 * @return the escaped String
	 */
	public static String escapeForSQL(final String s) {
		if ((s.indexOf('\'') < 0) && (s.indexOf('&') < 0))
			return s;
		StringBuffer buffer = new StringBuffer(s.length() + 10);
		char[] characters = s.toCharArray();
		for (char character : characters) {
			buffer.append(character);
			if (character == '\'') {
				// escape out ' (ie. ' ==> '')
				buffer.append('\'');
			} else if (character == '&') {
				// escape out & (ie. & ==> &'||')
				buffer.append('\'');
				buffer.append('|');
				buffer.append('|');
				buffer.append('\'');
			}
		}
		return buffer.toString();
	}

	/**
	 * Returns the SQL equivalent of insertion from the given WhDbCodeRevision.
	 *
	 * @param whdbCodeRevision
	 *            the WhDbCodeRevision
	 * @return the String of the SQL equivalent
	 */
	public static String constructInsertSQL(final CodeRevision codeRevision) {

		WhDbCodeRevision whdbCodeRevision = org.ifmc.codesupdate.revisioner.helper.WhDbHelper
				.convertToWhDbCodeRevision(codeRevision);

		String answer = whdbCodeRevision.getAnswer();
		Date startDate = whdbCodeRevision.getStartDate();
		Date endDate = whdbCodeRevision.getEndDate();

		// properties common for all code revisions
		String updateUserId = whdbCodeRevision.getUpdateUserId();
		java.util.Date updateDate = whdbCodeRevision.getUpdateDate();
		String answerDescription = whdbCodeRevision.getAnswerDescription();
		int parentAnswerId = whdbCodeRevision.getParentAnswerId();

		String genericName = whdbCodeRevision.getGenericName();
		String externalCd = whdbCodeRevision.getExternalCd();

		String sql = "INSERT INTO sub_answer"
				+ " (answer, sub_answer_id, start_date, end_date, update_user_id,"
				+ " update_date, answer_desc, parent_answer_id";

		// medication codes have generic name
		if (genericName != null) {
			sql += ", generic_name";
		}

		// diagnosis and procedure codes have external code
		if (externalCd != null) {
			sql += ", external_cd";
		}

		sql += ")";

		sql += " VALUES ('" + WhDbHelper.escapeForSQL(answer)
				+ "',(SELECT (max(sub_answer_id) + 1) from sub_answer)," + "'"
				+ CoreHelper.formatDateAsString(startDate) + "','"
				+ CoreHelper.formatDateAsString(endDate) + "','" + updateUserId
				+ "','" + CoreHelper.formatDateAsString(updateDate) + "','"
				+ WhDbHelper.escapeForSQL(answerDescription) + "','"
				+ parentAnswerId + "'";

		if (genericName != null) {
			sql += ",'" + WhDbHelper.escapeForSQL(genericName) + "'";
		}

		// diagnosis and procedure codes have external code
		if (externalCd != null) {
			sql += ",'" + WhDbHelper.escapeForSQL(externalCd) + "'";
		}

		sql += ");";

		return sql;
	}

	public static String constructExpireSQL(final CodeRevision cr,
			Date expiryDate) {

		// if expiry date is set then use that (as is the case for
		// revisedCodeRevisions)
		expiryDate = expiryDate == null ? cr.getRevision().getEndDate()
				: expiryDate;

		String sql = "UPDATE sub_answer SET end_date='"
				+ CoreHelper.formatDateAsString(expiryDate)
				+ "', update_user_id='1', update_date='"
				+ CoreHelper.formatDateAsString(cr.getUpdatedOn())
				+ "' WHERE answer='" + cr.getCode().getKey()
				+ "' AND parent_answer_id='"
				+ TYPE_ID_MAP.get(cr.getCode().getCodeType().getDescription())
				+ "' AND end_date='"
				+ CoreHelper.formatDateAsString(CoreSettings.HIGH_DATE) + "';";
		return sql;
	}

	public static String constructInsertSQL(final Table table) {

		String sql = "INSERT INTO "
				+ "measure_table (msr_tbl_id,msr_tbl_name,msr_tbl_cd,creat_user_id,creat_dt)"
				+ " SELECT (SELECT max(msr_tbl_id)+1 FROM measure_table),'"
				+ table.getKey()
				+ "','"
				+ RevisionerHelper.removeChar(table.getKey(), '.')
				+ "','1','"
				+ CoreHelper.formatDateAsString(table.getCreatedOn())
				+ "'"
				+ " FROM DUAL WHERE NOT EXISTS (SELECT msr_tbl_id FROM measure_table WHERE msr_tbl_name='"
				+ table.getKey() + "');";

		return sql;
	}

	public static String constructInsertSQL(final TableRevision tr,
			final CodeRevision cr, final TableTypeEnum tableTypeEnum) {

		String sql = "INSERT INTO "
				+ getJoinTableName(tableTypeEnum)
				+ " (msr_tbl_sub_aswr_id, msr_tbl_id, sub_answer_Id, tbl_asgn_strt_dt,"
				+ " tbl_asgn_end_dt, creat_user_id, creat_dt) VALUES"
				+ " ((SELECT max(msr_tbl_sub_aswr_id) + 1 FROM"
				+ " measure_table_sub_answer),"
				+ "(SELECT msr_tbl_id FROM"
				+ " measure_table WHERE msr_tbl_name='"
				+ tr.getTable().getKey()
				+ "'),(SELECT sub_answer_id FROM sub_answer WHERE answer='"
				+ cr.getCode().getKey()
				+ "' AND PARENT_ANSWER_ID='"
				+ TYPE_ID_MAP.get(cr.getCode().getCodeType().getDescription())
				+ "'),'"
				+ CoreHelper
						.formatDateAsString(tr.getRevision().getStartDate())
				+ "','"
				+ CoreHelper.formatDateAsString(tr.getRevision().getEndDate())
				+ "','1','" + CoreHelper.formatDateAsString(tr.getCreatedOn())
				+ "');";

		return sql;
	}

	/**
	 * Expires the table to code association for given TableRevision and
	 * CodeRevision.
	 *
	 * @param tr
	 * @param tableTypeEnum
	 * @param cr
	 * @param revisionDate
	 * @return
	 */
	public static String constructExpireSQL(final TableRevision tr,
			java.util.Date expiryDate, final TableTypeEnum tableTypeEnum) {

		// if expiry date is set then use that (as is the case for
		// revisedTableRevisions)
		expiryDate = expiryDate == null ? tr.getRevision().getEndDate()
				: expiryDate;

		String sql = "UPDATE " + getJoinTableName(tableTypeEnum)
				+ " SET tbl_asgn_end_dt='"
				+ CoreHelper.formatDateAsString(expiryDate)
				+ "' WHERE msr_tbl_id=(SELECT msr_tbl_id FROM"
				+ " measure_table WHERE msr_tbl_name='"
				+ tr.getTable().getKey() + "') AND tbl_asgn_end_dt='"
				+ CoreHelper.formatDateAsString(CoreSettings.HIGH_DATE) + "';";

		return sql;
	}

	private static String getJoinTableName(final TableTypeEnum tableTypeEnum) {
		switch (tableTypeEnum) {
		case CART_MEDICATION:
			return "medication_sub";
		case OPPS_MEDICATION:
			return "medication_sub";
		default:
			return "measure_table_sub_answer";
		}
	}

	/**
	 * Writes the list of strings to a file in the temporary location.
	 *
	 * @param sqlList
	 *            the List of SQL statements
	 * @param outputFileName
	 *            the output File
	 * @param revisionDate
	 *            the Revision Date
	 * @throws CodesUpdateRevisionerException
	 *             if error writing output file
	 */
	public static File writeToFile(final List<String> sqlList,
			final String outputFileName, final java.util.Date revisionDate)
			throws CodesUpdateRevisionerException {

		File outputFile = new File(CoreHelper.getTempLocation()
				+ outputFileName);
		outputFile.deleteOnExit(); // cleanup

		FileOutputStream fop = null;
		String output = null;
		try {
			fop = new FileOutputStream(outputFile);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss",
					Locale.US);
			String timeStamp = sdf.format(new java.util.Date());
			output = "/* File created: " + timeStamp + "; Revision Date: "
					+ revisionDate + " */";
			fop.write((output + "\n").getBytes());
			int i = 0;
			for (String line : sqlList) {
				i++;
				fop.write((line + "\n").getBytes());
				if (i % 500 == 0) {
					fop.write(("COMMIT; \n").getBytes());
				}
			}
			if (!sqlList.isEmpty()) {
				fop.write(("COMMIT; \n").getBytes());
			}
			fop.write(("/* File creation completed */").getBytes());
		} catch (FileNotFoundException e) {
			throw new CodesUpdateRevisionerException(
					"Failed to open file for CART Warehouse sql output", e);
		} catch (IOException e) {
			throw new CodesUpdateRevisionerException("Failed to write output",
					e);
		} finally {
			try {
				fop.close();
			} catch (IOException ignore) {
			}
		}

		return outputFile;
	}
}
