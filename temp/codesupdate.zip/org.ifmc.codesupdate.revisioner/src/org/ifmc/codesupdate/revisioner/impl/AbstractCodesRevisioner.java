/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.revisioner.IRevisioner;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public abstract class AbstractCodesRevisioner implements IRevisioner {

	protected final CodeTypeEnum codeTypeEnum;

	protected final Date revisionDate;

	protected List<CodeRevision> newCodeRevisions;

	protected List<CodeRevision> revisedCodeRevisions;

	protected List<CodeRevision> expiredCodeRevisions;

	protected final String notificationEmailAddressList;

	protected final ISVNClientService svnClientService;

	protected final ILogService logService;

	protected final IEmailService emailService;

	/**
	 * *
	 * 
	 * @param newCodeRevisions
	 *            the List of new Code Revisions
	 * @param revisedCodeRevisions
	 *            the List of revised Code Revisions
	 * @param expiredCodeRevisions
	 *            the List of expired Code Revisions
	 * @param codeTypeEnum
	 *            the CodeTypeEnum of the Code Revisions
	 * @param revisionDate
	 *            the Revision Date
	 * @param notificationEmailAddressList
	 *            the delimited list of email addresses where notification
	 *            emails should be sent
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @param logService
	 *            handle to the LogService
	 * @param emailService
	 *            handle to the EmailService
	 * 
	 */
	public AbstractCodesRevisioner(final CodeTypeEnum codeTypeEnum,
			final Date revisionDate, List<CodeRevision> newCodeRevisions,
			List<CodeRevision> revisedCodeRevisions,
			List<CodeRevision> expiredCodeRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {
		super();
		this.codeTypeEnum = codeTypeEnum;
		this.revisionDate = revisionDate;
		this.newCodeRevisions = newCodeRevisions;
		this.revisedCodeRevisions = revisedCodeRevisions;
		this.expiredCodeRevisions = expiredCodeRevisions;
		this.notificationEmailAddressList = notificationEmailAddressList;
		this.svnClientService = svnClientService;
		this.logService = logService;
		this.emailService = emailService;
	}

}
