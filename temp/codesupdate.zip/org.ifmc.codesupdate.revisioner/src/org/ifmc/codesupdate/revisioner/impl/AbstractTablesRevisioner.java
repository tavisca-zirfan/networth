/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.revisioner.IRevisioner;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractTablesRevisioner implements IRevisioner {

	protected final TableTypeEnum tableTypeEnum;

	protected final Date revisionDate;

	protected List<TableRevision> newTableRevisions;

	protected List<TableRevision> revisedTableRevisions;

	protected List<TableRevision> expiredTableRevisions;

	protected final String notificationEmailAddressList;

	protected final ISVNClientService svnClientService;

	protected final ILogService logService;

	protected final IEmailService emailService;

	public AbstractTablesRevisioner(final TableTypeEnum tableTypeEnum,
			final Date revisionDate, final List<TableRevision> newTableRevisions,
			final List<TableRevision> revisedTableRevisions,
			final List<TableRevision> expiredTableRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {
		super();
		this.tableTypeEnum = tableTypeEnum;
		this.revisionDate = revisionDate;
		this.newTableRevisions = newTableRevisions;
		this.revisedTableRevisions = revisedTableRevisions;
		this.expiredTableRevisions = expiredTableRevisions;
		this.notificationEmailAddressList = notificationEmailAddressList;
		this.svnClientService = svnClientService;
		this.logService = logService;
		this.emailService = emailService;
	}

}
