/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.revisioner.helper.RepositoryFile;
import org.ifmc.codesupdate.revisioner.helper.RevisionerHelper;
import org.ifmc.codesupdate.revisioner.helper.XMLHelper;
import org.ifmc.qms.lookup.data.objects.Code;

/**
 * Revisioner for the XML files.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class XMLCodesRevisioner extends AbstractCodesRevisioner {

	/**
	 * holds the map between code type and output file name
	 */
	private static Map<String, String> XML_FILES_MAP = new HashMap<String, String>();

	static {
		XML_FILES_MAP.put(CodeTypeEnum.DIAGNOSIS.toString(), "diagnosis.codes");
		XML_FILES_MAP
				.put(CodeTypeEnum.PROCEDURE.toString(), "procedures.codes");
		XML_FILES_MAP.put(CodeTypeEnum.CART_MEDICATION.toString(),
				"cart_medications.codes");
		XML_FILES_MAP.put(CodeTypeEnum.CPT.toString(), "cpt.codes");
		XML_FILES_MAP.put(CodeTypeEnum.OPPS_MEDICATION.toString(),
				"opps_medications.codes");
	}

	public XMLCodesRevisioner(final CodeTypeEnum codeTypeEnum,
			final Date revisionDate, final List<CodeRevision> newCodeRevisions,
			final List<CodeRevision> revisedCodeRevisions,
			final List<CodeRevision> expiredCodeRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {

		super(codeTypeEnum, revisionDate, newCodeRevisions,
				revisedCodeRevisions, expiredCodeRevisions,
				notificationEmailAddressList, svnClientService, logService,
				emailService);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.ifmc.codesupdate.revisioner.IRevisioner#revise(java.util.List,
	 * java.util.List, java.util.List, org.ifmc.codesupdate.core.CodeTypeEnum,
	 * java.util.Date, java.lang.String,
	 * org.ifmc.codesupdate.core.services.ISVNClientService,
	 * org.ifmc.codesupdate.core.services.ILogService,
	 * org.ifmc.codesupdate.core.services.IEmailService,
	 * org.ifmc.codesupdate.core.WorkData)
	 */
	public void revise(final WorkData workData)
			throws CodesUpdateRevisionerException {

		// input file from latest available revision
		String fileName = XML_FILES_MAP.get(codeTypeEnum.toString());

		try {
			workData.setCurrentSubTask("Generating output file " + fileName);

			logService
					.logInfo("Attempting to checkout most recent XML revision for "
							+ codeTypeEnum.toString() + " codes");

			// retrieve the XML file from subversion for the last revision
			RepositoryFile repositoryFile = XMLHelper.fetchLatestXMLFile(
					fileName, revisionDate, svnClientService, false);

			if (repositoryFile == null)
				throw new CodesUpdateRevisionerException(
						"XML Revisioner - Failed to checkout previous version of "
								+ fileName);
			else {
				logService.logInfo("Succeeded retrieving XML Codes for "
						+ codeTypeEnum.toString()
						+ " from "
						+ CoreHelper.formatDateAsString(repositoryFile
								.getRevisionDate()));
			}

			File xmlInputFile = repositoryFile.getFile();

			logService.logInfo("Attempting to update XML file for "
					+ codeTypeEnum.toString() + " codes");
			File xmlOutputFile;
			try {
				xmlOutputFile = reviseFile(xmlInputFile, fileName);
			} catch (CodesUpdateRevisionerException e) {
				throw new CodesUpdateRevisionerException("Failed to revise "
						+ fileName + " by XMLCodesRevisioner.", e);
			}
			logService.logInfo("Succeeded updating XML file for "
					+ codeTypeEnum.toString() + " codes");

			logService.logInfo("Attempting to checkin updated XML file for "
					+ codeTypeEnum.toString() + " codes for revision "
					+ CoreHelper.formatDateAsString(revisionDate));
			try {
				XMLHelper
						.checkin(xmlOutputFile, revisionDate, svnClientService);
			} catch (CodesUpdateRevisionerException e) {
				throw new CodesUpdateRevisionerException(
						"Failed to checkin revised version of " + fileName
								+ " by XMLCodesRevisioner.", e);
			}
			logService.logInfo("Succeeded checking in XML file for "
					+ codeTypeEnum.toString() + " codes for revision "
					+ CoreHelper.formatDateAsString(revisionDate));
			RevisionerHelper
					.sendSuccessEmail(notificationEmailAddressList, fileName,
							codeTypeEnum.toString(), logService, emailService);

			workData.worked(1);

		} catch (CodesUpdateRevisionerException e) {
			RevisionerHelper.sendFailureEmail(notificationEmailAddressList,
					fileName, logService, emailService);
			throw e;
		}
	}

	/**
	 * Returns a file that is contains the revised codes from the given input
	 * code revisions and input file.
	 *
	 * @param expiredCodeRevisions
	 *            the List of expired Code Revisions
	 * @param newCodeRevisions
	 *            the List of new Code Revisions
	 * @param revisedCodeRevisions
	 *            the List of revised Code Revisions
	 * @param xmlInputFile
	 *            the input XML file
	 * @param outputFileName
	 *            the output file name
	 * @param codeTypeEnum
	 *            the CodeTypeEnum of the input File
	 * @param revisionDate
	 *            the Revision Date
	 * @return the revised XML file
	 * @throws CodesUpdateRevisionerException
	 *             if error writing output file
	 */
	private File reviseFile(final File xmlInputFile, final String outputFileName) {

		// this is the XML file
		List<org.ifmc.qms.lookup.data.objects.Code> masterXMLCodes = XMLHelper
				.readCodesFromInputXMLFile(xmlInputFile, codeTypeEnum
						.toString());
		// Filter codes by revision date
		List<org.ifmc.qms.lookup.data.objects.Code> filteredXMLCodes = XMLHelper
				.filterXMLCodes(masterXMLCodes, revisionDate);

		// expire all expired code revisions
		expireCodeRevisions(filteredXMLCodes);

		// add all new code revisions
		addNewCodeRevisions(masterXMLCodes);

		// now revise all revised code revisions
		reviseCodeRevisions(masterXMLCodes, filteredXMLCodes);

		// write codes
		File xmlOutputFile = new File(CoreHelper.getTempLocation()
				+ outputFileName);
		xmlOutputFile.deleteOnExit(); // make sure to cleanup

		XMLHelper.writeCodesToFile(masterXMLCodes, xmlOutputFile, codeTypeEnum
				.toString());
		return xmlOutputFile;
	}

	/**
	 * @param codeRevisions
	 * @return
	 */
	private Collection<String> getCodeKeys(
			final List<CodeRevision> codeRevisions) {
		Collection<String> codeKeys = new ArrayList<String>();

		for (CodeRevision codeRevision : codeRevisions) {
			codeKeys.add(codeRevision.getCode().getKey());
		}
		return codeKeys;
	}

	/**
	 * Expires XML Codes in the List of active codes that are present in the
	 * reference expired codes. The List of active XML Codes is composed of
	 * objects referenced in the master List of XML Codes. Expiry of these codes
	 * is automatically reflected in the master list.
	 *
	 * @param activeXMLCodes
	 *            the List of active XML Codes
	 * @param revisionDate
	 *            the revision date to apply to the expired codes
	 */
	private void expireCodeRevisions(
			final List<org.ifmc.qms.lookup.data.objects.Code> activeXMLCodes) {

		// avoid unncessary looping if there are 0 expired codes
		if (expiredCodeRevisions.isEmpty())
			return;

		Collection<String> expiredCodeKeys = getCodeKeys(expiredCodeRevisions);

		// loop through all active codes in the XML file
		for (Code c : activeXMLCodes) {

			if (expiredCodeKeys.contains(c.getCode().trim())) {
				// activeXMLCode is in the list of expired codes
				// so expire it in the list of masterXMLCodes
				Date newExpDate = CoreHelper.getDateBefore(revisionDate);
				c.setData(Code.endDate, newExpDate);
			}
		}
	}

	/**
	 * Updates the master List of XML Codes with revised Codes.
	 *
	 * @param masterXMLCodes
	 *            the master List of XML Codes
	 * @param activeXMLCodes
	 *            the List of active XML Codes
	 * @param referenceRevisedCodes
	 *            the reference list of revised codes
	 * @param revisionDate
	 *            the Revision Date
	 * @param codeTypeEnum
	 *            the CodeTypeEnum
	 */
	private void reviseCodeRevisions(final List<Code> masterXMLCodes,
			final List<Code> activeXMLCodes) {

		for (CodeRevision codeRevision : revisedCodeRevisions) {

			// first, expire this code from the active list
			Code c1 = XMLHelper.findInXMLCodeList(activeXMLCodes, codeRevision
					.getCode().getKey());
			if (c1 == null) {
				continue; // this should normally not happen
			}

			c1.setData(Code.endDate, CoreHelper.getDateBefore(revisionDate));

			// create a new code with a new start date, end date and
			// description.
			Code newC = null;
			if ((codeTypeEnum == CodeTypeEnum.CART_MEDICATION)
					|| (codeTypeEnum == CodeTypeEnum.OPPS_MEDICATION)) {
				newC = createNewMedicationCode(c1.getCode(), codeRevision
						.getCode().getKey(), codeRevision.getDescription(),
						revisionDate, CoreSettings.HIGH_DATE);
			} else if (codeTypeEnum == CodeTypeEnum.CPT) {
				// CPT codes do not have externalCd attribute
				newC = createNewCode(c1.getCode(), codeRevision
						.getDescription(), null, revisionDate,
						CoreSettings.HIGH_DATE);
			} else {

				newC = createNewCode(c1.getCode(), codeRevision
						.getDescription(),
						org.ifmc.codesupdate.revisioner.helper.RevisionerHelper
								.formatExternalCode(c1.getCode()),
						revisionDate, CoreSettings.HIGH_DATE);
			}

			masterXMLCodes.add(newC);
		}
	}

	/**
	 * Adds new code revisions to the master list of XML Codes.
	 *
	 * @param masterXMLCodes
	 *            the master List of XML Codes
	 * @param referenceActiveCodeRevisions
	 *            the reference List of active Code Revisions
	 * @param revisionDate
	 *            the Revision Date
	 * @param codeTypeEnum
	 *            the CodeTypeEnum
	 */
	private void addNewCodeRevisions(
			final List<org.ifmc.qms.lookup.data.objects.Code> masterXMLCodes) {

		for (CodeRevision codeRevision : newCodeRevisions) {
			String key = codeRevision.getCode().getKey();

			Code newC = null;
			if ((codeTypeEnum == CodeTypeEnum.CART_MEDICATION)
					|| (codeTypeEnum == CodeTypeEnum.OPPS_MEDICATION)) {
				newC = createNewMedicationCode(key, key, codeRevision
						.getDescription(), revisionDate, CoreSettings.HIGH_DATE);
			} else if (codeTypeEnum == CodeTypeEnum.CPT) {
				// CPT codes do not have an externalCd attribute
				newC = createNewCode(key, codeRevision.getDescription(), null,
						revisionDate, CoreSettings.HIGH_DATE);
			} else {
				newC = createNewCode(key, codeRevision.getDescription(),
						org.ifmc.codesupdate.revisioner.helper.RevisionerHelper
								.formatExternalCode(key), revisionDate,
						CoreSettings.HIGH_DATE);
			}

			masterXMLCodes.add(newC);
		}
	}

	/**
	 * Returns a XML Medication Code with the given attributes.
	 *
	 * @param newId
	 *            the code ID
	 * @param desc
	 *            the description
	 * @param genericName
	 *            the generic name
	 * @param stDt
	 *            the start date
	 * @param endDt
	 *            the end date
	 * @return the XML Medication Code
	 */
	private Code createNewMedicationCode(final String newId, final String desc,
			final String genericName, final Date stDt, final Date endDt) {

		// the sequence in which attributes are set must match the attribute
		// sequence in the input file
		Code newC = new Code();
		newC.setData(Code.startDate, stDt);
		newC.setData(Code.persistId, UUID.randomUUID().toString());
		newC.setData(Code.description, desc);
		newC.setData(Code.endDate, endDt);
		newC.setData(Code.id, newId);
		newC.setData(Code.genericName, genericName);

		return newC;
	}

	/**
	 * Returns a XML Code with the given attributes.
	 *
	 * @param newId
	 *            the code ID
	 * @param desc
	 *            the description
	 * @param extCode
	 *            the external code
	 * @param stDt
	 *            the start date
	 * @param endDt
	 *            the end date
	 * @return the XML Code
	 */
	private Code createNewCode(final String newId, final String desc,
			final String extCode, final Date stDt, final Date endDt) {

		// the sequence in which attributes are set must match the attribute
		// sequence in the input file
		Code newC = new Code();
		newC.setData(Code.startDate, stDt);
		newC.setData(Code.persistId, UUID.randomUUID().toString());
		newC.setData(Code.description, desc);
		newC.setData(Code.endDate, endDt);
		newC.setData(Code.id, newId);
		if (extCode != null) {
			newC.setData(Code.externalCode, extCode);
		}
		return newC;
	}

}
