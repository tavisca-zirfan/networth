/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.helper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.SortedSet;

import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.revisioner.impl.XStreamUtils;
import org.ifmc.codesupdate.svn.client.exception.SVNClientException;
import org.ifmc.qms.lookup.data.objects.Code;
import org.ifmc.qms.lookup.data.objects.Table;
import org.ifmc.qms.util.DateUtils;

/**
 * Helper methods for XML Revisioner.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public final class XMLHelper {

	private XMLHelper() {
	}

	/**
	 * Returns the XML output file for the given Revision Date.
	 *
	 * @param fileName
	 *            the XML file name
	 * @param sRevisionDate
	 *            the Revision Date
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @return <ul>
	 *         <li>the XML output File</li>
	 *         <li><code>null</code> if error retrieving file from subversion or
	 *         file does not exist in repository</li>
	 *         </ul>
	 */
	public static File checkout(final String fileName,
			final String sRevisionDate, final ISVNClientService svnClientService) {

		String filePath = sRevisionDate + "/Output/XML/" + fileName;
		String outputFilePath = CoreHelper.getTempLocation() + fileName + "_"
				+ new Date().getTime();
		try {
			File file = svnClientService.retrieveFile(filePath, outputFilePath);
			file.deleteOnExit(); // cleanup on exit

			return file;

		} catch (SVNClientException e) {
			// file does not exist in repository
			return null;
		}
	}

	/**
	 * @param fileName
	 * @param revisionDate
	 * @param svnClientService
	 * @param isInclusive
	 *            indicates if the given revision must be included in the list
	 *            of revisions to search
	 * @return
	 */
	public static RepositoryFile fetchLatestXMLFile(final String fileName,
			final Date revisionDate, final ISVNClientService svnClientService,
			final boolean isInclusive) {
		File xmlInputFile = null;

		List<Date> sortedRevisionDates = getSortedRevisionDates(revisionDate,
				svnClientService);

		// if not inclusive then remove the given revisionDate from the list of
		// revisionDates
		if (!isInclusive && sortedRevisionDates.contains(revisionDate)) {
			sortedRevisionDates.remove(sortedRevisionDates
					.indexOf(revisionDate));
		}

		Date previousRevisionDate = null;
		String sPreviousRevisionDate = null;

		// iterate backwards through the sorted list of revision dates so we
		// get the latest file
		ListIterator<Date> it = sortedRevisionDates
				.listIterator(sortedRevisionDates.size());

		while (it.hasPrevious() && (xmlInputFile == null)) {

			previousRevisionDate = it.previous();

			sPreviousRevisionDate = CoreHelper
					.formatDateAsString(previousRevisionDate);

			xmlInputFile = checkout(fileName, sPreviousRevisionDate,
					svnClientService);

		}

		if (xmlInputFile == null)
			return null;

		return new RepositoryFile(xmlInputFile, previousRevisionDate);
	}

	/**
	 * Returns the revision date in repository that is previous to the given
	 * date.
	 *
	 * @param date
	 *            the Date to be checked against
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @return the revision date in repository that is previous to the given
	 *         date; <code>null</code> if no previous date exists
	 */
	/*
	 * private static Date getPreviousRevisionDate(final Date date, final
	 * ISVNClientService svnClientService) { Date previousRevisionDate = null;
	 *
	 * SortedSet<Date> revisionDates = svnClientService
	 * .getSortedRevisionDates();
	 *
	 * for (Date revisionDate : revisionDates) { if (revisionDate.equals(date))
	 * return previousRevisionDate; else { previousRevisionDate = revisionDate;
	 * } }
	 *
	 * return null; }
	 */

	/**
	 * Returns the revision dates in the repository that are on or before the
	 * given date.
	 *
	 * @param date
	 *            the Date to be checked against
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @return revision dates in repository that is on or before the given date;
	 *         <code>null</code> if no previous date exists
	 */
	private static List<Date> getSortedRevisionDates(final Date date,
			final ISVNClientService svnClientService) {
		List<Date> revisionDatesList = new ArrayList<Date>();

		SortedSet<Date> revisionDates = svnClientService
				.getSortedRevisionDates();

		for (Date revisionDate : revisionDates) {
			// on or before data comparison
			if (revisionDate.compareTo(date) < 1) {
				revisionDatesList.add(revisionDate);
			}
		}

		return revisionDatesList;
	}

	/**
	 * Checks-in the given file into Subversion under the given Revision Date.
	 *
	 * @param file
	 *            the File to be checked in
	 * @param revisionDate
	 *            the Revision Date
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @throws CodesUpdateRevisionerException
	 *             if error checking in the file
	 */
	public static void checkin(final File file, final Date revisionDate,
			final ISVNClientService svnClientService)
			throws CodesUpdateRevisionerException {
		String sRevisionDate = CoreHelper.formatDateAsString(revisionDate);

		String destFolder = sRevisionDate + "/Output/XML/";
		try {
			svnClientService.persistFile(file, destFolder);
		} catch (SVNClientException e) {
			throw new CodesUpdateRevisionerException(e);
		}
	}

	/**
	 * Returns a List of XML Codes from the given input file.
	 *
	 * @param file
	 *            the File to be read
	 * @param codeTypeEnum
	 *            the CodeTypeEnum of the input File
	 * @return the List of XML Codes
	 * @throws CodesUpdateException
	 *             if error reading input file
	 */
	@SuppressWarnings("unchecked")
	public static List<org.ifmc.qms.lookup.data.objects.Code> readCodesFromInputXMLFile(
			final File file, final String type) {
		URL resURL;
		try {
			resURL = file.toURL();
		} catch (MalformedURLException e) {
			throw new CodesUpdateRevisionerException("Failed to read XML file",
					e);
		}

		Map<String, Class> map = new HashMap<String, Class>();
		map.put("code", org.ifmc.qms.lookup.data.objects.Code.class);
		map.put("list", ArrayList.class);

		List<org.ifmc.qms.lookup.data.objects.Code> list = (List<org.ifmc.qms.lookup.data.objects.Code>) XStreamUtils.INSTANCE
				.loadLookupResource(null, resURL, map, type);

		return list;
	}

	/**
	 * Returns a filtered List of XML Codes from the given List of XML Codes by
	 * filtering by the discharge date.
	 *
	 * @param codes
	 *            the List of XML Codes to be filtered
	 * @param dischargeDate
	 *            the date to filter by
	 * @return the filtered List of XML Codes
	 */
	public static List<Code> filterXMLCodes(
			final List<org.ifmc.qms.lookup.data.objects.Code> codes,
			final Date dischargeDate) {
		List<Code> filteredCodes = new ArrayList<Code>();
		if (codes != null) {

			long dateToCompareAgainst = DateUtils.getDateLong(dischargeDate
					.getTime(), false);
			for (Code lookup : codes) {

				Date startDate = lookup.getStartDate();
				startDate = DateUtils.getDate(startDate, false);
				Date endDate = lookup.getEndDate();
				endDate = DateUtils.getDate(endDate, false);

				long startDateLong = DateUtils.getDateLong(startDate.getTime(),
						false);
				long endDateLong = DateUtils.getDateLong(endDate.getTime(),
						false);
				if ((startDateLong <= dateToCompareAgainst)
						&& (endDateLong >= dateToCompareAgainst)) {
					filteredCodes.add(lookup);
				}
			}
		}
		return filteredCodes;
	}

	/**
	 * Returns Code if found in the list of Codes by matching the key attribute.
	 *
	 * @param codes
	 *            the List of Codes
	 * @param key
	 *            the code key to match
	 * @return the Code if found; <code>null</code> if not in the list
	 */
	public static Code findInXMLCodeList(final List<Code> codes,
			final String key) {
		for (Code code : codes) {
			if (code.getCode().compareToIgnoreCase(key) == 0)
				return code;
		}
		return null;
	}

	public static List<Table> filterXMLTables(final List<Table> tables,
			final Date dischargeDate) {
		List<Table> filteredTables = new ArrayList<Table>();
		if (tables != null) {

			long dateToCompareAgainst = DateUtils.getDateLong(dischargeDate
					.getTime(), false);
			for (Table lookup : tables) {

				Date startDate = lookup.getStartDate();
				startDate = DateUtils.getDate(startDate, false);
				Date endDate = lookup.getEndDate();
				endDate = DateUtils.getDate(endDate, false);

				long startDateLong = DateUtils.getDateLong(startDate.getTime(),
						false);
				long endDateLong = DateUtils.getDateLong(endDate.getTime(),
						false);
				if ((startDateLong <= dateToCompareAgainst)
						&& (endDateLong >= dateToCompareAgainst)) {
					filteredTables.add(lookup);
				}
			}
		}
		return filteredTables;
	}

	@SuppressWarnings("unchecked")
	public static List<Table> readTablesFromInputXMLFile(final File file,
			final TableTypeEnum tableTypeEnum) {
		URL resURL;
		try {
			resURL = file.toURL();
		} catch (MalformedURLException e) {
			throw new CodesUpdateRevisionerException(e);
		}

		Map<String, Class> map = new HashMap<String, Class>();
		map.put("code", org.ifmc.qms.lookup.data.objects.Code.class);
		map.put("table", org.ifmc.qms.lookup.data.objects.Table.class);
		map.put("list", ArrayList.class);

		List<org.ifmc.qms.lookup.data.objects.Table> list = XStreamUtils.INSTANCE
				.loadTables(null, resURL, map, tableTypeEnum.toString());

		return list;
	}

	public static void writeTablesToFile(final List<Table> XMLTables,
			final File outputFile, final String type) {

		PrintWriter pw = null;
		try {
			pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(
					outputFile)));
		} catch (FileNotFoundException e) {
			throw new CodesUpdateRevisionerException(e);
		}
		XStreamUtils.INSTANCE.writerXMLData(pw, XMLTables, type, true);
		pw.close();

	}

	/**
	 * Writes the given List of Codes to file.
	 *
	 * @param XMLCodes
	 *            the List of Codes
	 * @param outputFile
	 *            the output File
	 * @throws CodesUpdateRevisionerException
	 *             if error writing to output File
	 */
	public static void writeCodesToFile(final List<Code> XMLCodes,
			final File outputFile, final String type)
			throws CodesUpdateRevisionerException {

		PrintWriter pw = null;
		try {
			pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(
					outputFile)));
		} catch (FileNotFoundException e) {
			throw new CodesUpdateRevisionerException(e);
		}

		XStreamUtils.INSTANCE.writerXMLData(pw, XMLCodes, type, false);
		pw.close();
	}

}
