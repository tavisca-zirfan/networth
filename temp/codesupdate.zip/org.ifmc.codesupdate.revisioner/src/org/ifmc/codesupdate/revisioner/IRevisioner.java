/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner;

import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;

/**
 * The IRevisioner interface is the contract that must be adhered to by all
 * Revisioners.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public interface IRevisioner {

	/**
	 * Performs revisioning of the codes.
	 * 
	 * @param workData
	 *            the WorkData that tracks progress
	 * @throws CodesUpdateRevisionerException
	 *             if the revise fails
	 */
	void revise(WorkData workData) throws CodesUpdateRevisionerException;

}
