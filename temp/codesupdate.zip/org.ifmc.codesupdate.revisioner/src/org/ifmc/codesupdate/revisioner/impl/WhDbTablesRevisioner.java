/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.revisioner.helper.RevisionerHelper;
import org.ifmc.codesupdate.revisioner.helper.WhDbHelper;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class WhDbTablesRevisioner extends AbstractTablesRevisioner {
	/**
	 * Maps the code type to the output file name
	 */
	private static final Map<String, String> OUTPUT_FILE_MAP = new HashMap<String, String>();

	static {
		OUTPUT_FILE_MAP.put(TableTypeEnum.CART_DIAGNOSIS.toString(),
				"cart_diagnoses_tables.sql");
		OUTPUT_FILE_MAP.put(TableTypeEnum.CART_PROCEDURE.toString(),
				"cart_procedures_tables.sql");
		OUTPUT_FILE_MAP.put(TableTypeEnum.CART_MEDICATION.toString(),
				"cart_medications_tables.sql");

		OUTPUT_FILE_MAP.put(TableTypeEnum.OPPS_DIAGNOSIS.toString(),
				"opps_diagnoses_tables.sql");
		OUTPUT_FILE_MAP.put(TableTypeEnum.OPPS_PROCEDURE.toString(),
				"opps_procedures_tables.sql");
		OUTPUT_FILE_MAP.put(TableTypeEnum.OPPS_MEDICATION.toString(),
				"opps_medications_tables.sql");

		OUTPUT_FILE_MAP.put(TableTypeEnum.CPT.toString(), "cpt_tables.sql");
	}

	public WhDbTablesRevisioner(final TableTypeEnum tableTypeEnum,
			final Date revisionDate,
			final List<TableRevision> newTableRevisions,
			final List<TableRevision> revisedTableRevisions,
			final List<TableRevision> expiredTableRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {

		super(tableTypeEnum, revisionDate, newTableRevisions,
				revisedTableRevisions, expiredTableRevisions,
				notificationEmailAddressList, svnClientService, logService,
				emailService);
	}

	public void revise(final WorkData workData)
			throws CodesUpdateRevisionerException {
		String fileName = OUTPUT_FILE_MAP.get(tableTypeEnum.toString());

		File sqlOutputFile;
		try {
			logService.logInfo("Attempting to generate SQL updates file for "
					+ tableTypeEnum.toString());
			workData.setCurrentSubTask("Generating output file " + fileName);
			sqlOutputFile = generateSQLFile(fileName);
			logService.logInfo("Succeeded generating SQL updates file for "
					+ tableTypeEnum.toString());

			logService
					.logInfo("Attempting to checkin updates for CART Warehouse Database for "
							+ tableTypeEnum.toString()
							+ " for revision "
							+ CoreHelper.formatDateAsString(revisionDate));
			WhDbHelper.checkin(sqlOutputFile, revisionDate, svnClientService);
			logService
					.logInfo("Succeeded checking in updates for CART Warehouse Database for "
							+ tableTypeEnum.toString()
							+ " for revision "
							+ CoreHelper.formatDateAsString(revisionDate));
			RevisionerHelper.sendSuccessEmail(notificationEmailAddressList,
					fileName, tableTypeEnum.toString(), logService,
					emailService);

			workData.worked(1);

		} catch (CodesUpdateRevisionerException e) {
			RevisionerHelper.sendFailureEmail(notificationEmailAddressList,
					fileName, logService, emailService);

			throw e;
		}
	}

	private File generateSQLFile(final String outputFileName) {
		List<String> sqlStatementList = new ArrayList<String>();

		expireTableRevisions(sqlStatementList);

		addNewTableRevisions(sqlStatementList);

		reviseTableRevisions(sqlStatementList);

		return WhDbHelper.writeToFile(sqlStatementList, outputFileName,
				revisionDate);
	}

	private void reviseTableRevisions(final List<String> sqlStatementList) {
		for (TableRevision tr : revisedTableRevisions) {

			// first, expire this table
			sqlStatementList.add(WhDbHelper.constructExpireSQL(tr, CoreHelper
					.getDateBefore(revisionDate), tableTypeEnum));

			for (CodeRevision cr : tr.getCodeRevisions()) {
				// add new table_code revisions
				sqlStatementList.add(WhDbHelper.constructInsertSQL(tr, cr,
						tableTypeEnum));
			}

		}
	}

	private void addNewTableRevisions(final List<String> sqlStatementList) {
		for (TableRevision tr : newTableRevisions) {

			sqlStatementList.add(WhDbHelper.constructInsertSQL(tr.getTable()));

			for (CodeRevision cr : tr.getCodeRevisions()) {
				sqlStatementList.add(WhDbHelper.constructInsertSQL(tr, cr,
						tableTypeEnum));
			}
		}
	}

	private void expireTableRevisions(final List<String> sqlStatementList) {
		for (TableRevision tr : expiredTableRevisions) {
			sqlStatementList.add(WhDbHelper.constructExpireSQL(tr, null,
					tableTypeEnum));
		}
	}
}
