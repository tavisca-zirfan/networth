/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.helper;

import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;

/**
 * Helper methods for revising codes.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public final class RevisionerHelper {

	private RevisionerHelper() {
	}

	/**
	 * Formats a code key as an external code. An external code is the code key
	 * wihtout decimals.
	 * 
	 * @param key
	 *            the code key to be formatted
	 * @return the formatted external code
	 */
	public static String formatExternalCode(final String key) {
		// remove any '.' (decimal) in the key
		return removeChar(key, '.');
	}

	/**
	 * Removes the specified character from the given string.
	 * 
	 * @param s
	 *            the String
	 * @param c
	 *            the Char to be removed
	 * @return the String with the char removed
	 */
	public static String removeChar(final String s, final char c) {
		String r = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) != c) {
				r += s.charAt(i);
			}
		}
		return r;
	}

	/**
	 * Sends a success email for output file generation.
	 * 
	 * @param toAddressList
	 *            the delimited String of notification addresses
	 * @param fileName
	 *            the file name of the output file that was generated
	 * @param typeDescription
	 *            the code type of the output file
	 * @param logService
	 *            handle to the LogService
	 * @param emailService
	 *            handle to the EmailService
	 */
	public static void sendSuccessEmail(final String toAddressList,
			final String fileName, final String typeDescription,
			final ILogService logService, final IEmailService emailService) {

		String subject = "The Output file " + fileName + " containing updated "
				+ typeDescription + " Codes was successfully generated. "
				+ new java.util.Date();
		String message = "The Output file " + fileName + " containing updated "
				+ typeDescription + " Codes was successfully generated. "
				+ new java.util.Date();

		sendEmail(toAddressList, subject, message, logService, emailService);
	}

	/**
	 * Sends an email.
	 * 
	 * @param toAddressList
	 *            the delimited String of email addresses to be sent to
	 * @param subject
	 *            the subject of the email
	 * @param message
	 *            the body of the email
	 * @param logService
	 *            handle to the LogService
	 * @param emailService
	 *            handle to the EmailService
	 */
	private static void sendEmail(final String toAddressList,
			final String subject, final String message,
			final ILogService logService, final IEmailService emailService) {

		String fromAddress = CoreSettings.FROM_EMAIL_ADDRESS;

		String failure = ""; // email addresses sent failure
		boolean genericError = false;

		// deconstruct the address list into an array
		String[] toAddressArray = CoreHelper.parseString(toAddressList, ";");

		if (toAddressArray.length > 0) {
			logService.logInfo("Attempting to send email notification");
			for (String toAddress : toAddressArray) {

				boolean sent;
				try {
					sent = emailService.sendSimpleEmail(fromAddress, toAddress,
							subject, message);
				} catch (CodesUpdateException e) {
					logService.logError("Failed to send email notification", e);
					genericError = true;
					// generic email send error. stop further processing
					break;
				}
				if (!sent) {
					// send failure depends on support from email server
					// @sdps.ifmc.org email addresses are properly detected
					failure = failure + toAddress + ";";
				}

			}

			if (!"".equals(failure)) {
				logService
						.logError("Failure sending emails to following addresses: "
								+ failure);
			} else if (!genericError) {
				logService.logInfo("Succeeded sending email notification");
			}

		} else {
			logService
					.logError("Email notification not sent because address not specified in preferences");
		}
	}

	/**
	 * Sends a failure email for output file generation.
	 * 
	 * @param toAddressList
	 *            the delimited String of notification addresses
	 * @param fileName
	 *            the file name of the output file that was generated
	 * @param logService
	 *            handle to the LogService
	 * @param emailService
	 *            handle to the EmailService
	 */
	public static void sendFailureEmail(final String toAddressList,
			final String fileName, final ILogService logService,
			final IEmailService emailService) {

		String subject = "System Failed to generate Output file " + fileName
				+ ". " + new java.util.Date();
		String message = "System Failed to generate Output file " + fileName
				+ ". " + new java.util.Date() + "\n";

		sendEmail(toAddressList, subject, message, logService, emailService);
	}
}
