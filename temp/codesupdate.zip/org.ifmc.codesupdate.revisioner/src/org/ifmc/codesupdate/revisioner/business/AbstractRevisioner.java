/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.revisioner.Activator;
import org.ifmc.codesupdate.revisioner.IRevisioner;
import org.ifmc.qms.exception.ExceptionHandler;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractRevisioner {

	/**
	 * the List of Revisioners that will be executed
	 */
	protected final List<IRevisioner> revisioners = new ArrayList<IRevisioner>();

	/**
	 * the Revision Date
	 */
	protected final Date revisionDate;

	/**
	 * the delimited list of email addresses where notifications must be sent
	 */
	protected final String notificationEmailAddressList;

	/**
	 * handle to the SVNClientService
	 */
	protected final ISVNClientService svnClientService;

	/**
	 * handle to the LogService
	 */
	protected final ILogService logService;

	/**
	 * handle to the EmailService
	 */
	protected final IEmailService emailService;

	public AbstractRevisioner(final Date revisionDate,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService, final ILogService logService,
			final IEmailService emailService) {
		this.revisionDate = revisionDate;
		this.notificationEmailAddressList = notificationEmailAddressList;
		this.svnClientService = svnClientService;
		this.logService = logService;
		this.emailService = emailService;

	}

	abstract protected void addRevisionersToList();

	public void revise(final WorkData workData) {

		addRevisionersToList();

		for (IRevisioner revisioner : revisioners) {
			try {
				revisioner.revise(workData);
			} catch (CodesUpdateRevisionerException e) {
				// if a revisioner fails just display the exception and keep
				// going
				logService.logError(e.getMessage());
				ExceptionHandler.handleException(e, Activator.PLUGIN_ID, true);
			}
		}
	}

}
