/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.revisioner.impl.WhDbCodesRevisioner;
import org.ifmc.codesupdate.revisioner.impl.XMLCodesRevisioner;

/**
 * Primary class the sequences and excutes all registered revisioners.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CodesRevisioner extends AbstractRevisioner {

	/**
	 * the CodeTypeEnum of the input Code Revisions
	 */
	private final CodeTypeEnum codeTypeEnum;

	/**
	 * the List of expired Code Revisions associated with this revision
	 */
	private final List<CodeRevision> expiredCodeRevisions;

	/**
	 * the List of active Code Revisions associated with this revision
	 */
	private final List<CodeRevision> activeCodeRevisions;

	private final List<CodeRevision> revisedCodeRevisions = new ArrayList<CodeRevision>();

	/**
	 * Constructor
	 *
	 * @param codeTypeEnum
	 *            the CodeTypeEnum of the Code Revisions
	 * @param revisionDate
	 *            the Revision Date
	 * @param expiredCodeRevisions
	 *            the list of expired Code Revisions
	 * @param activeCodeRevisions
	 *            the list of active Code Revisions
	 * @param notificationEmailAddressList
	 *            the delimited list of notification email addreses
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @param logService
	 *            handle to the LogService
	 * @param emailService
	 *            handle to the EmailService
	 */
	public CodesRevisioner(final CodeTypeEnum codeTypeEnum, final Date revisionDate,
			final List<CodeRevision> expiredCodeRevisions,
			final List<CodeRevision> activeCodeRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService,
			final ILogService logService, final IEmailService emailService) {

		super(revisionDate, notificationEmailAddressList,
				svnClientService, logService, emailService);

		this.codeTypeEnum = codeTypeEnum;
		this.expiredCodeRevisions = expiredCodeRevisions;
		this.activeCodeRevisions = activeCodeRevisions;

		createRevisedCodeRevisions(activeCodeRevisions, revisedCodeRevisions,
				expiredCodeRevisions);

	}

	@Override
	protected void addRevisionersToList() {
		// add all revisioners here
		revisioners.add(new XMLCodesRevisioner(codeTypeEnum, revisionDate,
				activeCodeRevisions, revisedCodeRevisions,
				expiredCodeRevisions, notificationEmailAddressList,
				svnClientService, logService, emailService));

		revisioners.add(new WhDbCodesRevisioner(codeTypeEnum, revisionDate,
				activeCodeRevisions, revisedCodeRevisions,
				expiredCodeRevisions, notificationEmailAddressList,
				svnClientService, logService, emailService));
	}

	/**
	 * Returns the List of revised Code Revisions from the given active Code
	 * Revisions and expired Code Revisions. Revised Code Revisions is the
	 * intersection of codes in the active Code Revisions and the expired Code
	 * Revisions. The revisedCodeRevisions list if populated at the return of
	 * this method.
	 *
	 * @param activeCodeRevisions
	 *            the List of active Code Revisions
	 * @param revisedCodeRevisions
	 *            the List of revised Code Revisions
	 * @param expiredCodeRevisions
	 *            the List of expired Code Revisions
	 */
	private void createRevisedCodeRevisions(
			final List<CodeRevision> activeCodeRevisions,
			final List<CodeRevision> revisedCodeRevisions,
			final List<CodeRevision> expiredCodeRevisions) {

		// get the intersection of codes in expired and active code revisions to
		// get the set of codes revised in this revision
		for (CodeRevision expiredCodeRevision : expiredCodeRevisions) {

			// check if expired Code Revision's code exists in the list of
			// active
			// Code Revisions
			CodeRevision activeCodeRevision = lookup(expiredCodeRevision
					.getCode(), activeCodeRevisions);

			if (activeCodeRevision != null) {
				// add to the list of revised codes
				revisedCodeRevisions.add(activeCodeRevision);

				// remove from the list of active code
				// revisions to prevent duplicate processing
				activeCodeRevisions.remove(activeCodeRevision);

			}
		}

		// now clean up revisedcodes from the expiredCodeRevisions
		for (CodeRevision revisedCodeRevision : revisedCodeRevisions) {
			removeFromList(revisedCodeRevision, expiredCodeRevisions);
		}
	}

	/**
	 * Removes given Code Revision from the given List of Code Revisions.
	 *
	 * @param codeRevision
	 *            the Code Revision to be removed
	 * @param codeRevisions
	 *            the List of Code Revisions from which to remove
	 */
	private void removeFromList(final CodeRevision codeRevision,
			final List<CodeRevision> codeRevisions) {

		int i = 0;
		while (!codeRevisions.isEmpty()) {
			CodeRevision cr = codeRevisions.get(i);
			if (cr.getCode().getKey()
					.compareTo(codeRevision.getCode().getKey()) == 0) {
				codeRevisions.remove(cr);
				return;
			}
			i++;
		}

	}

	/**
	 * Returns the Code Revision from the given list of Code Revisions
	 * corresponding to the given Code.
	 *
	 * @param code
	 *            the Code to lookup
	 * @param codeRevisions
	 *            the List of Code Revisions in which to lookup the Code
	 * @return the Code Revision corresponding to the given Code;
	 *         <code>null</code> if not found
	 */
	private CodeRevision lookup(final Code code,
			final List<CodeRevision> codeRevisions) {
		for (CodeRevision cr : codeRevisions) {
			if (cr.getCode().getKey().compareTo(code.getKey()) == 0)
				return cr;
		}
		return null;
	}

}
