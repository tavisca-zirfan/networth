/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateRevisionerException;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.revisioner.helper.RevisionerHelper;
import org.ifmc.codesupdate.revisioner.helper.WhDbHelper;

/**
 * Revisioner for the Warehouse Database.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class WhDbCodesRevisioner extends AbstractCodesRevisioner {

	/**
	 * Maps the code type to the output file name
	 */
	private static final Map<String, String> OUTPUT_FILE_MAP = new HashMap<String, String>();

	static {
		OUTPUT_FILE_MAP.put(CodeTypeEnum.DIAGNOSIS.toString(),
				"diagnoses_codes.sql");
		OUTPUT_FILE_MAP.put(CodeTypeEnum.PROCEDURE.toString(),
				"procedures_codes.sql");
		OUTPUT_FILE_MAP.put(CodeTypeEnum.CART_MEDICATION.toString(),
				"cart_medications_codes.sql");
		OUTPUT_FILE_MAP.put(CodeTypeEnum.CPT.toString(), "cpt_codes.sql");
		OUTPUT_FILE_MAP.put(CodeTypeEnum.OPPS_MEDICATION.toString(), "opps_medications_codes.sql");
	}

	public WhDbCodesRevisioner(final CodeTypeEnum codeTypeEnum, final Date revisionDate,
			final List<CodeRevision> newCodeRevisions,
			final List<CodeRevision> revisedCodeRevisions,
			final List<CodeRevision> expiredCodeRevisions,
			final String notificationEmailAddressList,
			final ISVNClientService svnClientService, final ILogService logService,
			final IEmailService emailService) {

		super(codeTypeEnum, revisionDate, newCodeRevisions, revisedCodeRevisions,
				expiredCodeRevisions, notificationEmailAddressList,
				svnClientService, logService, emailService);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.ifmc.codesupdate.revisioner.IRevisioner#revise(java.util.List,
	 *      java.util.List, java.util.List, org.ifmc.codesupdate.core.CodeTypeEnum,
	 *      java.util.Date, java.lang.String,
	 *      org.ifmc.codesupdate.core.services.ISVNClientService,
	 *      org.ifmc.codesupdate.core.services.ILogService,
	 *      org.ifmc.codesupdate.core.services.IEmailService,
	 *      org.ifmc.codesupdate.core.WorkData)
	 */
	public void revise(final WorkData workData)
			throws CodesUpdateRevisionerException {

		String fileName = OUTPUT_FILE_MAP.get(codeTypeEnum.toString());

		File sqlOutputFile;
		try {
			logService.logInfo("Attempting to generate SQL updates file for "
					+ codeTypeEnum.toString());
			workData.setCurrentSubTask("Generating output file " + fileName);
			sqlOutputFile = generateSQLFile(fileName);
			logService.logInfo("Succeeded generating SQL updates file for "
					+ codeTypeEnum.toString());

			logService
					.logInfo("Attempting to checkin updates for CART Warehouse Database for "
							+ codeTypeEnum.toString()
							+ " for revision "
							+ CoreHelper.formatDateAsString(revisionDate));
			WhDbHelper.checkin(sqlOutputFile, revisionDate, svnClientService);
			logService
					.logInfo("Succeeded checking in updates for CART Warehouse Database for "
							+ codeTypeEnum.toString()
							+ " for revision "
							+ CoreHelper.formatDateAsString(revisionDate));
			RevisionerHelper.sendSuccessEmail(notificationEmailAddressList,
					fileName, codeTypeEnum.toString(), logService, emailService);

			workData.worked(1);

		} catch (CodesUpdateRevisionerException e) {
			RevisionerHelper.sendFailureEmail(notificationEmailAddressList,
					fileName, logService, emailService);

			throw e;
		}

	}

	/**
	 * Returns a file containing SQL statements composed from given lists of
	 * CodeRevisions.
	 *
	 * @param expiredCodeRevisions
	 *            the List of expired Code Revisions
	 * @param newCodeRevisions
	 *            the List of new Code Revisions
	 * @param revisedCodeRevisions
	 *            the List of revised Code Revisions
	 * @param outputFileName
	 *            the destination file name
	 * @param revisionDate
	 *            the revision date
	 * @return the File containing corresponding SQL statements
	 * @throws CodesUpdateRevisionerException
	 *             if failed dto generate output file
	 */
	private File generateSQLFile(final String outputFileName)
			throws CodesUpdateRevisionerException {

		List<String> sqlStatementList = new ArrayList<String>();

		expireCodeRevisions(sqlStatementList);

		addNewCodeRevisions(sqlStatementList);

		reviseCodeRevisions(sqlStatementList);

		return WhDbHelper.writeToFile(sqlStatementList, outputFileName,
				revisionDate);
	}

	/**
	 * Creates expiry SQL statements and adds them to the list of SQL
	 * statements.
	 *
	 * @param sqlStatementList
	 *            the List of SQL statements
	 */
	private void expireCodeRevisions(final List<String> sqlStatementList) {
		for (CodeRevision codeRevision : expiredCodeRevisions) {
			sqlStatementList.add(WhDbHelper.constructExpireSQL(codeRevision,
					null));
		}
	}

	/**
	 * Creates insertion SQL statements and adds them to the List of SQL
	 * statements.
	 *
	 * @param sqlStatementList
	 *            the List of SQL statements
	 */
	private void addNewCodeRevisions(final List<String> sqlStatementList) {

		for (CodeRevision codeRevision : newCodeRevisions) {
			sqlStatementList.add(WhDbHelper.constructInsertSQL(codeRevision));
		}
	}

	/**
	 * Constructs SQL statements for revising (expiry & insert) and adds them to
	 * the List of SQL statements.
	 *
	 * @param sqlStatementList
	 *            the List of SQL statements
	 */
	private void reviseCodeRevisions(final List<String> sqlStatementList) {

		for (CodeRevision codeRevision : revisedCodeRevisions) {

			// first, expire this code
			sqlStatementList.add(WhDbHelper.constructExpireSQL(codeRevision,
					CoreHelper.getDateBefore(revisionDate)));

			// add new code revision
			sqlStatementList.add(WhDbHelper.constructInsertSQL(codeRevision));

		}
	}

}