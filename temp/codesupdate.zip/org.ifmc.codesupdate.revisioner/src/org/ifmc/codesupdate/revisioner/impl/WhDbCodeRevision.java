/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.impl;

import java.util.Date;

/**
 * Represents a CART Warehouse DB code table row.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class WhDbCodeRevision {

	private String answer; // required

	@SuppressWarnings("unused")
	private String updateUserId;

	private java.util.Date updateDate;

	private String externalCd;

	private String answerDescription;

	private int parentAnswerId;

	private String genericName;

	private Date startDate; // required

	private Date endDate; // required

	public WhDbCodeRevision(String answer, Date startDate, Date endDate) {
		this.answer = answer;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	/**
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * @param answer
	 *            the answer to set
	 */
	public void setAnswer(final String answer) {
		this.answer = answer;
	}

	/**
	 * @return the answerDescription
	 */
	public String getAnswerDescription() {
		return answerDescription;
	}

	/**
	 * @param answerDescription
	 *            the answerDescription to set
	 */
	public void setAnswerDescription(final String answerDescription) {
		this.answerDescription = answerDescription;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(final Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the externalCd
	 */
	public String getExternalCd() {
		return externalCd;
	}

	/**
	 * @param externalCd
	 *            the externalCd to set
	 */
	public void setExternalCd(final String externalCd) {
		this.externalCd = externalCd;
	}

	/**
	 * @return the genericName
	 */
	public String getGenericName() {
		return genericName;
	}

	/**
	 * @param genericName
	 *            the genericName to set
	 */
	public void setGenericName(final String genericName) {
		this.genericName = genericName;
	}

	/**
	 * @return the parentAnswerId
	 */
	public int getParentAnswerId() {
		return parentAnswerId;
	}

	/**
	 * @param parentAnswerId
	 *            the parentAnswerId to set
	 */
	public void setParentAnswerId(final int parentAnswerId) {
		this.parentAnswerId = parentAnswerId;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(final Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the updateDate
	 */
	public java.util.Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param date
	 *            the updateDate to set
	 */
	public void setUpdateDate(final java.util.Date date) {
		this.updateDate = date;
	}

	/**
	 * @return the updateUserId
	 */
	public String getUpdateUserId() {
		// return updateUserId;
		return "1"; // always 1 as per WHDB

	}

	/**
	 * @param userId
	 *            the updateUserId to set
	 */
	public void setUpdateUserId(final String userId) {
		this.updateUserId = userId;
	}

}
