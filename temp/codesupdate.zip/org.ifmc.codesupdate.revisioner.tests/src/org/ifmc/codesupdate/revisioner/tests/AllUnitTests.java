package org.ifmc.codesupdate.revisioner.tests;

import org.ifmc.codesupdate.revisioner.helper.WhDbHelperTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses( { WhDbHelperTest.class })
public class AllUnitTests {

}
