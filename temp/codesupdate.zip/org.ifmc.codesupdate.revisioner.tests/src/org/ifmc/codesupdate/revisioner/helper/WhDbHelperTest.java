/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.revisioner.helper;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;

import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.Revision;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class WhDbHelperTest {

	private static CodeRevision cr;

	private static TableRevision tr;

	private static Table table;

	@BeforeClass
	public static void setup() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("mm-dd-yyyy");
		java.util.Date createdOn = sdf.parse("01-01-2008");
		java.util.Date updatedOn = sdf.parse("01-01-2008");

		Code code = new Code("100.01", new CodeType("DIAGNOSIS"));
		Revision revision = new Revision(sdf.parse("01-31-2008"), sdf
				.parse("01-31-2010"));
		cr = new CodeRevision(code, "Test code", revision);
		cr.setCreatedBy("anonymous");
		cr.setCreatedOn(createdOn);
		cr.setUpdatedBy("anonymous");
		cr.setUpdatedOn(updatedOn);

		table = new Table("2.1", new CodeType("DIAGNOSIS"));
		table.setCreatedBy("anonymous");
		table.setCreatedOn(createdOn);
		table.setUpdatedBy("anonymous");
		table.setUpdatedOn(updatedOn);

		Set<CodeRevision> codeRevisions = new HashSet<CodeRevision>();
		codeRevisions.add(cr);

		tr = new TableRevision(table, codeRevisions, revision);
		tr.setCreatedBy("anonymous");
		tr.setCreatedOn(createdOn);
		tr.setUpdatedBy("anonymous");
		tr.setUpdatedOn(updatedOn);

	}

	@Test
	public void constructInsertSQLCodeRevision() {
		String expected = "INSERT INTO cart.sub_answer (answer, sub_answer_id, start_date, end_date, update_user_id, update_date, answer_desc, parent_answer_id, external_cd) VALUES ('100.01',(SELECT (max(sub_answer_id) + 1) from cart.sub_answer),'01-31-2008','01-31-2010','anonymous','01-01-2008','Test code','2','10001');";
		Assert.assertEquals(expected, WhDbHelper.constructInsertSQL(cr));
	}

	@Test
	public void constructExpireSQLCodeRevision() {
		Date expiryDate = null;

		String expected = "UPDATE cart.sub_answer SET end_date='01-30-2010' WHERE answer='100.01' AND parent_answer_id='2' AND end_date='09-30-2099';";
		Assert.assertEquals(expected, WhDbHelper.constructExpireSQL(cr,
				expiryDate));
	}

	@Test
	public void constructInsertSQLTable() {
		String expected = "INSERT INTO cart.measure_table (msr_tbl_id,msr_tbl_name,msr_tbl_cd,creat_user_id,creat_dt) SELECT (SELECT max(msr_tbl_id)+1 FROM cart.measure_table),'2.1','21','anonymous','1/1/2007' FROM DUAL WHERE NOT EXISTS (SELECT msr_tbl_id FROM cart.measure_table WHERE msr_tbl_name='2.1');";
		Assert.assertEquals(expected, WhDbHelper.constructInsertSQL(table));
	}

	@Test
	public void constructInsertSQLTableRevision() {
		String expected = "INSERT INTO cart.measure_table_sub_answer (msr_tbl_sub_aswr_id, msr_tbl_id, sub_answer_Id, tbl_asgn_strt_dt, tbl_asgn_end_dt, creat_user_id, creat_dt) VALUES ((SELECT max(msr_tbl_sub_aswr_id) + 1 FROM cart.measure_table_sub_answer),(SELECT msr_tbl_id FROM cart.measure_table WHERE msr_tbl_name='2.1'),(SELECT sub_answer_id FROM cart.sub_answer WHERE answer='100.01' AND PARENT_ANSWER_ID='2'),'01-31-2008','01-31-2010','anonymous','01-01-2008');";
		Assert.assertEquals(expected, WhDbHelper.constructInsertSQL(tr, cr));
	}

	@Test
	public void constructExpireSQLTableRevision() {
		Date expiryDate = null;

		String expected = "UPDATE cart.measure_table_sub_answer SET tbl_asgn_end_dt='01-31-2010' WHERE msr_tbl_id=(SELECT msr_tbl_id FROM cart.measure_table WHERE msr_tbl_name='2.1') AND tbl_asgn_end_dt='09-30-2099' AND sub_answer_id=(SELECT sub_answer_id FROM cart.sub_answer WHERE answer='100.01' AND parent_answer_id='2');";
		Assert.assertEquals(expected, WhDbHelper.constructExpireSQL(tr, cr,
				expiryDate));
	}
}
