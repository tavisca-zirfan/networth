/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client.exception;

import org.tmatesoft.svn.core.SVNException;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class SVNClientException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SVNClientException() {
		super();
	}

	public SVNClientException(String message) {
		super(message);
	}

	public SVNClientException(String message, Throwable cause) {
		super(message, cause);
	}

	public SVNClientException(Throwable cause) {
		super(cause);
	}

	public int getErrorCode(final Throwable cause) {
		if (cause instanceof SVNException) {
			SVNException svne = (SVNException) cause;
			return svne.getErrorMessage().getErrorCode().getCode();
		}
		return 0;
	}
}