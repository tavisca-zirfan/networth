/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.ifmc.codesupdate.svn.client.exception.SVNClientException;
import org.tmatesoft.svn.core.SVNDirEntry;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

/**
 * Immutable service for connecting to subversion.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class Repository {

	// the respository location
	private transient SVNRepository svnRepository;

	/**
	 * Constructor that creates an authenticated connection.
	 *
	 * @param repositoryURL
	 *            the absolute subversion URL to bind at
	 * @param login
	 *            the subversion username to use for authentication
	 * @param password
	 *            the subversion password to use for authentication
	 * @throws SVNClientException
	 *             if failure to initialize Repository
	 */
	public Repository(final String repositoryURL, final String login,
			final String password) throws SVNClientException {

		// Prior to using the library one must set up an appropriate
		// SVNRepositoryFactory realization for a particular protocol.
		// For svn:// protocol, one must register the following factory:
		// we assume svn://
		SVNRepositoryFactoryImpl.setup();

		try {

			svnRepository = SVNRepositoryFactory.create(SVNURL
					.parseURIEncoded(repositoryURL));

			ISVNAuthenticationManager authManager = SVNWCUtil
					.createDefaultAuthenticationManager(login, password);
			svnRepository.setAuthenticationManager(authManager);

			// execute a connection test for verification
			svnRepository.testConnection();

			// TODO check for validity of SVN location
		} catch (SVNException svne) {

			// cannot recover from this exception
			throw new SVNClientException(
					"Error creating subversion connection. Please verify the repository location setting in the administrative preferences.",
					svne);

		}
	}

	/**
	 * Retrieves the file in the repository at the specified path. The returned
	 * file is located at the specified output file path. If the file exists at
	 * the output file path it is overwritten.
	 *
	 * @param filePath
	 *            the file path relative to the repository bind location
	 * @param outputFilePath
	 *            the output location where the retrieved file should be placed
	 * @return the File object retrieved from the repository
	 * @throws SVNClientException
	 *             if failed to retrieve specified file in repository location
	 *             or if failed to create the output destination file
	 */
	public File retrieveFile(final String filePath, final String outputFilePath) {

		return SVNOperation.retrieveFile(svnRepository, filePath,
				outputFilePath);

	}

	/**
	 * Adds specified file to the given repository location, or overwrites the
	 * existing file if it already exists at the given location.
	 *
	 * @param file
	 *            the File to be added to the repository
	 * @param repoDirPath
	 *            the repository location where the File is to be added
	 * @throws SVNClientException
	 *             if the save or update failed
	 */
	public void saveOrUpdateFile(final File file, final String repoDirPath) {

		if (isFileExistsInRepository(file, repoDirPath)) {
			SVNOperation.updateFile(svnRepository, file, SVNClientHelper
					.addTrailingSlash(repoDirPath));
		} else {
			// we need to create all missing directories in the destination
			// repoFilePath
			createDir(repoDirPath);
			SVNOperation.addFile(svnRepository, file, SVNClientHelper
					.addTrailingSlash(repoDirPath));
		}

	}

	/**
	 * Recursively creates all directories including parent directories for the
	 * given directory path.
	 *
	 * @param dirPath
	 *            the directory path relative to the repository bind location.
	 *            There should NOT be leading '/'.
	 * @throws SVNClientException
	 *             if failed to created directory
	 */
	public void createDir(final String dirPath) {
		// recursively create all directories in the specified directory path
		createDirRecursive(dirPath, 0);
	}

	/**
	 * Recursively creates all directories specified in the directory path.
	 *
	 * @param dirPath
	 *            the directory path relative to the repository bind location
	 * @param index
	 *            the starting location of the current directory being processed
	 *            in the directory path
	 * @throws SVNClientException
	 *             if failed to created directory
	 */
	private void createDirRecursive(String dirPath, final int index) {

		// TODO This does not handle dirs such as A/
		// String parentDir = null;

		// dirPath must have trailing '/' for this logic to work correctly
		// TODO consider File.Separator
		dirPath = SVNClientHelper.addTrailingSlash(dirPath);

		if (dirPath.indexOf('/', index) != -1) {
			String parentDir = dirPath
					.substring(0, dirPath.indexOf('/', index));

			if (isDirectoryExistsInRepository(parentDir)) {
				// + 1 handles the '/' separator
				createDirRecursive(dirPath, parentDir.length() + 1);
			} else {
				SVNOperation.addDir(svnRepository, parentDir);
				createDirRecursive(dirPath, parentDir.length() + 1);
			}
		}
	}

	/**
	 * Checks if the specified directory path exists.
	 *
	 * @param dirPath
	 *            the directory path relative to the repository root
	 * @return <code>true</code> if exists,
	 *         <code>false<code> if path is not a directory, or does not exist
	 */
	private boolean isDirectoryExistsInRepository(final String dirPath) {

		String DIR_PATH = "dir";
		String nodeType;
		nodeType = SVNOperation.findNodeType(svnRepository, dirPath);

		return DIR_PATH.equals(nodeType);

	}

	/**
	 * Checks if given file exists at the given repository location.
	 *
	 * @param file
	 *            the File to check
	 * @param dirPath
	 *            the repository location
	 * @return <code>true</code> if exists, <code>false</code> if not a file
	 *         or does not exist
	 */
	public boolean isFileExistsInRepository(final File file,
			final String dirPath) {

		String FILE_PATH = "file";
		String filePath = dirPath + "/" + file.getName();
		String nodeType;
		nodeType = SVNOperation.findNodeType(svnRepository, filePath);

		return FILE_PATH.equals(nodeType);

	}

	/**
	 * Return the list of directories at the given path. Sub-directories are not
	 * included.
	 *
	 * @param path
	 *            the repository path relative the repository bind location
	 * @return the list of directories at the given path
	 */
	public List<String> retrieveDirList(final String path) {

		List<SVNDirEntry> dirs = SVNOperation.retrieveDirList(svnRepository,
				path);

		List<String> dirPaths = new ArrayList<String>();

		for (SVNDirEntry entry : dirs) {
			if (isDirectory(entry)) {
				dirPaths.add(entry.getRelativePath());
			}
		}
		return dirPaths;
	}

	/**
	 * Checks if entry is a directory node.
	 *
	 * @param entry
	 *            the SVNDirEntry
	 * @return <code>true<code> if directory node, <code>false</code> false otherwise
	 */
	private boolean isDirectory(final SVNDirEntry entry) {
		return entry.getKind() == SVNNodeKind.DIR;
	}
}
