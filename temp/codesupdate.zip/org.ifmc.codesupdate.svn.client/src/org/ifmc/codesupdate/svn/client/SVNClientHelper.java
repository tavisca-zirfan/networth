/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.io.File;

/**
 * Helper methods for subversion access.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public final class SVNClientHelper {

	/**
	 * Private constructor prevents object instantation. Helper class has all
	 * static methods.
	 */
	private SVNClientHelper() {
	}

	/**
	 * Returns the file name in the given file path.
	 * 
	 * @param filePath
	 *            the file path
	 * @return the file name
	 */
	public static String extractFileNameFromPath(final String filePath) {
		return new File(filePath).getName();
	}

	/**
	 * Formats given directory path to have a trailing '/' if it is missing.
	 * 
	 * @param dirPath
	 *            the directory path to be formatted. Valid values are . ,
	 *            Folder1, Folder1/Folder2
	 * @return the formatted directory path with a trailing slash. Ex: ./ ,
	 *         Folder1/ , Folder1/Folder2/
	 */
	public static String addTrailingSlash(final String dirPath) {

		if (dirPath.length() == 0) {
			return "";
		}

		if (dirPath.charAt(dirPath.length() - 1) != '/') {
			return dirPath + "/";
		}

		return dirPath;
	}

}