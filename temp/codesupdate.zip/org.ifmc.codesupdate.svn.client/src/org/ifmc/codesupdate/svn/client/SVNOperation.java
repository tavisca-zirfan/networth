/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.svn.client;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.ifmc.codesupdate.svn.client.exception.SVNClientException;
import org.tmatesoft.svn.core.SVNCommitInfo;
import org.tmatesoft.svn.core.SVNDirEntry;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.io.ISVNEditor;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.diff.SVNDeltaGenerator;

/**
 * Provides CRUD and other operations for subversion access.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
final class SVNOperation {

	private SVNOperation() {
	}

	/**
	 * Retrieves the file from the repositoty at the given file path location
	 * and stores it in at the given output file path location.
	 *
	 * @param repository
	 *            the SVNRepository
	 * @param filePath
	 *            the file path relative to the repository bind location where
	 *            the output file must be placed
	 * @param outputFilePath
	 *            the output location where the retrieved file should be placed
	 * @return the File object retrieved from the repository
	 * @throws SVNClientException
	 *             if failed to retrieve specified file in repository location
	 *             or if failed to create the output destination file
	 */
	protected static File retrieveFile(final SVNRepository repository,
			final String filePath, final String outputFilePath)
			throws SVNClientException {

		try {
			repository.getFile(filePath, -1, null, new FileOutputStream(
					outputFilePath));
			return new File(outputFilePath);

		} catch (FileNotFoundException fnfe) {
			throw new SVNClientException("Failed to create output file", fnfe);
		} catch (SVNException svne) {
			throw new SVNClientException(
					"Failed to retrieve file from repository", svne);
		}
	}

	/**
	 * Creates a new directory as specified by the full path relative to the
	 * repository bind location. All parent directories in the hierarchy must
	 * already exist.
	 *
	 * @param repository
	 *            the SVNRepository
	 * @param dirPath
	 *            the full path to the directory to be created relative to the
	 *            repository bind location
	 * @return teh SVNCommitInfo
	 * @throws SVNClientException
	 *             if failed to created directory
	 */
	protected static SVNCommitInfo addDir(final SVNRepository repository,
			final String dirPath) throws SVNClientException {

		ISVNEditor editor = null;
		try {

			editor = repository.getCommitEditor("app: directory added", null);
			editor.openRoot(-1);

			String parentDirPath = "";
			if (dirPath.indexOf('/') != -1) {
				parentDirPath = dirPath.substring(0, dirPath.lastIndexOf('/'));
			}

			// open all parent directories
			int parentDirCount = openParentDirectoryHierarchy(parentDirPath,
					editor);

			// when adding the directory the first argument is the complete path
			// to the new directory relative to the repository root
			editor.addDir(dirPath, null, -1);

			// close the newly created directory
			editor.closeDir();

			// close all parent directories
			closeParentDirectoryHierarchy(editor, parentDirCount);

			// close the root directory
			editor.closeDir();

			return editor.closeEdit();

		} catch (SVNException svne) {

			// must purge the transaction under any exception
			try {
				editor.abortEdit();
			} catch (SVNException e) {
				// swallow this since we are throwing an exception immediately
				// after
			}

			throw new SVNClientException(
					"Failed to create new directory in repository [" + dirPath
							+ "]", svne);
		}

	}

	/**
	 * Calls closeDir on ISVNEditor iteratively for specified number of parent
	 * directory counts.
	 *
	 * @param editor
	 *            the ISVNEditor
	 * @param parentDirCount
	 *            the number of parent directories that need to be closed
	 * @throws SVNException
	 *             if close directory call fails
	 */
	private static void closeParentDirectoryHierarchy(final ISVNEditor editor,
			final int parentDirCount) throws SVNException {
		// close all parent directories
		for (int i = 0; i < parentDirCount; i++) {
			editor.closeDir();
		}
	}

	/**
	 * Opens all directories in the hierarchy except for the last.
	 *
	 * @param dirPath
	 *            the full relative path to the directory
	 * @param editor
	 *            the ISVNEditor
	 * @return the number of parent directories in the specified directory path
	 * @throws SVNException
	 *             if the open directory call fails
	 */
	private static int openParentDirectoryHierarchy(final String dirPath,
			final ISVNEditor editor) throws SVNException {
		StringTokenizer tokenizer = new StringTokenizer(dirPath, "/");
		// total no. of directories in the directory path
		int parentDirCount = tokenizer.countTokens();

		// open all directories in the hierarchy except for the last
		// the last directory in the hierarchy doesn't exist yet
		// directories must be opened with full relative paths
		String path = "";
		for (int i = 0; i < parentDirCount; i++) {
			if ("".equals(path)) {
				// ignore '/' - the top most directory
				path = tokenizer.nextToken();
			} else {
				path = path + "/" + tokenizer.nextToken();
			}
			editor.openDir(path, -1);
		}
		return parentDirCount;
	}

	/**
	 * Adds given file to the given repository location.
	 *
	 * @param repository
	 *            the SVNRepository
	 * @param file
	 *            the File to be added to subversion
	 * @param addDirPath
	 *            the repository path relative to SVNRepository bind location
	 *            where the File should be added
	 * @return the SVNCommitInfo
	 * @throws SVNClientException
	 *             if the input file was not found or could not be read, or if
	 *             failed to add to repository
	 */
	protected static SVNCommitInfo addFile(final SVNRepository repository,
			final File file, final String addDirPath) throws SVNClientException {
		ISVNEditor editor;
		try {

			byte[] data = new byte[(int) file.length()];
			RandomAccessFile raf = new RandomAccessFile(file, "r");
			raf.readFully(data);
			raf.close();

			editor = repository.getCommitEditor("app: file added", null);
			editor.openRoot(-1);

			int parentDirCount = openParentDirectoryHierarchy(addDirPath,
					editor);

			editor.addFile(addDirPath + file.getName(), null, -1);
			editor.applyTextDelta(addDirPath + file.getName(), null);

			SVNDeltaGenerator deltaGenerator = new SVNDeltaGenerator();
			String checksum = deltaGenerator.sendDelta(addDirPath
					+ file.getName(), new ByteArrayInputStream(data), editor,
					true);

			editor.closeFile(addDirPath + file.getName(), checksum);

			// close all parent directories
			closeParentDirectoryHierarchy(editor, parentDirCount);
			// close the root directory
			editor.closeDir();

			return editor.closeEdit();

		} catch (SVNException svne) {
			throw new SVNClientException(svne);
		} catch (FileNotFoundException fnfe) {
			throw new SVNClientException(fnfe);
		} catch (IOException ioe) {
			throw new SVNClientException(ioe);
		}

	}

	/**
	 * Returns type of node at given path.
	 *
	 * @param repository
	 *            the SVNRepository
	 * @param path
	 *            the repository path
	 * @return the type of node at the given path; <code>none</code> if path
	 *         does not exist
	 * @throws SVNClientException
	 *             if failed to connect to the repository (either issue with
	 *             server or login credentials)
	 */
	protected static String findNodeType(final SVNRepository repository,
			final String path) {
		try {

			return repository.checkPath(path, -1).toString();

		} catch (SVNException svne) {
			throw new SVNClientException(
					"Failed connecting to the repository either because of issue with Subversion server or login credentials",
					svne);
		}
	}

	/**
	 * Updates the given file at the given repository location.
	 *
	 * @param repository
	 *            the SVNRepository
	 * @param file
	 *            the input file
	 * @param updateDirPath
	 *            the path relative to the repository bind location
	 * @return the SVNCommitInfo
	 * @throws SVNClientException
	 *             if the input file was not found or could not be read, or if
	 *             failed to update in repository
	 */
	protected static SVNCommitInfo updateFile(final SVNRepository repository,
			final File file, final String updateDirPath)
			throws SVNClientException {

		ISVNEditor editor;
		try {

			byte[] data = new byte[(int) file.length()];
			RandomAccessFile raf = new RandomAccessFile(file, "r");
			raf.readFully(data);
			raf.close();

			editor = repository.getCommitEditor("app: file updated", null);
			editor.openRoot(-1);

			int parentDirCount = openParentDirectoryHierarchy(updateDirPath,
					editor);

			editor.openFile(updateDirPath + file.getName(), -1);
			editor.applyTextDelta(updateDirPath + file.getName(), null);

			SVNDeltaGenerator deltaGenerator = new SVNDeltaGenerator();
			String checksum = deltaGenerator.sendDelta(updateDirPath
					+ file.getName(), new ByteArrayInputStream(data), editor,
					true);

			editor.closeFile(updateDirPath + file.getName(), checksum);

			// close all parent directories
			closeParentDirectoryHierarchy(editor, parentDirCount);
			// close the root directory
			editor.closeDir();

			return editor.closeEdit();

		} catch (SVNException svne) {
			throw new SVNClientException(svne);
		} catch (FileNotFoundException fnfe) {
			throw new SVNClientException(fnfe);
		} catch (IOException ioe) {
			throw new SVNClientException(ioe);
		}
	}

	/**
	 * Returns a collection of directories and files that exist at the given
	 * repository path.
	 *
	 * @param repository
	 *            the SVNRepository
	 * @param dirPath
	 *            the directory path relative to the repository bind location
	 * @return the List of SVNDirEntry objects located at the given repository
	 *         path
	 * @throws SVNClientException
	 *             in the following cases:
	 *             <ul>
	 *             <li>path not found in the specified revision</li>
	 *             <li>path is not a directory</li>
	 *             <li>a failure occured while connecting to a repository</li>
	 *             <li>the user authentication failed</li>
	 *             </ul>
	 */
	protected static List<SVNDirEntry> retrieveDirList(
			final SVNRepository repository, final String dirPath) {
		// TODO Path must not start with '/' though it does work. What is the
		// assumption?

		List<SVNDirEntry> dirs = new ArrayList<SVNDirEntry>();
		try {
			repository.getDir(dirPath, -1, false, dirs);
		} catch (SVNException svne) {
			throw new SVNClientException(
					"Failed to retrieve list of directories", svne);
		} catch (NullPointerException npe) {
			throw new SVNClientException(
					"Invalid repository location specifed ["
							+ repository.getLocation() + "]", npe);
		}
		return dirs;
	}
}
