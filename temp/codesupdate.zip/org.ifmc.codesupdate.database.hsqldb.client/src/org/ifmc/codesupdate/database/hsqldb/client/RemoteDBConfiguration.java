/*
 * Copyright 2005 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may
 * be reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 *
 */
package org.ifmc.codesupdate.database.hsqldb.client;

import org.eclipse.jface.preference.IPreferenceStore;
import org.ifmc.qms.database.IDatabaseParams;

/**
 * Configuration for the ICD-9-CM Codes HSQLDB embedded database
 * 
 * @author Dana Oredson
 * @version $Revision: 4838 $
 */
public class RemoteDBConfiguration extends
		org.ifmc.qms.database.hsqldb.client.RemoteDBConfiguration {

	private IPreferenceStore store;

	private IDatabaseParams params;

	public IPreferenceStore getPreferenceStore() {
		if (store == null) {
			store = Activator.getDefault().getPreferenceStore();
		}

		return store;
	}

	public IDatabaseParams getDatabaseParams() {
		if (params == null) {
			params = new RemoteDBParams();
		}

		return params;
	}

	@Override
	public String getUrlForDatabase(String dbName) {
		return getDatabaseParams().getURLPrefix() + getServername()
				+ ":" + dbName;
	}
}