/*
 * Copyright 2005 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may
 * be reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 *
 */
package org.ifmc.codesupdate.database.hsqldb.client;

/**
 * Implements the default configuration information for OPPS. Only the schema
 * needs to be overridden.
 * 
 * @author Dana Oredson
 * 
 */
public class RemoteDBParams extends
		org.ifmc.qms.database.hsqldb.client.RemoteDBParams {
	public String getSchema() {
		return "ICD9_APP";
	}

	@Override
	public String getURLPrefix() {
		// return "jdbc:hsqldb:mem"; // in-memory db for testing
		return "jdbc:hsqldb:file";
	}

	@Override
	public String getPassword() {
		return "";
	}

	@Override
	public String getServername() {
		return "";
	}

}