/*
 * Copyright 2005 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 * 
 */
package org.ifmc.codesupdate.database.hsqldb.client;

import java.sql.Connection;

import org.eclipse.core.runtime.Platform;
import org.ifmc.codesupdate.Perspective;
import org.ifmc.qms.database.DatabaseInitializationException;
import org.ifmc.qms.database.IDatabaseConfiguration;
import org.ifmc.qms.exception.ExceptionHandler;
import org.osgi.framework.Bundle;

/**
 * @author Dana Oredson
 * 
 */
public class RemoteDatabase extends
		org.ifmc.qms.database.hsqldb.client.RemoteDatabase {

	private IDatabaseConfiguration config;

	public String getPerspective() {
		return Perspective.ID;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.qms.database.IDatabase#getConfiguration()
	 */
	public IDatabaseConfiguration getConfiguration() {
		if (config == null)
			config = new RemoteDBConfiguration();
		return config;
	}

	@Override
	protected void initializeDatabaseStructure() {
		Connection structureCon = null;

		try {
			structureCon = getConnection();
			Bundle bundle = Platform
					.getBundle("org.ifmc.codesupdate.database.hsqldb.client");

			new RemoteDBInitializer().initialize(structureCon, bundle);

		} catch (DatabaseInitializationException die) {
			ExceptionHandler.handleException(die, true);
		} catch (Throwable t) {
			ExceptionHandler.handleException(t, true);
		} finally {
			dispose(structureCon);
		}
	}

	@Override
	public synchronized void stopDatabase() {
		super.stopDatabase();
		config = null;
	}

	public void archiveDatabase() {
		// no archiving of HSQLDB database
	}
}
