/*
 * Copyright 2005 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 * 
 */
package org.ifmc.codesupdate.database.hsqldb.client;

import java.sql.Connection;

import org.ifmc.qms.database.DatabaseInitializationException;
import org.ifmc.qms.database.util.XmlDatabaseInitializer;
import org.osgi.framework.Bundle;

/**
 * Initializes the structure of the CodesUpdate HSQLDB database
 * 
 * @author Dana Oredson
 * 
 */
public class RemoteDBInitializer {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.qms.database.IDatabaseInitializer#initialize(org.ifmc.qms.database.IDatabase)
	 */
	public void initialize(Connection con, Bundle bundle)
			throws DatabaseInitializationException {

		try {
			new XmlDatabaseInitializer(con, bundle)
					.initialize("resources/initialization.xml");
		} catch (Throwable t) {
			throw new DatabaseInitializationException(
					"Failed to initialize the CodesUpdate HSQLDB database", t);
		}
	}
}
