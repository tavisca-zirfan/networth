/**
 * 
 */
package org.ifmc.codesupdate;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.IPlaceholderFolderLayout;

/**
 * @author Sudhakar
 * 
 */
public class Perspective implements IPerspectiveFactory {

	public final static String ID = "org.ifmc.codesupdate.perspective";

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IPerspectiveFactory#createInitialLayout(org.eclipse.ui.IPageLayout)
	 */
	public void createInitialLayout(IPageLayout layout) {

		String editorArea = layout.getEditorArea();

		layout.setEditorAreaVisible(false);

		// TODO
		// adding this view activates the UI plugin which in turn adds the
		// Console view
		// but switching to welcome and back doesn't re-display the view
		layout.addStandaloneView("org.ifmc.codesupdate.ui.view.codeFiles",
				false, IPageLayout.LEFT, 0.30f, editorArea);

		layout.addStandaloneView("org.ifmc.codesupdate.ui.view.tableFiles",
				false, IPageLayout.BOTTOM, 0.50f,
				"org.ifmc.codesupdate.ui.view.codeFiles");

		// Set up message area on the bottom of the screen.
		IPlaceholderFolderLayout right = layout.createPlaceholderFolder(
				"right", IPageLayout.RIGHT, 0.75f, editorArea);

		/*
		 * Add a view placeholder at the right of the screen. Any views opened
		 * will open in this placeholder.
		 */
		right.addPlaceholder("*");
	}

}
