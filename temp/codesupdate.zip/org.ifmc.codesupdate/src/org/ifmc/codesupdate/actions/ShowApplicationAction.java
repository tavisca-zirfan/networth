/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.actions;

import org.ifmc.codesupdate.Perspective;
import org.ifmc.qms.perspective.ShowPerspectiveAction;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class ShowApplicationAction extends ShowPerspectiveAction {

	/* (non-Javadoc)
	 * @see org.ifmc.qms.perspective.ShowPerspectiveAction#getPerspectiveId()
	 */
	@Override
	public String getPerspectiveId() {
		return Perspective.ID;
	}
}
