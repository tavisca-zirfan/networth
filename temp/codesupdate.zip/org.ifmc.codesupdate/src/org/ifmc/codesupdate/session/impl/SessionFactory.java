/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.session.impl;

import org.ifmc.codesupdate.Perspective;
import org.ifmc.qms.session.ISession;
import org.ifmc.qms.session.ISessionFactory;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class SessionFactory implements ISessionFactory {

	/* (non-Javadoc)
	 * @see org.ifmc.qms.session.ISessionFactory#createSession()
	 */
	public ISession createSession() {
		return new SessionImpl();
	}

	/* (non-Javadoc)
	 * @see org.ifmc.qms.session.ISessionFactory#getPerspective()
	 */
	public String getPerspective() {
		return Perspective.ID;
	}

}
