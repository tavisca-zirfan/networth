package org.ifmc.codesupdate.session.impl;

import java.util.HashMap;
import java.util.Map;

import org.ifmc.qms.session.ISession;

public class SessionImpl implements ISession {
	private Map<String, Object> cache = new HashMap<String, Object>();

	public Object getAttribute(String name) {
		return cache.get(name);
	}

	public void invalidate() {
		cache.clear();
	}

	public Object removeAttribute(String name) {
		return cache.remove(name);
	}

	public void setAttribute(String name, Object value) {
		cache.put(name, value);
	}
}
