/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.business;

import java.io.File;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.ifmc.codesupdate.central.business.TablesUpdater;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.services.impl.LogData;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.revisioner.business.TablesRevisioner;
import org.ifmc.qms.exception.ExceptionHandler;

/**
 * Primary class that sequences all steps in the tables update process.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class TablesProcessor extends AbstractProcessor {

	private final Map<TableTypeEnum, File> inputFileMap;

	public TablesProcessor(final Date revisionDate, final String repositoryURL,
			final String notificationEmailAddressList,
			final Map<TableTypeEnum, File> inputFileMap, final LogData logData) {

		super(revisionDate, repositoryURL, notificationEmailAddressList,
				logData);
		this.inputFileMap = inputFileMap;
	}

	public void process(final IProgressMonitor monitor) {
		// The set of keys in the map
		Set<TableTypeEnum> tableTypeEnums = inputFileMap.keySet();
		Iterator<TableTypeEnum> keyIter = tableTypeEnums.iterator();

		addWorkDataListeners(monitor);

		// iterate through the map elements and process each file
		while (keyIter.hasNext()) {

			// Get the next key.
			TableTypeEnum tableTypeEnum = keyIter.next();

			monitor.beginTask("Processing " + tableTypeEnum.toString(), 6);
			File inputFile = inputFileMap.get(tableTypeEnum);
			try {
				logService.logInfo("*** Log initialized for file "
						+ inputFile.getName() + " revision date "
						+ CoreHelper.formatDateAsString(revisionDate) + " ***");

				// update the central repository with input file
				TablesUpdater updater = new TablesUpdater(inputFile,
						tableTypeEnum,
						revisionDate, databaseService, svnClientService,
						logService, workData);

				updater.update();

				// list object to hold expired and new code revisions
				List<TableRevision> expiredTableRevisions = updater
						.getExpiredTableRevisions();
				List<TableRevision> newTableRevisions = updater
						.getNewTableRevisions();

				// call the revisioners with the inputs
				TablesRevisioner revisioner = new TablesRevisioner(
						tableTypeEnum,
						revisionDate, expiredTableRevisions, newTableRevisions,
						notificationEmailAddressList, svnClientService,
						logService, emailService);
				revisioner.revise(workData);
			} catch (Exception e) {
				ExceptionHandler.handleException(e, true);
			}
		}
	}

	public String getName() {
		return "Updating tables";
	}

}