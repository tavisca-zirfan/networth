/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.business;

import java.io.File;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.ifmc.codesupdate.central.business.CodesUpdater;
import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.services.impl.LogData;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.revisioner.business.CodesRevisioner;
import org.ifmc.qms.exception.ExceptionHandler;

/**
 * Primary class that sequences all steps in the codes update process.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CodesProcessor extends AbstractProcessor {

	private final Map<CodeTypeEnum, File> inputFileMap;


	/**
	 * @param repositoryURL
	 *            an abosolute URL giving the base subversion location
	 * @param notificationEmailAddressList
	 * @param logData
	 *            a handle to central logging
	 */
	public CodesProcessor(final Date revisionDate, final String repositoryURL,
			final String notificationEmailAddressList,
			final Map<CodeTypeEnum, File> inputFileMap, final LogData logData) {
		super(revisionDate, repositoryURL, notificationEmailAddressList,
				logData);
		this.inputFileMap = inputFileMap;
	}

	public void process(final IProgressMonitor monitor) {

		// The set of keys in the map
		Set<CodeTypeEnum> codeTypeEnums = inputFileMap.keySet();
		Iterator<CodeTypeEnum> keyIter = codeTypeEnums.iterator();

		addWorkDataListeners(monitor);

		// iterate through the map elements and process each file
		while (keyIter.hasNext()) {

			// Get the next key.
			CodeTypeEnum codeTypeEnum = keyIter.next();

			monitor.beginTask("Processing " + codeTypeEnum.toString(), 6);
			File inputFile = inputFileMap.get(codeTypeEnum);
			try {
				logService.logInfo("*** Log initialized for file "
						+ inputFile.getName() + " revision date "
						+ CoreHelper.formatDateAsString(revisionDate) + " ***");

				// update the central repository with input file
				CodesUpdater updater = new CodesUpdater(inputFile,
						codeTypeEnum,
						revisionDate, databaseService, svnClientService,
						logService, workData);
				updater.update();

				// list object to hold expired and new code revisions
				List<CodeRevision> expiredCodeRevisions = updater
						.getExpiredCodeRevisions();
				List<CodeRevision> newCodeRevisions = updater
						.getNewCodeRevisions();

				// call the revisioners with the input file
				CodesRevisioner revisioner = new CodesRevisioner(codeTypeEnum,
						revisionDate, expiredCodeRevisions, newCodeRevisions,
						notificationEmailAddressList, svnClientService,
						logService, emailService);
				revisioner.revise(workData);
			} catch (Exception e) {
				ExceptionHandler.handleException(e, true);
			}
		}

	}

	public String getName() {
		return "Updating codes";
	}

}