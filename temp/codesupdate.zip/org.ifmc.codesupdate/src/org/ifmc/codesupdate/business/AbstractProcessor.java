/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.business;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;

import org.eclipse.core.runtime.IProgressMonitor;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.IEmailService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.core.services.impl.DatabaseService;
import org.ifmc.codesupdate.core.services.impl.EmailService;
import org.ifmc.codesupdate.core.services.impl.LogData;
import org.ifmc.codesupdate.core.services.impl.LogService;
import org.ifmc.codesupdate.core.services.impl.SVNClientService;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractProcessor implements IProcessor {

	protected ISVNClientService svnClientService;

	protected IDatabaseService databaseService;

	protected IEmailService emailService;

	protected ILogService logService;

	// TODO move to a properties file
	private final String login = "icd9cm";

	// TODO move to a properties file
	private final String password = "dw12n3e12";

	protected Date revisionDate;

	protected String notificationEmailAddressList;

	protected final WorkData workData;

	/**
	 * Constructor that initializes necessary services.
	 *
	 * @param revisionDate
	 *
	 * @param repositoryURL
	 *            an abosolute URL giving the base subversion location
	 * @param notificationEmailAddressList
	 * @param logData
	 *            a handle to central logging
	 */
	public AbstractProcessor(final Date revisionDate, final String repositoryURL,
			final String notificationEmailAddressList, final LogData logData) {

		svnClientService = new SVNClientService(repositoryURL, login, password);
		databaseService = new DatabaseService();
		emailService = new EmailService();
		logService = new LogService(logData);
		this.revisionDate = revisionDate;
		this.notificationEmailAddressList = notificationEmailAddressList;
		workData = new WorkData(); // the WorkData to track job progress
	}


	public void commitLogFileAndClear() throws CodesUpdateException {

		try {
			logService.commit(revisionDate, svnClientService);
			logService.clearMessages();
		} catch (CodesUpdateException e) {
			throw new CodesUpdateException(e);
		}
	}

	/**
	 * Adds property change listeners for WorkData attributes
	 *
	 * @param monitor
	 *            the IProgressMonitor
	 */
	protected void addWorkDataListeners(final IProgressMonitor monitor) {
		workData.addPropertyChangeListener("workedUnits",
				new PropertyChangeListener() {

					public void propertyChange(final PropertyChangeEvent evt) {
						monitor.worked((Integer) evt.getNewValue());
					}
				});

		workData.addPropertyChangeListener("currentSubTask",
				new PropertyChangeListener() {

					public void propertyChange(final PropertyChangeEvent evt) {
						monitor.subTask((String) evt.getNewValue());
					}

				});
	}
}
