/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.business;

import java.io.File;
import java.util.Date;
import java.util.Map;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.services.impl.LogData;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public interface IProcessorFactory {

	IProcessor constructCodeProcessor(final Date revisionDate,
			final String repositoryUrl,
			final String notificationEmailAddressList,
			final Map<CodeTypeEnum, File> inputFileMap, final LogData logData);

	IProcessor constructTableProcessor(Date revisionDate, String repositoryUrl,
			String notificationEmailAddressList,
			Map<TableTypeEnum, File> inputFileMap, LogData logData);
}
