/*
 * Copyright 2005 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may
 * be reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 *
 */
package org.ifmc.codesupdate.database.oracle.client;

import org.eclipse.jface.preference.IPreferenceStore;
import org.ifmc.qms.database.IDatabaseParams;
import org.ifmc.qms.database.oracle.client.RemoteDBParams;

/**
 * Configuration for the Oracle database
 * @author Dana Oredson
 */
public class RemoteDBConfiguration extends org.ifmc.qms.database.oracle.client.RemoteDBConfiguration {

	private IPreferenceStore store;
	private IDatabaseParams params;
	
	public IDatabaseParams getDatabaseParams() {
		if(params == null) {
			params = new RemoteDBParams();
		}
		
		return params;
	}

	public IPreferenceStore getPreferenceStore() {
		if(store == null) {
			store = Activator.getDefault().getPreferenceStore();
		}
		return store;
	}
}
