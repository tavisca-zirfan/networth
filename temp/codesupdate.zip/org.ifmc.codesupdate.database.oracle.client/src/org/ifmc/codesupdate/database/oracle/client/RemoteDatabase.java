package org.ifmc.codesupdate.database.oracle.client;

import org.ifmc.codesupdate.Perspective;
import org.ifmc.qms.database.IDatabaseConfiguration;

public class RemoteDatabase extends org.ifmc.qms.database.oracle.client.RemoteDatabase {

	private IDatabaseConfiguration config;
	
	public String getPerspective() {
		return Perspective.ID;
	}

	/* (non-Javadoc)
	 * @see org.ifmc.qms.database.IDatabase#stopDatabase()
	 */
	public synchronized void stopDatabase() {
		super.stopDatabase();
		config = null;
	}

	/* (non-Javadoc)
	 * @see org.ifmc.qms.database.IDatabase#getConfiguration()
	 */
	public IDatabaseConfiguration getConfiguration() {
		if (config == null)
			config = new RemoteDBConfiguration();
		return config;
	}
}
