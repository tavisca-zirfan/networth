/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.parser;

import java.util.Map;

import org.ifmc.codesupdate.core.exception.CodesUpdateException;

/**
 * The ICodesParser interface defines the contract that all input data files
 * must adhere to.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public interface ICodesParser {

	/**
	 * Returns a Map of the code key to code description from the encapsulated
	 * file.
	 * 
	 * @return the Map of code key to code description
	 * @throws CodesUpdateException
	 *             if there was an error parsing the File
	 */
	Map<String, String> parse();
}
