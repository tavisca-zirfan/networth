/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.parser;

import java.io.File;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.file.CARTDiagnosisTablesFile;
import org.ifmc.codesupdate.file.CARTMedicationCodesFile;
import org.ifmc.codesupdate.file.CARTMedicationTablesFile;
import org.ifmc.codesupdate.file.CARTProcedureTablesFile;
import org.ifmc.codesupdate.file.CPTCodesFile;
import org.ifmc.codesupdate.file.CPTTablesFile;
import org.ifmc.codesupdate.file.DiagnosisCodesFile;
import org.ifmc.codesupdate.file.OPPSDiagnosisTablesFile;
import org.ifmc.codesupdate.file.OPPSMedicationCodesFile;
import org.ifmc.codesupdate.file.OPPSMedicationTablesFile;
import org.ifmc.codesupdate.file.OPPSProcedureTablesFile;
import org.ifmc.codesupdate.file.ProcedureCodesFile;

/**
 * Factory class that provides methods to create ICodesDataFile objects.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public final class ParserFactory {

	private ParserFactory() {
	} // not extensible

	/**
	 * Returns a ICodesDataFile object that encapsulates the given File and is
	 * of given CodeTypeEnum.
	 *
	 * @param file
	 *            the File to be encapsulated
	 * @param codeType
	 *            the CodeTypeEnum of the given file
	 * @return the AbstractDataFile; <code>null</code> if codeType is not
	 *         implemented
	 */
	public static ICodesParser createCodesParser(final File file,
			final CodeTypeEnum type) {

		ICodesParser retFile = null;
		switch (type) {
		case DIAGNOSIS:
			retFile = new DiagnosisCodesFile(file);
			break;
		case PROCEDURE:
			retFile = new ProcedureCodesFile(file);
			break;
		case CART_MEDICATION:
			retFile = new CARTMedicationCodesFile(file);
			break;
		case OPPS_MEDICATION:
			retFile = new OPPSMedicationCodesFile(file);
			break;
		case CPT:
			retFile = new CPTCodesFile(file);
			break;
		default:
			throw new CodesUpdateException(type.toString()
					+ " code codeType for codes is not supported.");
		}

		return retFile;
	}

	/**
	 * Returns a ICodesDataFile object that encapsulates the given File and is
	 * of given CodeTypeEnum.
	 *
	 * @param file
	 *            the File to be encapsulated
	 * @param codeType
	 *            the CodeTypeEnum of the given file
	 * @return the AbstractDataFile; <code>null</code> if codeType is not
	 *         implemented
	 */
	public static ITablesParser createTablesParser(final File file,
			final TableTypeEnum type) {

		ITablesParser retFile = null;
		switch (type) {
		case CART_DIAGNOSIS:
			retFile = new CARTDiagnosisTablesFile(file);
			break;
		case CART_PROCEDURE:
			retFile = new CARTProcedureTablesFile(file);
			break;
		case CART_MEDICATION:
			retFile = new CARTMedicationTablesFile(file);
			break;
		case OPPS_DIAGNOSIS:
			retFile = new OPPSDiagnosisTablesFile(file);
			break;
		case OPPS_PROCEDURE:
			retFile = new OPPSProcedureTablesFile(file);
			break;
		case OPPS_MEDICATION:
			retFile = new OPPSMedicationTablesFile(file);
			break;
		case CPT:
			retFile = new CPTTablesFile(file);
			break;
		default:
			throw new CodesUpdateException(type.toString()
					+ " code codeType for tables is not supported.");
		}

		return retFile;
	}
}
