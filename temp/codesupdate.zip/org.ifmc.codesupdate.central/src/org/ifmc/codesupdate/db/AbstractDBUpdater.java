/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.db;

import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.dao.dt.Revision;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractDBUpdater {

	protected Date revisionDate;

	protected IDatabaseService databaseService;

	protected ILogService logService;

	protected int countNew = 0; // track total no. of new tables

	protected int countExpired = 0; // track total no. of expired tables

	protected int countRevised = 0; // track total no. of revised tables

	// int countReintroduced = 0; // track total no. of re-introduced
	// tables

	protected String expiredKeys = "";// holds the expired keys

	protected String newKeys = ""; // holds the new table keys

	protected String revisedKeys = ""; // holds the revised table keys

	// String reintroducedCodeKeys = ""; // hold the reintroduced code
	// keys

	protected Revision currentRevision;

	protected List<Revision> allRevisions;

	public AbstractDBUpdater(final Date revisionDate,
			final IDatabaseService databaseService, final ILogService logService) {

		this.revisionDate = revisionDate;
		this.databaseService = databaseService;
		this.logService = logService;

		currentRevision = databaseService.findOrCreateRevision(revisionDate);
		// get the list of all revisions so we won't have to query
		// improves expiry and revising performance
		allRevisions = databaseService.findAllRevisions();

	}

	public void update() {

		expire();
		addNewOrRevise();
		logResults();

	}

	abstract protected void expire();

	abstract protected void addNewOrRevise();

	abstract public void rollback();

	private void logResults() {
		logService.logInfo("Total no. of " + getTypeDescription()
				+ " records expired: " + countExpired + " [ "
				+ expiredKeys.trim() + " ]");

		logService
				.logInfo("Total no. of " + getTypeDescription()
						+ " records added: " + countNew + " [ "
						+ newKeys.trim() + " ]");

		logService.logInfo("Total no. of " + getTypeDescription()
				+ " records revised: " + countRevised + " [ "
				+ revisedKeys.trim() + " ]");
	}

	abstract protected String getTypeDescription();
}
