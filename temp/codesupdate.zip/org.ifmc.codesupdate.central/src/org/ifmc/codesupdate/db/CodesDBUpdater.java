/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.db;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.ifmc.codesupdate.central.CentralHelper;
import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.codesupdate.dao.dt.Revision;

/**
 * Provides methods to update the Central Codes Database.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public final class CodesDBUpdater extends AbstractDBUpdater {

	protected CodeTypeEnum codeTypeEnum;

	private final List<CodeRevision> expiredCodeRevisions = new ArrayList<CodeRevision>();

	private final List<CodeRevision> newCodeRevisions = new ArrayList<CodeRevision>();

	private final Map<String, String> fileRecords;

	private Map<Code, CodeRevision> existingActiveCodesCodeRevisionsMap;

	protected CodeType codeType;

	public CodesDBUpdater(final Map<String, String> fileRecords,
			final CodeTypeEnum codeTypeEnum, final Date revisionDate,
			final IDatabaseService databaseService, final ILogService logService) {
		super(revisionDate, databaseService, logService);
		this.codeTypeEnum = codeTypeEnum;
		this.fileRecords = fileRecords;
		codeType = databaseService.findOrCreateCodeType(codeTypeEnum.toString());
	}

	public List<CodeRevision> getExpiredCodeRevisions() {
		return expiredCodeRevisions;
	}

	public List<CodeRevision> getNewCodeRevisions() {
		return newCodeRevisions;
	}

	/**
	 * Rolls back updates for specified code codeType for specified revision. First
	 * deletes all new code revisions of specified codeType added for specified
	 * revision date. This is followed by un-expiring all code revisions of
	 * specified codeType that were expired for the specified revision date.
	 */
	@Override
	public void rollback() {

		// delete all code revisions added for the specified revision
		List<CodeRevision> addedCodeRevisions = databaseService
				.findActiveCodeRevisions(codeTypeEnum.toString(), revisionDate);
		databaseService.deleteCodeRevisions(addedCodeRevisions);

		// "un-expire" all code revisions that were expired for specified
		// revision
		List<CodeRevision> expiredCodeRevisions = databaseService
				.findExpiredCodeRevisions(codeTypeEnum.toString(), revisionDate);
		databaseService.unExpireCodeRevisions(expiredCodeRevisions);

	}

	@Override
	protected void expire() {
		// retrieve active code revisions from the database
		List<CodeRevision> existingActiveCodeRevisions = databaseService
				.findActiveCodeRevisions(codeType);

		// get the list of all revisions so we won't have to query
		// improves expiry and revising performance
		List<Revision> allRevisions = databaseService.findAllRevisions();

		StringBuilder sb = new StringBuilder();
		// expire codes
		for (CodeRevision cr : existingActiveCodeRevisions) {

			// if this active code does not exist in the input file
			// then expire the code
			if (!fileRecords.containsKey(cr.getCode().getKey())) {
				databaseService.expireCodeRevision(cr, currentRevision
						.getStartDate(), allRevisions);
				countExpired++;
				sb.append(" " + cr.getCode().getKey());
				expiredCodeRevisions.add(cr);
			}
		}
		expiredKeys = sb.toString();

		// create a map of code to coderevisions
		existingActiveCodesCodeRevisionsMap = CentralHelper
				.getCodesCodeRevisionsMap(existingActiveCodeRevisions);

	}

	@SuppressWarnings("unchecked")
	@Override
	protected void addNewOrRevise() {
		StringBuilder sb1 = new StringBuilder();
		StringBuilder sb2 = new StringBuilder();

		Set<Entry<String, String>> entries = fileRecords.entrySet();
		Iterator entryIter = entries.iterator();
		// iterate through the map elements and process each code
		while (entryIter.hasNext()) {
			Map.Entry entry = (Map.Entry) entryIter.next();
			String key = (String) entry.getKey();
			String description = (String) entry.getValue();

			// check if specified code key and codeType combination
			// exists in the list of active code revisions
			CodeRevision codeRevision = existingActiveCodesCodeRevisionsMap
					.get(new Code(key, codeType));
			if (codeRevision == null) {
				// process newly added code revisions. The code may already
				// exist
				// TODO maybe one way to check for reintroduced codes
				// Code newCode = databaseService.retrieveOrCreateCode(key,
				// codeType);
				Code newCode = new Code(key, codeType);
				CodeRevision newCodeRevision = databaseService
						.createCodeRevision(newCode, currentRevision,
								description);
				countNew++;
				sb1.append(" " + key);
				newCodeRevisions.add(newCodeRevision);
			} else if (codeRevision.getDescription().compareTo(description) != 0) {
				// revise code
				// expire last revision and add new code revision
				CodeRevision expiredCodeRevision = databaseService
						.expireCodeRevision(codeRevision, currentRevision
								.getStartDate(), allRevisions);
				expiredCodeRevisions.add(expiredCodeRevision);

				CodeRevision newCodeRevision = databaseService
						.createCodeRevision(codeRevision.getCode(),
								currentRevision, description);
				newCodeRevisions.add(newCodeRevision);

				countRevised++;
				sb2.append(" " + key);
			}

		}
		newKeys = sb1.toString();
		revisedKeys = sb2.toString();

	}

	@Override
	protected String getTypeDescription() {
		return codeType.getDescription();
	}

}
