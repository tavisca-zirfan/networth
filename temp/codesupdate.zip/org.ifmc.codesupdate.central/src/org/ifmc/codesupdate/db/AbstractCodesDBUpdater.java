/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.db;

import java.util.Date;
import java.util.List;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.dao.dt.CodeRevision;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractCodesDBUpdater extends AbstractDBUpdater {

	public AbstractCodesDBUpdater(final CodeTypeEnum codeTypeEnum,
			final Date revisionDate, final IDatabaseService databaseService,
			final ILogService logService) {
		super(revisionDate, databaseService, logService);
	}

	public abstract List<CodeRevision> getExpiredCodeRevisions();

	public abstract List<CodeRevision> getNewCodeRevisions();
}
