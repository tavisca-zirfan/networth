/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.db;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.ifmc.codesupdate.central.CentralHelper;
import org.ifmc.codesupdate.central.exception.CodesUpdateCentralException;
import org.ifmc.codesupdate.core.CoreSettings;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.CodeType;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.dao.dt.TableType;

/**
 * Provides methods to update the Central Codes Database.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public final class TablesDBUpdater extends AbstractDBUpdater {

	protected TableTypeEnum tableTypeEnum;

	private final List<TableRevision> expiredTableRevisions = new ArrayList<TableRevision>();

	private final List<TableRevision> newTableRevisions = new ArrayList<TableRevision>();

	private final Map<String, List<String>> fileRecords;

	private Map<Table, TableRevision> existingActiveTablesTableRevisionsMap;

	private final Map<Code, CodeRevision> existingActiveCodesCodeRevisionsMap;

	private final TableType tableType;

	private final CodeType codeType;

	public TablesDBUpdater(final Map<String, List<String>> fileRecords,
			final TableTypeEnum tableTypeEnum, final Date revisionDate,
			final IDatabaseService databaseService, final ILogService logService) {

		super(revisionDate, databaseService, logService);

		this.fileRecords = fileRecords;
		this.tableTypeEnum = tableTypeEnum;

		tableType = databaseService
				.findOrCreateTableType(tableTypeEnum
				.toString());
		codeType = databaseService
				.findOrCreateCodeType(tableTypeEnum.codeTypeEnum.toString());

		List<CodeRevision> activeCodeRevisions = databaseService
				.findActiveCodeRevisions(codeType);
		existingActiveCodesCodeRevisionsMap = CentralHelper
				.getCodesCodeRevisionsMap(activeCodeRevisions);
	}

	public List<TableRevision> getExpiredTableRevisions() {
		return expiredTableRevisions;
	}

	public List<TableRevision> getNewTableRevisions() {
		return newTableRevisions;
	}

	/**
	 * Rolls back updates for specified code codeType for specified revision.
	 * First deletes all new table revisions of specified codeType added for
	 * specified revision date. This is followed by un-expiring all code
	 * revisions of specified codeType that were expired for the specified
	 * revision date.
	 *
	 * @param codeTypeEnum
	 *            codeType of code in the inputFile
	 * @param revisionDate
	 *            date as of which this revision is active
	 * @param databaseService
	 *            handle to the database service
	 * @throws CodesUpdateCentralException
	 */
	@Override
	public void rollback() {

		// delete all table revisions added for the specified revision
		List<TableRevision> addedTableRevisions = databaseService
				.findActiveTableRevisions(tableTypeEnum.toString(),
						revisionDate);
		databaseService.deleteTableRevisions(addedTableRevisions);

		// "un-expire" all table revisions that were expired for specified
		// revision
		List<TableRevision> expiredTableRevisions = databaseService
				.findExpiredTableRevisions(tableTypeEnum.toString(),
						revisionDate);
		databaseService.unExpireTableRevisions(expiredTableRevisions);

	}

	@Override
	protected void expire() {
		// retrieve active table revisions from the database
		List<TableRevision> existingActiveTableRevisions = databaseService
				.findActiveTableRevisions(tableType);

		StringBuilder sb = new StringBuilder();

		// expire tables
		for (TableRevision tr : existingActiveTableRevisions) {

			// if this active table does not exist in the input file
			// then expire the table revision
			if (!fileRecords.containsKey(tr.getTable().getKey())) {
				databaseService.expireTableRevision(tr, currentRevision
						.getStartDate(), allRevisions);
				countExpired++;
				sb.append(" " + tr.getTable().getKey());
				expiredTableRevisions.add(tr);
				// TODO should we also remove tr from
				// the existingActiveTableRevisions
				// for CodesDBUpdater.java
			}
		}
		expiredKeys = sb.toString();

		// create a map of table to TableRevisions
		// TODO...should we remove expired tables before mapping
		existingActiveTablesTableRevisionsMap = CentralHelper
				.getTablesTableRevisionsMap(existingActiveTableRevisions);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void addNewOrRevise() {

		StringBuilder sb1 = new StringBuilder();
		StringBuilder sb2 = new StringBuilder();

		Set<Entry<String, List<String>>> entries = fileRecords.entrySet();
		Iterator entryIter = entries.iterator();

		// iterate through the map elements and process each table
		while (entryIter.hasNext()) {
			Map.Entry entry = (Map.Entry) entryIter.next();
			String tableKey = (String) entry.getKey();
			List<String> codeKeys = (List<String>) entry.getValue();

			// remove all inactive codes that are in present in the table
			filterInactiveCodeKeys(tableKey, codeKeys);

			Set<CodeRevision> codeRevisions = getCodeRevisionsFromActiveKeys(codeKeys);

			// check if specified table key and tableType combination
			// exists in the list of active table revisions
			TableRevision tableRevision = existingActiveTablesTableRevisionsMap
					.get(new Table(tableKey, tableType));
			if (tableRevision == null) {
				addNewTableRevision(sb1, tableKey, codeRevisions);
			} else if (isChanged(tableRevision, codeKeys)) {
				reviseTableRevision(sb2, tableKey, codeRevisions, tableRevision);
			}
		}
		newKeys = sb1.toString();
		revisedKeys = sb2.toString();

	}

	@SuppressWarnings("unchecked")
	private void filterInactiveCodeKeys(final String tableKey,
			final List<String> codeKeys) {

		String inactiveCodes = ""; // tracks all inactive codes

		Iterator it = codeKeys.iterator();
		while (it.hasNext()) {
			String codeKey = (String) it.next();
			CodeRevision activeCodeRevision = existingActiveCodesCodeRevisionsMap
					.get(new Code(codeKey, codeType));
			if (activeCodeRevision == null) {
				it.remove();
				inactiveCodes += " " + codeKey;
			}
		}

		// TODO need to write test case for this
		if (!"".equals(inactiveCodes)) {
			logService.logError(codeType.getDescription()
					+ " table contains inactive or non-existent codes [Table "
					+ tableKey + ":"
					+ inactiveCodes + "]");
		}

	}

	private Set<CodeRevision> getCodeRevisionsFromActiveKeys(
			final List<String> activeCodeKeys) {
		Set<CodeRevision> codeRevisions = new HashSet<CodeRevision>();

		for (String codeKey : activeCodeKeys) {
			CodeRevision activeCodeRevision = existingActiveCodesCodeRevisionsMap
					.get(new Code(codeKey, codeType));
			if (activeCodeRevision != null) {
				codeRevisions.add(activeCodeRevision);
			} // else an error because assumption is method receives only
			// active code keys
		}

		return codeRevisions;
	}

	/**
	 * @param sb2
	 * @param tableKey
	 * @param codeRevisions
	 * @param tableRevision
	 */
	private void reviseTableRevision(final StringBuilder sb2,
			final String tableKey, final Set<CodeRevision> codeRevisions,
			final TableRevision tableRevision) {
		// expire last revision and add new table revision
		TableRevision expiredTableRevision = databaseService
				.expireTableRevision(tableRevision, currentRevision
						.getStartDate(), allRevisions);

		expiredTableRevisions.add(expiredTableRevision);

		TableRevision newTableRevision = databaseService.createTableRevision(
				tableRevision.getTable(), currentRevision, codeRevisions);
		newTableRevisions.add(newTableRevision);

		countRevised++;
		sb2.append(" " + tableKey);
	}

	/**
	 * A table is deemed to have changed under the following conditions:
	 * <ol>
	 * <li>a new code is added to the table</li>
	 * <li>a code is dropped from table</li>
	 * <li>an existing code in the table is revised</li>
	 * </ol>
	 *
	 * Also all codes revisions associcated with a table must have active code
	 * revisions, or if they are expired, the revised code revisions must exist.
	 *
	 * @param tableRevision
	 * @param codeKeys
	 * @return
	 */
	private boolean isChanged(final TableRevision tableRevision,
			final List<String> codeKeys) {
		// TODO ...for now we turn lazy = false
		// we need to reload tableRevision with lazy turned off so we can get to
		// the collections
		Set<CodeRevision> codeRevisions = tableRevision.getCodeRevisions();
		Map<Code, CodeRevision> codeToCodeRevisionsMap = CentralHelper
				.getCodesCodeRevisionsMap(codeRevisions);

		// check if new code added to table
		for (String codeKey : codeKeys) {
			if (codeToCodeRevisionsMap.get(new Code(codeKey, codeType)) == null)
				return true;
		}

		// check if code in table has been dropped
		for (CodeRevision cr : codeRevisions) {
			if (!codeKeys.contains(cr.getCode().getKey()))
				return true;
		}

		// check if any codes have been revised
		for (CodeRevision cr : codeRevisions) {
			if (!CoreSettings.HIGH_DATE.equals(cr.getRevision().getEndDate())) {
				if (existingActiveCodesCodeRevisionsMap.get(cr.getCode()) != null)
					return true;
				else {
					// TODO how to handle this
					// we have an inactive code in the table
					throw new CodesUpdateCentralException("Code "
							+ cr.getCode().getKey() + " in table "
							+ tableRevision.getTable().getKey()
							+ " does not have an active code revision");
				}
			}
		}
		return false;
	}

	/**
	 * @param sb1
	 * @param tableKey
	 * @param codeRevisions
	 */
	private void addNewTableRevision(final StringBuilder sb1,
			final String tableKey, final Set<CodeRevision> codeRevisions) {
		Table newTable = new Table(tableKey, tableType);
		TableRevision newTableRevision = databaseService.createTableRevision(
				newTable, currentRevision, codeRevisions);
		countNew++;
		sb1.append(" " + tableKey);
		newTableRevisions.add(newTableRevision);
	}

	@Override
	protected String getTypeDescription() {
		return tableType.getDescription();
	}

}