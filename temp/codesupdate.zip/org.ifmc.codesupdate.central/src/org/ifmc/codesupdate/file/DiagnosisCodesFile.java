/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.ifmc.codesupdate.core.CodeTypeEnum;

/**
 * Concrete implementation of the Diagnosis codes file.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class DiagnosisCodesFile extends AbstractCodesFile {

	/**
	 * Constructor
	 * 
	 * @param file
	 */
	public DiagnosisCodesFile(File file) {
		super(file);
	}

	@Override
	protected String recordLayout() {
		// assuming file format is <code key><space(s)><description>
		// where length of code key > 2 and < 6
		// and where length of code description > 0 and < 25
		return "^(\\w{3,5}) +(.{1,24})$";

	}

	@Override
	protected String formatKey(String key) {
		// add a decimal point after the 3 digit in the key if
		// length > 3 and is not an E series key
		// If E series key then decimal point is in the 4th location
		if (key.length() > 3) {
			if (key.startsWith("E")) {
				if (key.length() > 4) {
					// E1001 => E100.1
					key = (key.substring(0, 4) + "." + key.substring(4)).trim();
				} // E100 => E100
			} else {
				// 1011 => 101.1
				key = (key.substring(0, 3) + "." + key.substring(3)).trim();
			}
		} // 101 => 101; E80 => E80
		return key;
	}

	@Override
	public CodeTypeEnum getType() {
		return CodeTypeEnum.DIAGNOSIS;
	}
}
