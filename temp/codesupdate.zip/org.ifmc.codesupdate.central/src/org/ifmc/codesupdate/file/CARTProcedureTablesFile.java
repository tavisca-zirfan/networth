/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.ifmc.codesupdate.core.TableTypeEnum;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CARTProcedureTablesFile extends AbstractTablesFile {

	public CARTProcedureTablesFile(final File file) {
		super(file);
	}

	@Override
	protected String codeKeyPattern() {
		// eg: 10.1; 10.01
		return "^[0-9]{2}\\.[0-9]{1,2}$";
	}

	@Override
	protected String worksheet() {
		return "Appendix_A";
	}

	@Override
	public TableTypeEnum getType() {
		return TableTypeEnum.CART_PROCEDURE;
	}

	@Override
	protected boolean isValidRow(final HSSFRow row) {
		return (row != null) && (row.getPhysicalNumberOfCells() == 6);
	}
}