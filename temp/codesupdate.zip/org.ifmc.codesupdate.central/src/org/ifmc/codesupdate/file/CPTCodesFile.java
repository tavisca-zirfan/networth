/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.ifmc.codesupdate.core.CodeTypeEnum;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CPTCodesFile extends AbstractCodesFile {

	public CPTCodesFile(File file) {
		super(file);
	}

	@Override
	protected String recordLayout() {
		// <5 alpha numeric code><tab><max 28 character description>
		return "^(\\w{5})\\t(.{1,28})$";
	}

	@Override
	public CodeTypeEnum getType() {
		return CodeTypeEnum.CPT;
	}

}
