/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.ifmc.codesupdate.core.TableTypeEnum;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CARTDiagnosisTablesFile extends AbstractTablesFile {

	public CARTDiagnosisTablesFile(final File file) {
		super(file);
	}

	@Override
	protected String worksheet() {
		return "Appendix_A";
	}

	@Override
	protected String codeKeyPattern() {
		// matches 001.0, 003.20, 024, E800.0, E882, V01.0, V01.71
		return "^([E]?[0-9]{3}|V[0-9]{2})(\\.[0-9]{1,2})?$";
	}

	@Override
	public TableTypeEnum getType() {
		return TableTypeEnum.CART_DIAGNOSIS;
	}

	@Override
	protected boolean isValidRow(final HSSFRow row) {
		return (row != null) && (row.getPhysicalNumberOfCells() == 6);
	}

}