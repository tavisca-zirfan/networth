/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.regex.MatchResult;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.parser.ICodesParser;

/**
 * Abstracts the behaviour of codes input files.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractCodesFile extends AbstractDataFile implements
		ICodesParser {

	public AbstractCodesFile(final File file) {
		super(file);
	}

	/**
	 * Returns the record layout regex of the input file.
	 *
	 * @return the record layout regex
	 */
	protected abstract String recordLayout();

	/*
	 * (non-Javadoc)
	 *
	 * @see org.ifmc.codesupdate.parser.ICodesParser#parse()
	 */
	public Map<String, String> parse() {

		// use case in-sensitive map in order to ignore case differences in the
		// key
		Map<String, String> records = new TreeMap<String, String>(
				String.CASE_INSENSITIVE_ORDER);

		Scanner fileScanner = null;
		try {
			// use a Scanner to get each line
			fileScanner = new Scanner(file);

			while (fileScanner.hasNextLine()) {
				// use a second Scanner to parse the content of each line
				Scanner lineScanner = new Scanner(fileScanner.nextLine());
				MatchResult result = getMatchResult(lineScanner);

				String key = formatKey(result.group(1).trim());
				String desc = formatDescription(result.group(2).trim());

				records.put(key, desc);
				lineScanner.close();
			}
		} catch (FileNotFoundException e) {
			throw new CodesUpdateException("Input file "
					+ file.getAbsoluteFile() + " not found", e);
		} finally {
			fileScanner.close();
		}

		return records;
	}

	/**
	 * Returns default implementation of key formatting which is no formatting.
	 * Sub-classes must over-ride this method to provide custom formatting.
	 *
	 * @param key
	 *            the String key to be formatted
	 * @return the formatted key
	 */
	protected String formatKey(final String key) {
		return key;
	}

	/**
	 * Returns default implementation of description formatting which is no
	 * formatting. Sub-classes must over-ride this method to provide custom
	 * formatting.
	 *
	 * @param description
	 *            the String description to be formatted
	 * @return the formatted description
	 */
	protected String formatDescription(final String description) {
		return description;
	}

	/**
	 * @param lineScanner
	 * @throws CodesUpdateException
	 */
	private MatchResult getMatchResult(final Scanner lineScanner) {

		lineScanner.findInLine(recordLayout());

		try {
			return lineScanner.match();
		} catch (Exception e) {
			// match all so we can display offending line
			lineScanner.findInLine(".*");
			throw new CodesUpdateException(
					"Error validating input file at line "
							+ lineScanner.match().group() + " ["
							+ file.getName() + "]");
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.ifmc.codesupdate.file.ICodesDataFile#getType()
	 */
	public abstract CodeTypeEnum getType();
}
