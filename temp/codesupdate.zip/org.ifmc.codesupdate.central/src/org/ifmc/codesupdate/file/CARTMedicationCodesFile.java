/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.ifmc.codesupdate.core.CodeTypeEnum;

/**
 * Concrete implementation of the Medication codes file.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CARTMedicationCodesFile extends AbstractCodesFile {

	/**
	 * Constructor
	 * 
	 * @param file
	 */
	public CARTMedicationCodesFile(File file) {
		super(file);
	}

	@Override
	protected String recordLayout() {
		// assuming file format is <code key><tab><description>
		return "^(.+)\\t(.+)$";
	}

	@Override
	public CodeTypeEnum getType() {
		return CodeTypeEnum.CART_MEDICATION;
	}

}
