/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.ifmc.codesupdate.core.TableTypeEnum;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class OPPSProcedureTablesFile extends AbstractTablesFile {

	public OPPSProcedureTablesFile(final File file) {
		super(file);
	}

	@Override
	protected String codeKeyPattern() {
		// eg: 10.1; 10.01
		return "^[0-9]{2}\\.[0-9]{1,2}$";
	}

	@Override
	protected String worksheet() {
		return "Sheet1";
	}

	@Override
	public TableTypeEnum getType() {
		return TableTypeEnum.OPPS_PROCEDURE;
	}

	@Override
	protected String codeKeyFieldValue(final HSSFRow row) {
		// code key column is numeric
		try {
			return row.getCell((short) 3).getStringCellValue().trim();
		} catch (Exception e) {
			double key = row.getCell((short) 3).getNumericCellValue();
			// strip the decimals ie 99393.0 => 99393
			// if it is procedure code 410.11 => 410
			return (int) key + "";
		}
	}

	@Override
	protected boolean isValidRow(final HSSFRow row) {
		// TODO Auto-generated method stub
		return false;
	}
}