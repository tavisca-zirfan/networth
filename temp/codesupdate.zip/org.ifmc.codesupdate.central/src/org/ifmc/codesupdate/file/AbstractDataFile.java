/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

/**
 * Provides an abstract implementation of ICodesDataFile that concrete
 * implementations can extend.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public abstract class AbstractDataFile {

	/**
	 * the encapsulated file
	 */
	protected File file;

	/**
	 * Constructor
	 * 
	 * @param file
	 *            the File
	 */
	public AbstractDataFile(final File file) {
		this.file = file;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.ifmc.codesupdate.file.ICodesDataFile#getFile()
	 */
	public File getFile() {
		return file;
	}
}
