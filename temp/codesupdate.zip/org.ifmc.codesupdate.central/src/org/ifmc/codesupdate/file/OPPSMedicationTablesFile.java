/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.ifmc.codesupdate.core.TableTypeEnum;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class OPPSMedicationTablesFile extends AbstractTablesFile {

	public OPPSMedicationTablesFile(final File file) {
		super(file);
	}

	@Override
	protected String codeKeyPattern() {
		return ".+";
	}

	@Override
	protected String worksheet() {
		return "Appendix_C";
	}

	@Override
	public TableTypeEnum getType() {
		return TableTypeEnum.OPPS_MEDICATION;
	}

	@Override
	protected boolean isValidRow(final HSSFRow row) {
		return (row != null) && (row.getPhysicalNumberOfCells() == 5);
	}
}
