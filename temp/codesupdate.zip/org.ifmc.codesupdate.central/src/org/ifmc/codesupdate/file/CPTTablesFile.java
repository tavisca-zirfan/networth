/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.ifmc.codesupdate.core.TableTypeEnum;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CPTTablesFile extends AbstractTablesFile {

	public CPTTablesFile(final File file) {
		super(file);
	}

	@Override
	protected String codeKeyPattern() {
		return "\\w{5}";
	}

	@Override
	protected String worksheet() {
		return "Sheet1";
	}

	@Override
	public TableTypeEnum getType() {
		return TableTypeEnum.CPT;
	}

	@Override
	protected String codeKeyFieldValue(final HSSFRow row) {
		HSSFCell keyCell = row.getCell((short) 3);

		switch (keyCell.getCellType()) {

		case HSSFCell.CELL_TYPE_NUMERIC:
			double value = keyCell.getNumericCellValue(); // get the cell value
			HSSFCellStyle style = keyCell.getCellStyle();
			short idx = style.getDataFormat();
			// get format pattern for this cell
			String format = dataformat.getFormat(idx);
			// try to create java formatter. Warning: This MAY not work in all
			// cases!
			if ("General".equals(format)) {
				// check if value if format 92322.0 or 323.1
				if ((int) value == value)
					return String.valueOf((int) value);
				else
					return String.valueOf(value);
			} else {
				NumberFormat fmt = new DecimalFormat(format);
				return fmt.format(value);
			}
		default:
			return keyCell.getStringCellValue().trim();
		}
	}

	@Override
	protected boolean isValidRow(final HSSFRow row) {
		return (row != null)
				&& ((row.getPhysicalNumberOfCells() == 5) || (row
						.getPhysicalNumberOfCells() == 6));
	}
}
