/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;

import org.ifmc.codesupdate.core.CodeTypeEnum;

/**
 * Concrete implementation of the Procedure codes file.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class ProcedureCodesFile extends AbstractCodesFile {

	/**
	 * Constructor
	 *
	 * @param file
	 */
	public ProcedureCodesFile(final File file) {
		super(file);
	}

	@Override
	protected String recordLayout() {
		return "^([0-9]{3,4}) +(.{1,24})$";
	}

	@Override
	protected String formatKey(final String key) {
		// add decimal to the code key after the second digit
		return (key.substring(0, 2) + "." + key.substring(2));
	}

	@Override
	public CodeTypeEnum getType() {
		return CodeTypeEnum.PROCEDURE;
	}
}
