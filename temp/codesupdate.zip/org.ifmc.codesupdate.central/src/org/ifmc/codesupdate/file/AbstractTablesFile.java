/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.ifmc.codesupdate.central.CentralHelper;
import org.ifmc.codesupdate.central.exception.InputFileNotFoundException;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.parser.ITablesParser;

/**
 * Abstracts the behaviour of codes input files.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractTablesFile extends AbstractDataFile implements
		ITablesParser {

	protected HSSFDataFormat dataformat;

	public AbstractTablesFile(final File file) {
		super(file);
	}

	/**
	 * Returns the worksheet name where the data is located.
	 *
	 * @return the String worksheet name <br />
	 *         <code>null</code> if the first worksheet is to be used
	 *         irrespective of worksheet name
	 */
	protected abstract String worksheet();

	/*
	 * (non-Javadoc)
	 *
	 * @see org.ifmc.codesupdate.parser.ITablesParser#parse()
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<String>> parse() {

		// use case in-sensitive map in order to ignore case differences in the
		// key
		Map<String, List<String>> records = new TreeMap<String, List<String>>(
				String.CASE_INSENSITIVE_ORDER);

		try {
			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(file));

			HSSFWorkbook wb = new HSSFWorkbook(fs);
			dataformat = wb.createDataFormat();

			HSSFSheet sheet = null;
			if (worksheet() == null) {
				sheet = wb.getSheetAt(0);
			} else {
				sheet = wb.getSheet(worksheet());
			}

			Iterator it = sheet.rowIterator();

			while (it.hasNext()) {
				HSSFRow row = (HSSFRow) it.next();

				if (isValidRow(row)) {
					String tableKey = tableKeyFieldValue(row);
					String codeKey = codeKeyFieldValue(row);

					Pattern pattern = Pattern.compile(tableColumnPattern());
					Matcher matcher = pattern.matcher(tableKey);
					if (matcher.find()) {
						pattern = Pattern.compile(codeKeyPattern());
						matcher = pattern.matcher(codeKey);
						if (matcher.find()) {
							tableKey = tableKey.substring(5).trim();
							CentralHelper.addCodeToTable(tableKey, codeKey,
									records);
						}
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO
			throw new InputFileNotFoundException(e);
		} catch (IOException e) {
			throw new CodesUpdateException(
					"Error opening input file for reading [" + file.getName()
							+ "]", e);
		} catch (NullPointerException e) {
			throw new CodesUpdateException(
					"Error opening input file for reading. Check worksheet name ["
							+ file.getName() + "]", e);
		}

		return records;
	}

	protected String tableColumnPattern() {
		// valid field format
		// "Table <number>.<number><optional lower case alphabet>"
		return "^Table \\d+\\.\\w+";
	}

	protected abstract String codeKeyPattern();

	protected String codeKeyFieldValue(final HSSFRow row) {
		return row.getCell((short) 3).getStringCellValue().trim();
	}

	/**
	 * Default implementation assumes key is the first column.
	 *
	 * @param row
	 * @return
	 */
	protected String tableKeyFieldValue(final HSSFRow row) {
		return row.getCell((short) 0).getStringCellValue().trim();
	}

	/**
	 * Concrete classes must implement whether given row is valid.
	 * 
	 * @param row
	 * @return
	 */
	abstract protected boolean isValidRow(final HSSFRow row);

	public abstract TableTypeEnum getType();
}
