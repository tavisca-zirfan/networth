/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.central.business;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.CodesUpdateDBException;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.db.CodesDBUpdater;
import org.ifmc.codesupdate.parser.ICodesParser;
import org.ifmc.codesupdate.parser.ParserFactory;

/**
 * Provides the entry point that sequences all steps required to update the
 * Central repository of codes.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CodesUpdater extends AbstractUpdater {

	private Map<String, String> fileRecords;

	private final CodesDBUpdater dbUpdater;

	protected CodeTypeEnum codeTypeEnum;

	public CodesUpdater(final File inputFile, final CodeTypeEnum codeTypeEnum,
			final Date revisionDate, final IDatabaseService databaseService,
			final ISVNClientService svnClientService,
			final ILogService logService, final WorkData workData) {

		super(inputFile, revisionDate, databaseService,
				svnClientService, logService, workData);

		this.codeTypeEnum = codeTypeEnum;

		parseInputFile(); // run the parser -- populates the fileRecords

		dbUpdater = new CodesDBUpdater(fileRecords, codeTypeEnum, revisionDate,
				databaseService, logService);


	}

	/**
	 * Checks if a rollback is necessary, and executes one if it is. Rollback is
	 * required if the input file already exists in the specified revision.
	 *
	 * @param inputFile
	 *            the input File
	 * @param codeTypeEnum
	 *            the CodeTypeEnum of the input File
	 * @param revisionDate
	 *            the revision date
	 * @param databaseService
	 *            handle to the IDatabaseService
	 * @param svnClientService
	 *            handle to the ISVNClientService
	 * @param logService
	 *            handle to the ILogService
	 * @param workData
	 *            the WorkData to track progress
	 */
	@Override
	protected void rollbackIfNecessary() {
		String inputDirPath = CoreHelper.formatInputDestination(revisionDate);
		// check if input file already exists (indicates rollback necessary)
		if (svnClientService.isFileExists(inputFile, inputDirPath)) {
			logService
					.logInfo("Detected revising existing revision. Attempting to rollback existing revision ["
							+ inputFile.getName() + "]");
			workData.setCurrentSubTask("Rolling back existing revision");
			// TODO rollback subversion file as well!
			dbUpdater.rollback();
			workData.worked(1);
			logService.logInfo("Succeeded rollback of existing revision ["
					+ inputFile.getName() + "]");
		}

	}

	/**
	 * Returns a map of code key to code description.
	 */
	@Override
	protected void parseInputFile() {

		ICodesParser fileParser = ParserFactory.createCodesParser(inputFile,
				codeTypeEnum);

		// parse input file
		logService.logInfo("Attempting to validate input file ["
				+ inputFile.getName() + "]");
		workData.setCurrentSubTask("Validating input file");
		fileRecords = fileParser.parse();
		workData.worked(1);
		logService.logInfo("Succeeded validating input file containing "
				+ fileRecords.size() + " codes [" + inputFile.getName() + "]");
	}

	@Override
	protected void updateCentralDB() {
		// update the central database with input file
		logService
				.logInfo("Attempting to perform database updates for input file ["
						+ inputFile.getName() + "]");
		workData.setCurrentSubTask("Updating central database");

		try {
			dbUpdater.update();

		} catch (RuntimeException e) {
			// database update failed
			// subversion and database are now out of sync
			// TODO need to rollback subversion
			// need to handle issue when revising
			throw new CodesUpdateDBException(
					"Failed update of central database for input file ["
							+ inputFile.getName() + "].", e);
		}
		workData.worked(2);
		logService.logInfo("Succeeded database updates for input file ["
				+ inputFile.getName() + "]");

	}

	public List<CodeRevision> getExpiredCodeRevisions() {
		return dbUpdater.getExpiredCodeRevisions();
	}

	public List<CodeRevision> getNewCodeRevisions() {
		return dbUpdater.getNewCodeRevisions();
	}
}