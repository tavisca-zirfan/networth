/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.central.business;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.TableTypeEnum;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.CodesUpdateDBException;
import org.ifmc.codesupdate.dao.dt.TableRevision;
import org.ifmc.codesupdate.db.TablesDBUpdater;
import org.ifmc.codesupdate.parser.ITablesParser;
import org.ifmc.codesupdate.parser.ParserFactory;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class TablesUpdater extends AbstractUpdater {

	private Map<String, List<String>> fileRecords;

	private final TablesDBUpdater dbUpdater;

	private final TableTypeEnum tableTypeEnum;

	public TablesUpdater(final File inputFile,
			final TableTypeEnum tableTypeEnum,
			final Date revisionDate, final IDatabaseService databaseService,
			final ISVNClientService svnClientService,
			final ILogService logService, final WorkData workData) {

		super(inputFile, revisionDate, databaseService,
				svnClientService, logService, workData);

		this.tableTypeEnum = tableTypeEnum;

		parseInputFile(); // populates the fileRecords
		workData.setCurrentSubTask("Initializing database updater");
		dbUpdater = new TablesDBUpdater(fileRecords, tableTypeEnum,
				revisionDate,
				databaseService, logService);

	}

	@Override
	protected void parseInputFile() {

		ITablesParser fileParser = ParserFactory.createTablesParser(inputFile,
				tableTypeEnum);

		logService.logInfo("Attempting to validate input file ["
				+ inputFile.getName() + "]");
		workData.setCurrentSubTask("Validating input file");
		fileRecords = fileParser.parse();
		workData.worked(1);
		logService.logInfo("Succeeded validating input file containing "
				+ fileRecords.size() + " tables [" + inputFile.getName() + "]");
	}

	@Override
	protected void rollbackIfNecessary() {
		String inputDirPath = CoreHelper.formatInputDestination(revisionDate);
		// check if input file already exists (indicates rollback necessary)
		if (svnClientService.isFileExists(inputFile, inputDirPath)) {
			logService
					.logInfo("Detected revising existing revision. Attempting to rollback existing revision ["
							+ inputFile.getName() + "]");
			workData.setCurrentSubTask("Rolling back existing revision");

			dbUpdater.rollback();
			// TODO atomic rollback of subversion file as well!
			workData.worked(1);
			logService.logInfo("Succeeded rollback of existing revision ["
					+ inputFile.getName() + "]");
		}

	}

	@Override
	protected void updateCentralDB() {

		// update the central database with input file
		logService
				.logInfo("Attempting to perform database updates for input file ["
						+ inputFile.getName() + "]");
		workData.setCurrentSubTask("Updating central database");

		try {

			dbUpdater.update();

		} catch (RuntimeException e) {
			// database update failed
			// subversion and database are now out of sync
			// TODO need to rollback subversion
			// need to handle issue when revising
			throw new CodesUpdateDBException(
					"Failed update of central database for input file ["
							+ inputFile.getName() + "].", e);
		}

		workData.worked(2);
		logService.logInfo("Succeeded database updates for input file ["
				+ inputFile.getName() + "]");
	}

	public List<TableRevision> getExpiredTableRevisions() {
		return dbUpdater.getExpiredTableRevisions();
	}

	public List<TableRevision> getNewTableRevisions() {
		return dbUpdater.getNewTableRevisions();
	}

}
