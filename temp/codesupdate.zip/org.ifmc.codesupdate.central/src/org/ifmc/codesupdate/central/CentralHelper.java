/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.central;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.ifmc.codesupdate.central.exception.CodesUpdateCentralException;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.dao.dt.Code;
import org.ifmc.codesupdate.dao.dt.CodeRevision;
import org.ifmc.codesupdate.dao.dt.Table;
import org.ifmc.codesupdate.dao.dt.TableRevision;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CentralHelper {

	/**
	 * Checks if Revision Date specified is chronologically equal or greater
	 * than the most recent revision date in the repository.
	 *
	 * @param revisionDate
	 *            the Revision Date to check
	 * @param svnClientService
	 *            handle to the SVNClientService
	 * @throws CodesUpdateCentralException
	 *             if error accessing subversion;
	 * @return <code>true</code> if no revision exists yet or if revision date
	 *         is on or after the most recent revision date in the repository;
	 *         <code>false</code> otherwise
	 */
	public static boolean isValidRevisionDate(final Date revisionDate,
			final ISVNClientService svnClientService) {

		Date latestRevisionDate = svnClientService.getLatestRevisionDate();

		if (latestRevisionDate == null)
			return true; // clean repository

		return (revisionDate.compareTo(latestRevisionDate) >= 0);

	}

	// TODO ..delete use Set instead
	public static Map<Code, CodeRevision> getCodesCodeRevisionsMap(
			final List<CodeRevision> codeRevisions) {
		Map<Code, CodeRevision> map = new HashMap<Code, CodeRevision>();
		for (CodeRevision cr : codeRevisions) {
			map.put(cr.getCode(), cr);
		}
		return map;
	}

	public static Map<Table, TableRevision> getTablesTableRevisionsMap(
			final List<TableRevision> tableRevisions) {
		Map<Table, TableRevision> map = new HashMap<Table, TableRevision>();
		for (TableRevision tr : tableRevisions) {
			map.put(tr.getTable(), tr);
		}
		return map;
	}

	public static void addCodeToTable(final String table_key,
			final String code_key, final Map<String, List<String>> records) {

		List<String> codes = records.get(table_key);
		if (codes == null) {
			codes = new ArrayList<String>();
			records.put(table_key, codes);
		}

		codes.add(code_key);
	}

	public static Map<Code, CodeRevision> getCodesCodeRevisionsMap(
			final Set<CodeRevision> codeRevisions) {
		// TODO use Generics
		Map<Code, CodeRevision> map = new HashMap<Code, CodeRevision>();
		for (CodeRevision cr : codeRevisions) {
			map.put(cr.getCode(), cr);
		}
		return map;
	}
}
