/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.central.exception;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class CodesUpdateCentralException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CodesUpdateCentralException() {
		super();
	}

	public CodesUpdateCentralException(String message) {
		super(message);
	}

	public CodesUpdateCentralException(String message, Throwable cause) {
		super(message, cause);
	}

	public CodesUpdateCentralException(Throwable cause) {
		super(cause);
	}
}
