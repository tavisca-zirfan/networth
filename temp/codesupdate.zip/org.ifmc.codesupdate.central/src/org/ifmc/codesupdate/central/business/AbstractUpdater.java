/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.central.business;

import java.io.File;
import java.util.Date;

import org.ifmc.codesupdate.central.CentralHelper;
import org.ifmc.codesupdate.core.CoreHelper;
import org.ifmc.codesupdate.core.WorkData;
import org.ifmc.codesupdate.core.exception.CodesUpdateException;
import org.ifmc.codesupdate.core.services.IDatabaseService;
import org.ifmc.codesupdate.core.services.ILogService;
import org.ifmc.codesupdate.core.services.ISVNClientService;
import org.ifmc.codesupdate.svn.client.exception.SVNClientException;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractUpdater {

	protected File inputFile;

	protected Date revisionDate;

	protected IDatabaseService databaseService;

	protected ISVNClientService svnClientService;

	protected ILogService logService;

	protected WorkData workData;

	public AbstractUpdater(final File inputFile, final Date revisionDate,
			final IDatabaseService databaseService,
			final ISVNClientService svnClientService, final ILogService logService,
			final WorkData workData) {
		super();
		this.inputFile = inputFile;
		this.revisionDate = revisionDate;
		this.databaseService = databaseService;
		this.svnClientService = svnClientService;
		this.logService = logService;
		this.workData = workData;

	}

	/**
	 * The entry method that sequences all steps to update the Central codes
	 * repository. Verifies that specified revision date is not before the most
	 * recent revision date in the central repository. Validates the input data
	 * file. Detects if re-running the most recent revision and rolls back the
	 * most recent revision before applying specified updates.
	 */
	public void update() {

		workData.setCurrentSubTask("Updating central repository");
		if (!CentralHelper.isValidRevisionDate(revisionDate, svnClientService)) {
			throw new CodesUpdateException(
					"Specified revision date ["
							+ CoreHelper.formatDateAsString(revisionDate)
							+ "] is before that of most recent revision in the repository. Revising prior dates is currently not supported.");
		}

		rollbackIfNecessary();
		commitInputFile();
		updateCentralDB();

	}

	/**
	 * Returns a map of code key to code description.
	 */
	protected abstract void parseInputFile();

	protected abstract void rollbackIfNecessary();

	protected abstract void updateCentralDB();

	/**
	 * Commits input file into subversion.
	 *
	 * @param inputFile
	 *            the input File
	 * @param revisionDate
	 *            the Revision date
	 * @param svnClientService
	 *            handle to the ISVNClientService
	 * @param logService
	 *            handle to the ILogService
	 * @param workData
	 *            the WorkData to track progress
	 * @throws SVNClientException
	 *             if failed to commit file to subversion
	 */
	protected void commitInputFile() {
		logService.logInfo("Attempting to check input file into subversion ["
				+ inputFile.getName() + "]");
		workData.setCurrentSubTask("Checking input file into subversion");

		String destinationDir = CoreHelper.formatInputDestination(revisionDate);
		svnClientService.persistFile(inputFile, destinationDir);

		workData.worked(1);
		logService.logInfo("Succeeded in checking input file into subversion ["
				+ inputFile.getName() + "]");
	}
}
