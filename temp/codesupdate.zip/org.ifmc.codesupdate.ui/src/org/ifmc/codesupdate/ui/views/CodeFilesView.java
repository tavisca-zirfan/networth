/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.views;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;
import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.ui.CodesUpdateUIPlugin;
import org.ifmc.codesupdate.ui.core.UIText;
import org.ifmc.codesupdate.ui.widgets.FileEvent;
import org.ifmc.codesupdate.ui.widgets.FileListChangedListener;
import org.ifmc.codesupdate.ui.widgets.FileListEditor;
import org.ifmc.codesupdate.ui.widgets.FileEvent.ACTION;
import org.ifmc.qms.edit.engine.data.ValidationError;
import org.ifmc.qms.exception.ExceptionHandler;
import org.ifmc.qms.expression.engine.data.SingleData;
import org.ifmc.qms.expression.engine.data.DataTypes.Type;
import org.ifmc.qms.expression.engine.exception.ExpressionEngineException;
import org.ifmc.qms.expression.engine.exception.ExpressionEngineException.Severity;
import org.ifmc.qms.form.validation.FormData;
import org.ifmc.qms.form.validation.FormValidator;
import org.ifmc.qms.form.validation.FormValidatorFactory;
import org.ifmc.qms.ui.model.attribute.editor.DateEditor;
import org.ifmc.qms.ui.model.attribute.editor.DateFieldEditor;
import org.ifmc.qms.ui.util.WidgetToolkit;
import org.ifmc.qms.ui.widget.IWidgetSettings;
import org.ifmc.qms.ui.widget.WhiteSettings;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class CodeFilesView extends ViewPart {

	public static String ID = "org.ifmc.codesupdate.ui.view.codeFilesView";

	private FormToolkit toolkit;

	private ScrolledForm form;

	private DateFieldEditor revisionDateFieldEditor;

	private FileListEditor fileListEditor;

	@SuppressWarnings("unused")
	private PropertyChangeListener modelListener;

	private Button btnUpdateCodes;

	private final CodeFilesViewModel model = new CodeFilesViewModel();

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets
	 * .Composite)
	 */
	@Override
	public void createPartControl(final Composite parent) {

		toolkit = new FormToolkit(parent.getDisplay());
		form = toolkit.createScrolledForm(parent);
		form.getBody().setLayout(new GridLayout());
		form.setText("Code Files");

		IWidgetSettings settings = new WhiteSettings();

		// create the area for user input
		createFileUploadArea(form.getBody(), settings);

		// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=103420
		form.reflow(true);

		addModelChangeListener();
	}

	/**
	 *
	 */
	private void addModelChangeListener() {
		model
				.addPropertyChangeListener(modelListener = new PropertyChangeListener() {

					public void propertyChange(final PropertyChangeEvent evt) {
						Display.getDefault().syncExec(new Runnable() {
							public void run() {
								if ("lastLogMessage".equals(evt
										.getPropertyName())) {
									CodesUpdateUIPlugin.getDefault()
											.writeToConsole(
													model.getLastLogMessage());
								}
								if ("isUpdateEnabled".equals(evt
										.getPropertyName())) {
									btnUpdateCodes.setEnabled(model
											.isUpdateEnabled());
								}

							}
						});

					}
				});
	}

	/**
	 * @param composite
	 * @param settings
	 */
	private void createFileUploadArea(final Composite composite,
			final IWidgetSettings settings) {

		DateEditor revisionDateEditor = new DateEditor(settings);
		revisionDateEditor.setLabelText(UIText.LABEL_REVISION_DATE_TEXT);
		revisionDateFieldEditor = (DateFieldEditor) revisionDateEditor
				.getFieldEditor(composite);
		revisionDateFieldEditor.getControls(composite);
		revisionDateFieldEditor.setRequired(true);
		revisionDateFieldEditor.setEnabled(true);

		WidgetToolkit.createLabel(composite); // for spacing

		String[] filterNames = { "Text Documents" };
		String[] filterExtensions = { "*.txt" };

		fileListEditor = new FileListEditor(composite, filterNames,
				filterExtensions, 250, 250, settings, model);
		populateValidFileNames();
		addFileListChangeListener();

		WidgetToolkit.createLabel(composite); // for spacing

		// put both buttons in a single composite to make them equal width
		Composite composite2 = WidgetToolkit.createComposite(composite, 4, 2);
		settings.setupControl(composite2);

		btnUpdateCodes = WidgetToolkit.createButton(composite2, 0,
				UIText.BUTTON_UPDATE_CODES_TEXT, updateCodesBtnListener(), 0,
				settings);
		btnUpdateCodes.setEnabled(model.isUpdateEnabled());
	}

	private void addFileListChangeListener() {
		fileListEditor.addFileAddedListener(new FileListChangedListener() {

			public void listChanged(final FileEvent e) {

				File file = e.getFile();
				if (e.getAction() == ACTION.ADD) {
					model.addInputFile(CodeTypeEnum.getCodeType(file.getName()),
							file);

				} else if (e.getAction() == ACTION.REMOVE) {
					model.removeInputFile(CodeTypeEnum.getCodeType(file.getName()));

				}
			}

		});
	}

	/**
	 * @return
	 */
	private void populateValidFileNames() {
		fileListEditor.addValidUniqueFileName("I9diagnoses.txt");
		fileListEditor.addValidUniqueFileName("I9procedures.txt");
		fileListEditor.addValidUniqueFileName("cart_medications.txt");
		fileListEditor.addValidUniqueFileName("opps_medications.txt");
		fileListEditor.addValidUniqueFileName("cpt.txt");
	}

	/**
	 * @return
	 */
	public SelectionListener updateCodesBtnListener() {
		SelectionListener selectionListener = new SelectionAdapter() {
			@Override
			public void widgetSelected(final SelectionEvent e) {

				// perform form fields validation
				String error = validateFields(createValidationMap());
				if (error != null) {
					openError(error);
				} else {
					// process the button action
					try {
						model.updateBtnClicked(revisionDateFieldEditor
								.getDate());
					} catch (RuntimeException e2) {
						// log message to platform log and display error
						// message
						ExceptionHandler.handleException(e2,
								CodesUpdateUIPlugin.PLUGIN_ID, true);
					}
				}
			}

		};

		return selectionListener;
	}

	/**
	 * @return
	 */
	protected Map<String, FormData> createValidationMap() {
		Map<String, FormData> validationMap = new HashMap<String, FormData>(2);

		// add variables used in the validation expressions
		// the first parameter in the put must match the code attribute in the
		// validation map XML
		if (revisionDateFieldEditor.getStringValue().equals(
				DateFieldEditor.DEFAULT_VALUE)) {
			validationMap.put("codesRevisionDate", new FormData(new SingleData(
					"", Type.Date)));
		} else {
			validationMap.put("codesRevisionDate", new FormData(new SingleData(
					revisionDateFieldEditor.getStringValue(), Type.Date)));
		}

		return validationMap;

	}

	/**
	 * @param msg
	 */
	protected void openError(final String msg) {
		MessageDialog.setDefaultImage(null);
		MessageDialog.openError(Display.getCurrent().getActiveShell(),
				"Errors", msg);
	}

	/**
	 * @param validateMap
	 * @return
	 */
	protected String validateFields(final Map<String, FormData> validateMap) {
		try {
			// use the QMS validation framework
			FormValidator validator = FormValidatorFactory.createValidator();
			Map<String, List<ValidationError>> validationErrors = validator
					.doValidate(validateMap);

			if (!validationErrors.isEmpty()) {
				StringBuffer sb = new StringBuffer(256);
				for (Iterator<List<ValidationError>> lit = validationErrors
						.values().iterator(); lit.hasNext();) {
					List<ValidationError> errors = lit.next();
					for (Iterator<ValidationError> it = errors.iterator(); it
							.hasNext();) {
						ValidationError error = it.next();
						sb.append(error.getCode() + " " + error.getMessage());
						if (it.hasNext()) {
							sb.append("\n");
						}
					}
					if (lit.hasNext()) {
						sb.append("\n");
					}
				}

				return sb.toString();
			}

		} catch (ExpressionEngineException e) {
			if (!e.getSeverity().equals(Severity.INFO)) {
				ExceptionHandler.handleException(e, false);
			}
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus() {
		form.setFocus();
	}

	@Override
	public void dispose() {
		toolkit.dispose();
		super.dispose();
	}

}
