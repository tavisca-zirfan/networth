/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.views;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.ifmc.codesupdate.business.IProcessor;
import org.ifmc.codesupdate.business.IProcessorFactory;
import org.ifmc.codesupdate.business.ProcessorFactory;
import org.ifmc.codesupdate.core.CodeTypeEnum;
import org.ifmc.codesupdate.core.services.impl.LogData;

/**
 * The model behind the CodesUpdateEditor. Implements Observer in order to track
 * log updates. Extends AbstractModelObject to update the view with log
 * messages.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public final class CodeFilesViewModel extends AbstractViewModel {

	private final Map<CodeTypeEnum, File> inputFileMap = new HashMap<CodeTypeEnum, File>();

	@Override
	protected IProcessor constructProcesser(final Date revisionDate,
			final String repositoryUrl,
			final String notificationEmailAddressList, final LogData logData) {
		IProcessorFactory factory = new ProcessorFactory();

		return factory.constructCodeProcessor(revisionDate,
				repositoryUrl, notificationEmailAddressList, inputFileMap,
				logData);
	}

	@Override
	public boolean isUpdateEnabled() {
		// update is enabled only if input files have been selected
		return !inputFileMap.isEmpty();
	}

	public void addInputFile(final CodeTypeEnum codeTypeEnum, final File file) {
		inputFileMap.put(codeTypeEnum, file);
		firePropertyChange("isUpdateEnabled", "", isUpdateEnabled());
	}

	public void removeInputFile(final CodeTypeEnum codeTypeEnum) {
		inputFileMap.remove(codeTypeEnum);
		firePropertyChange("isUpdateEnabled", "", isUpdateEnabled());
	}

	public void clearInputFiles() {
		inputFileMap.clear();
		firePropertyChange("isUpdateEnabled", "", isUpdateEnabled());
	}
}
