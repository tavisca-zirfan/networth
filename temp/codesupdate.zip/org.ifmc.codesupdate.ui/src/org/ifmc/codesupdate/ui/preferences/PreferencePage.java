package org.ifmc.codesupdate.ui.preferences;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.ifmc.codesupdate.ui.CodesUpdateUIPlugin;
import org.ifmc.codesupdate.ui.core.UIText;

public class PreferencePage extends FieldEditorPreferencePage {

	public PreferencePage() {
		super("ICD-9-CM Code Set Update", GRID);
		setPreferenceStore(CodesUpdateUIPlugin.getDefault().getPreferenceStore());
		setDescription("Customize your settings");
	}

	@Override
	protected void createFieldEditors() {
		{			
			addField(new EmailListEditor(
					PreferenceConstants.NOTIFICATION_EMAIL,
					UIText.LABEL_NOTIFICATION_EMAIL_TEXT,
					getFieldEditorParent()));
		}
	}
}