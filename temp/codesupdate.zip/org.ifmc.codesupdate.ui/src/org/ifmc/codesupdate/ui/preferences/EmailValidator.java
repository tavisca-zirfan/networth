/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.preferences;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.IInputValidator;

/**
 * Provides a validator for email addresses.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class EmailValidator implements IInputValidator {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.dialogs.IInputValidator#isValid(java.lang.String)
	 */
	public String isValid(final String emailAddress) {
		if (emailAddress != null && emailAddress.equals("")) {
			return "No email address entered";
		}

		if (!isValidEmailAddress(emailAddress)) {
			return "Invalid email address";
		}
		return null;
	}

	private boolean isValidEmailAddress(final String input) {

		// Checks for email addresses that start with
		// www. and prints a message if it does.
		Pattern p = Pattern.compile("^www\\.");
		Matcher m = p.matcher(input);
		if (m.find()) {
			return false;
		}

		p = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
				Pattern.CASE_INSENSITIVE);
		m = p.matcher(input);
		if (!m.find()) {
			return false;
		}
		return true;
	}
}
