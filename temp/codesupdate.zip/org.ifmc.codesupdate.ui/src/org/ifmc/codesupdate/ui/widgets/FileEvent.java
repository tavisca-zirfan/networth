/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.widgets;

import java.io.File;
import java.util.EventObject;

/**
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class FileEvent extends EventObject {

	private final File file;

	private final ACTION action;

	public enum ACTION {
		ADD, REMOVE
	};

	private static final long serialVersionUID = 248620620960476690L;

	public FileEvent(final Object source, final File file, final ACTION action) {
		super(source);
		this.file = file;
		this.action = action;
	}

	public File getFile() {
		return file;
	}

	public ACTION getAction() {
		return action;
	}
}
