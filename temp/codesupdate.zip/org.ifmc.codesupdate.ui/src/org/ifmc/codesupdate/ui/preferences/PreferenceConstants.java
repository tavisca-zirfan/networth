package org.ifmc.codesupdate.ui.preferences;

/**
 * A class to hold constants related to ModDev preferences.
 * 
 * @author Dana Oredson
 * 
 */
public final class PreferenceConstants {

	public static final String NOTIFICATION_EMAIL = "org.ifmc.codesupdate.notificationEmail";

	public static final String SVN_REPOSITORY_URL = "org.ifmc.codesupdate.svnRepositoryURL";

	/* Do not allow instantiation of this class */
	private PreferenceConstants() {
	}
}