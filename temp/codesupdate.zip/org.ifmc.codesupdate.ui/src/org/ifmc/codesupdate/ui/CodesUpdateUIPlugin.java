package org.ifmc.codesupdate.ui;

import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class CodesUpdateUIPlugin extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "org.ifmc.codesupdate.ui";

	// The shared instance
	private static CodesUpdateUIPlugin plugin;

	private MessageConsole console;

	private MessageConsoleStream stream;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;

		makeConsole();
	}

	private void makeConsole() {
		console = new MessageConsole("ICD-9-CM Code Set Log", null);
		ConsolePlugin.getDefault().getConsoleManager().addConsoles(
				new IConsole[] { console });
		stream = console.newMessageStream();

		// TODO fix timing issue
		// when Perspective is activated for the first time we need to
		// explicitly display the console since the Perspective class cannot
		// directly make this call (cyclic dependency)
		displayConsole();
	}

	public void displayConsole() {
		ConsolePlugin.getDefault().getConsoleManager().showConsoleView(console);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 * 
	 * @return the shared instance
	 */
	public static CodesUpdateUIPlugin getDefault() {
		return plugin;
	}

	public void writeToConsole(String message) {
		stream.println(message);
	}

}
