/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.jobs;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.ifmc.codesupdate.business.IProcessor;
import org.ifmc.qms.exception.ExceptionHandler;

/**
 * Extends the Eclipse Job class to provide asynchronous job functionality.
 *
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public class ProcessorJob extends Job {

	private IProcessor processor;

	public ProcessorJob(final String name) {
		super(name);
	}

	/**
	 * Constructor
	 *
	 * @param processor
	 *            the Processor
	 * @param title 
	 */
	public ProcessorJob(final IProcessor processor, final String title) {
		super(title);
		setUser(true);
		this.processor = processor;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @seeorg.eclipse.core.runtime.jobs.Job#run(org.eclipse.core.runtime.
	 * IProgressMonitor)
	 */
	@Override
	protected IStatus run(final IProgressMonitor monitor) {

		processor.process(monitor);

		// now commit and clear all log messages
		try {
			processor.commitLogFileAndClear();
		} catch (Exception e) {
			// TODO cleanup exception handling
			ExceptionHandler.handleException(e, true);
		}

		if (monitor.isCanceled()) {
			// TODO job is usually running so cancel doesn't work
			// monitor.setCanceled(true);
			// this.cancel();
			// NOTE: for now just display the cannot cancel message
			showCancelDialog();
			monitor.setCanceled(false);
		}
		monitor.done();

		return Status.OK_STATUS;
	}

	/**
	 * Displays the cancel dialog.
	 */
	private void showCancelDialog() {
		MessageDialog.setDefaultImage(null);
		final String msg = "Cancellation is currently not implemented. If you would like to re-run the current revision simply repeat the process. The procedure will automatically detect and rollback the previous run before executing.";
		Display.getDefault().syncExec(new Runnable() {

			public void run() {
				MessageDialog.openInformation(Display.getDefault()
						.getActiveShell(), "Information", msg);
			}
		});

	}

}