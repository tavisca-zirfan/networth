/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.widgets;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.ifmc.codesupdate.ui.views.AbstractViewModel;
import org.ifmc.codesupdate.ui.widgets.FileEvent.ACTION;
import org.ifmc.qms.ui.util.WidgetToolkit;
import org.ifmc.qms.ui.widget.IWidgetSettings;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public class FileListEditor {

	List<FileListChangedListener> fileAddedListeners = new ArrayList<FileListChangedListener>();

	public void addFileAddedListener(final FileListChangedListener listener) {
		fileAddedListeners.add(listener);
	}

	public void removeFileAddedListener(final FileListChangedListener listener) {
		fileAddedListeners.remove(listener);
	}

	public void fireFileListChanged(final FileEvent event) {
		for (FileListChangedListener listener : fileAddedListeners) {
			listener.listChanged(event);
		}
	}

	private org.eclipse.swt.widgets.List list;

	// list of acceptable filenames that can be selected
	private Set<String> validUniqueFileNames = new HashSet<String>();

	private final Set<File> selectedUniqueFiles = new HashSet<File>();

	public FileListEditor(final Set<String> validFileNames) {
		validUniqueFileNames = validFileNames;
	}

	public FileListEditor(final Composite parent, final String[] filterNames,
			final String[] filterExtensions, final int width, final int height,
			final IWidgetSettings settings, final AbstractViewModel model) {

		final Composite composite = WidgetToolkit.createComposite(parent, 5, 2);
		list = createList(width, height, settings, composite);
		createActions(filterNames, filterExtensions, settings, composite);
	}

	public void addValidUniqueFileName(final String fileName) {
		validUniqueFileNames.add(fileName);
	}

	public Set<String> getValidUniqueFileNames() {
		return validUniqueFileNames;
	}

	public Set<File> getSelectedUniqueFiles() {
		return selectedUniqueFiles;
	}

	/**
	 * @param filterNames
	 * @param filterExtensions
	 * @param width
	 * @param height
	 * @param settings
	 * @param parent
	 * @return
	 * @return
	 */
	private org.eclipse.swt.widgets.List createList(final int width,
			final int height, final IWidgetSettings settings,
			final Composite parent) {

		org.eclipse.swt.widgets.List list = new org.eclipse.swt.widgets.List(
				parent, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL);
		list.setBounds(0, 0, width, height);
		if (settings != null) {
			settings.setupControl(list);
		}

		// grab excess horizontal space so list grows with view resize
		list.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		return list;
	}

	private void createActions(final String[] filterNames,
			final String[] filterExtensions, final IWidgetSettings settings,
			final Composite parent) {

		final Composite composite = WidgetToolkit.createComposite(parent, 2, 1);
		GridData gridData = (GridData) composite.getLayoutData();
		// don't grab excess horizontal space; prevents resize on window resizes
		gridData.grabExcessHorizontalSpace = false;

		SelectionListener addSelectionListener = new SelectionAdapter() {
			@Override
			public void widgetSelected(final SelectionEvent event) {
				// User has selected to open file(s)
				FileDialog dlg = new FileDialog(composite.getShell(), SWT.OPEN
						| SWT.MULTI);
				dlg.setFilterNames(filterNames);
				dlg.setFilterExtensions(filterExtensions);
				String fn = dlg.open();
				if (fn != null) {
					Set<String> invalidFileNames = new HashSet<String>();
					Set<String> duplicateFileNames = new HashSet<String>();

					for (String fileName : dlg.getFileNames()) {

						// check if valid file
						if (isValid(fileName)) {
							String filterPath = dlg.getFilterPath();
							File file = new File(filterPath + File.separator
									+ fileName);
							if ((selectedUniqueFiles.contains(file))) {
								duplicateFileNames.add(fileName);
							} else {
								selectedUniqueFiles.add(file);
								list.add(fileName);
								fireFileListChanged(new FileEvent(this, file,
										ACTION.ADD));
							}
						} else {
							invalidFileNames.add(fileName);
						}
					}
					if (!duplicateFileNames.isEmpty()) {
						displayDuplicateFileNamesError(duplicateFileNames);
					}
					if (!invalidFileNames.isEmpty()) {
						displayInvalidFileNamesError(invalidFileNames);
					}
				}
			}

			private void displayDuplicateFileNamesError(
					final Set<String> duplicateFileNames) {
				String msg = "The following are duplicate input files:\n";
				msg += duplicateFileNames.toString();
				MessageDialog.setDefaultImage(null);
				MessageDialog.openInformation(Display.getCurrent()
						.getActiveShell(), "Information", msg);
			}

			private void displayInvalidFileNamesError(
					final Set<String> invalidFileNames) {
				String msg = "The following are not valid input files:\n";
				msg += invalidFileNames.toString();
				msg += "\n\nValid input file names are:\n";
				msg += validUniqueFileNames.toString();
				MessageDialog.setDefaultImage(null);
				MessageDialog.openError(Display.getCurrent().getActiveShell(),
						"Errors", msg);
			}

			private boolean isValid(final String fileName) {
				if ((validUniqueFileNames != null)
						&& (validUniqueFileNames.size() > 0))
					return validUniqueFileNames.contains(fileName);
				return true;
			}
		};

		SelectionListener removeSelectionListener = new SelectionAdapter() {
			@Override
			public void widgetSelected(final SelectionEvent event) {
				// User has selected to remove file(s)
				if (list.getSelectionCount() > 0) {

					for (int idx : list.getSelectionIndices()) {
						File file = removeFromSelectedFiles(list.getItems()[idx]);
						if (file != null) {
							fireFileListChanged(new FileEvent(this, file,
									ACTION.REMOVE));
						}
					}
					list.remove(list.getSelectionIndices());
				}

			}

			private File removeFromSelectedFiles(final String fileName) {
				for (File file : selectedUniqueFiles) {
					if (file.getName().equals(fileName)) {
						selectedUniqueFiles.remove(file);
						return file;
					}
				}
				return null;
			}
		};

		SelectionListener clearSelectionListener = new SelectionAdapter() {
			@Override
			public void widgetSelected(final SelectionEvent event) {
				list.removeAll();
				for (File file : selectedUniqueFiles) {
					fireFileListChanged(new FileEvent(this, file, ACTION.REMOVE));
				}
				selectedUniqueFiles.clear();

			}
		};

		@SuppressWarnings("unused")
		Button addButton = constructButton("Add...", settings, composite,
				addSelectionListener);

		@SuppressWarnings("unused")
		Button removeButton = constructButton("Remove", settings, composite,
				removeSelectionListener);

		@SuppressWarnings("unused")
		Button clearButton = constructButton("Remove All", settings, composite,
				clearSelectionListener);

	}

	/**
	 * @param text
	 * @param settings
	 * @param composite
	 * @param addSelectionListener
	 * @return
	 */
	private Button constructButton(final String text,
			final IWidgetSettings settings, final Composite composite,
			final SelectionListener addSelectionListener) {
		Button button;
		if (settings != null) {
			button = WidgetToolkit.createButton(composite, 0, text,
					addSelectionListener, SWT.NONE, settings);
		} else {
			button = new Button(composite, SWT.FLAT);
			button.setText(text);
			button.addSelectionListener(addSelectionListener);
		}
		button.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, true));
		return button;
	}
}
