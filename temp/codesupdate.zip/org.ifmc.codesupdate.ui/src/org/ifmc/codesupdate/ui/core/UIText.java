/**
 * 
 */
package org.ifmc.codesupdate.ui.core;

import org.eclipse.osgi.util.NLS;

/**
 * Provides constants for UI text elements.
 * 
 * @author sudhakar
 * 
 */
public final class UIText extends NLS {

	private UIText() {
	}

	private static final String BUNDLE_NAME = "org.ifmc.codesupdate.ui.core.uitext"; //$NON-NLS-1$	

	public static String BUTTON_UPDATE_TABLES_TEXT;

	public static String LABEL_REVISION_DATE_TEXT;

	public static String BUTTON_UPDATE_CODES_TEXT;

	// preferences
	public static String LABEL_NOTIFICATION_EMAIL_TEXT;

	public static String LABEL_SVN_REPOSITORY_URL_TEXT;

	static {
		NLS.initializeMessages(BUNDLE_NAME, UIText.class);
	}
}
