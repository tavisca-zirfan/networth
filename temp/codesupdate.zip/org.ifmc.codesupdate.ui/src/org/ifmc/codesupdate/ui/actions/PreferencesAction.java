package org.ifmc.codesupdate.ui.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.preference.PreferenceDialog;
import org.eclipse.jface.preference.PreferenceManager;
import org.eclipse.jface.preference.PreferenceNode;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

public class PreferencesAction implements IWorkbenchWindowActionDelegate {

	/*
	 * Does not need to do anything. There are no instance variables.
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
	 */
	public void dispose() {
	}

	/*
	 * No implementation necesssary. (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
	 */
	public void init(IWorkbenchWindow window) {
	}

	public void run(IAction action) {
		PreferenceManager pm = new PreferenceManager();
		PreferenceNode node1 = new PreferenceNode(
				"org.ifmc.codesupdate.ui.preferences.PreferencePage");
		node1.setPage(new org.ifmc.codesupdate.ui.preferences.PreferencePage());
		pm.addToRoot(node1);
		PreferenceNode node2 = new PreferenceNode(
				"org.ifmc.codesupdate.ui.preferences.AdminPreferencePage");
		node2
				.setPage(new org.ifmc.codesupdate.ui.preferences.AdminPreferencePage());
		node1.add(node2);

		PreferenceDialog d = new PreferenceDialog(null, pm);
		d.open();
	}

	/*
	 * No implementation necessary. (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction,
	 *      org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}
}
