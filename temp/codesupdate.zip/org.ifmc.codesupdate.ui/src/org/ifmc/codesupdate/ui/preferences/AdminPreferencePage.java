package org.ifmc.codesupdate.ui.preferences;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.StringFieldEditor;
import org.ifmc.codesupdate.ui.CodesUpdateUIPlugin;
import org.ifmc.codesupdate.ui.core.UIText;

public class AdminPreferencePage extends FieldEditorPreferencePage {

	public AdminPreferencePage() {
		super("ICD-9-CM Code Set Update Admin", GRID);
		setPreferenceStore(CodesUpdateUIPlugin.getDefault().getPreferenceStore());
		setDescription("WARNING: Incorrect settings may make the application inoperable or even corrupt the data.");
	}

	@Override
	protected void createFieldEditors() {
		{
			addField(new StringFieldEditor(
					PreferenceConstants.SVN_REPOSITORY_URL,
					UIText.LABEL_SVN_REPOSITORY_URL_TEXT,
					getFieldEditorParent()));
		}
	}
}