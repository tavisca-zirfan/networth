/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 * 
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui;

/**
 * Provides helper methods.
 * 
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 * 
 */
public final class UIHelper {

	private UIHelper() {
	}

	/**
	 * Returns the value for given preference id
	 * 
	 * @param preferenceId
	 * @param clazz
	 *            hint as to the preference value codeType
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Object getPreference(final String preferenceId,
			final Class clazz) {
		if (clazz == String.class) {
			return CodesUpdateUIPlugin.getDefault().getPluginPreferences().getString(
					preferenceId);
		}
		if (clazz == Boolean.class) {
			return CodesUpdateUIPlugin.getDefault().getPluginPreferences().getBoolean(
					preferenceId);
		}
		if (clazz == Integer.class) {
			return CodesUpdateUIPlugin.getDefault().getPluginPreferences().getInt(
					preferenceId);
		}
		return null;
	}

	/**
	 * Convenience method that assumes a default of String preference value
	 * 
	 * @param preferenceId
	 * @return
	 */
	public static String getPreference(final String preferenceId) {
		return (String) getPreference(preferenceId, String.class);
	}
}
