/**
 * Copyright 2008 by Iowa Foundation For Medical Care
 *
 * All rights reserved. No portion of this software or its documentation may be
 * reproduced in any form or by any means, without the express written
 * permission of the copyright owner.
 */
package org.ifmc.codesupdate.ui.views;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.ui.PlatformUI;
import org.ifmc.codesupdate.business.IProcessor;
import org.ifmc.codesupdate.core.AbstractModelObject;
import org.ifmc.codesupdate.core.services.impl.LogData;
import org.ifmc.codesupdate.ui.UIHelper;
import org.ifmc.codesupdate.ui.dialogs.MultiMessageDialog;
import org.ifmc.codesupdate.ui.jobs.ProcessorJob;
import org.ifmc.codesupdate.ui.preferences.PreferenceConstants;

/**
 * @author Sudhakar Ramasamy <sramasamy@ifmc.sdps.org>
 *
 */
public abstract class AbstractViewModel extends AbstractModelObject implements
		Observer {

	private final List<String> errorMessages = new ArrayList<String>();

	/**
	 * the last log message
	 */
	private String lastLogMessage;

	/**
	 * Process the update. Uses the Template Method pattern to have the derived
	 * classes supply the processor.
	 *
	 * @param revisionDate
	 *            the revision date
	 */
	public void updateBtnClicked(final Date revisionDate) {

		LogData logData = new LogData();
		logData.addObserver(this);

		// delimited list of email addresses where notification emails need to
		// be sent
		String notificationEmailAddressList = UIHelper
				.getPreference(PreferenceConstants.NOTIFICATION_EMAIL);

		String svnRepositoryUrl = UIHelper
				.getPreference(PreferenceConstants.SVN_REPOSITORY_URL);

		IProcessor processor = constructProcesser(revisionDate,
				svnRepositoryUrl,
				notificationEmailAddressList, logData);

		ProcessorJob job = new ProcessorJob(processor, processor.getName());
		firePropertyChange("isUpdateEnabled", "", false);
		job.schedule();

		job.addJobChangeListener(new JobChangeAdapter() {

			@Override
			public void done(final IJobChangeEvent event) {
				if (!errorMessages.isEmpty()) {
					displayMessages();
					firePropertyChange("isUpdateEnabled", "", true);
				}
			}

			private void displayMessages() {

				PlatformUI.getWorkbench().getDisplay().syncExec(new Runnable() {
					public void run() {
						MultiMessageDialog mmd = new MultiMessageDialog(
								PlatformUI.getWorkbench().getDisplay()
										.getActiveShell(),
								"Error Messages",
								"Following error messages were logged during the update process",
								IMessageProvider.ERROR);
						mmd.setContent(errorMessages);
						mmd.open();
						errorMessages.clear();
					}
				});

			}
		});
	}

	protected abstract IProcessor constructProcesser(Date revisionDate,
			String repositoryUrl,
			String notificationEmailAddressList, LogData logData);

	/*
	 * (non-Javadoc)
	 *
	 * @see java.util.Observer#update(java.util.Observable, java.lang.Object)
	 */
	public void update(final Observable o, final Object arg) {
		lastLogMessage = (String) arg;
		if (lastLogMessage.indexOf("ERROR") != -1) {
			errorMessages.add(lastLogMessage);
		}
		firePropertyChange("lastLogMessage", "", lastLogMessage);
	}

	/**
	 * @return the lastLogMessage
	 */
	String getLastLogMessage() {
		return lastLogMessage;
	}

	public abstract boolean isUpdateEnabled();
}
